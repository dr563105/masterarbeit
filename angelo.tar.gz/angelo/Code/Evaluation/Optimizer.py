import tensorflow as tf

from ReinforcementLearning import Graph
from Utils import XMLReader
import ray
import time
import numpy as np
import csv
import os
from Utils import utils

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

from Metrics import RapidPrototype
@ray.remote(num_gpus = 1)
class Optimizer(object):
    def __init__(self, id, eds, state_dim, LOG_DIR):
        self.OptimizerId = id
        self.state_dim = state_dim
        self._initialize(state_dim, LOG_DIR)
        self._optimize(eds, LOG_DIR)

    def _buildGraph(self, state_dim, LOG_DIR):
        graph = Graph.PPO(name="PPO",
                          state_dim=state_dim, LOG_DIR=LOG_DIR)
        return graph

    def _calculateAdvantage(self, StateBatch, ReturnBatch, SpeedBatch=None, SteeringBatch=None, GyroBatch=None):
        feed_dict = {self.Graph.PHstate: StateBatch, self.Graph.PHreturn: ReturnBatch}
        if self.Parameter.ModelConfig.CONCAT:
            feed_dict[self.Graph.PHSteering] = SteeringBatch
            feed_dict[self.Graph.PHGyro] = GyroBatch
            feed_dict[self.Graph.PHSpeed] = SpeedBatch

        return self.Session.run(self.Graph.advantage, feed_dict)

    def _optimizOneBatch(self, StateBatch, ReturnBatch, ActionBatch, AdvantageBatch, SpeedBatch, RewardBatch, LSTM_STATE,
                         SteeringBatch=None, GyroBatch=None):


        fetches = {self.Graph.a_grads,  # 0
                   self.Graph.c_grads,  # 1
                   self.merged_summary,  # 2
                   self.Graph.global_step  # 3
                   }

        feed_dict = {
            self.Graph.PHstate: StateBatch,
            self.Graph.PHreturn: ReturnBatch,
            self.Graph.PHadvantage: AdvantageBatch
        }

        if self.Parameter.EnvConfig.A_DIM == 1:
            feed_dict[self.Graph.PHaction0] = np.vstack(ActionBatch)

        elif self.Parameter.EnvConfig.A_DIM == 2:
            feed_dict[self.Graph.PHaction0] = [[i[0]] for i in ActionBatch]
            feed_dict[self.Graph.PHaction1] = [[i[1]] for i in ActionBatch]

        else:
            feed_dict[self.Graph.PHaction0] = [[i[0]] for i in ActionBatch]
            feed_dict[self.Graph.PHaction1] = [[i[1]] for i in ActionBatch]
            feed_dict[self.Graph.PHaction2] = [[i[2]] for i in ActionBatch]

        if self.Parameter.ModelConfig.CONCAT:
            feed_dict[self.Graph.PHSteering] = SteeringBatch
            feed_dict[self.Graph.PHGyro] = GyroBatch
            feed_dict[self.Graph.PHSpeed] = SpeedBatch

        fetched = self.Session.run(fetches, feed_dict=feed_dict)
        feed_dict = {}
        for i in range(len(fetched[0])):
            feed_dict[self.Graph.placeholder_a_gradients[i]] = fetched[0][i]
        for i in range(len(fetched[1])):
            feed_dict[self.Graph.placeholder_c_gradients[i]] = fetched[1][i]


        fetched2 = self.Session.run([self.Graph.apply_a_gradients,
                                     self.Graph.apply_c_gradients
                                     ], feed_dict=feed_dict)

        return fetched[2], fetched2


    def _collect_gradients(self, StateBatch, ReturnBatch, ActionBatch, AdvantageBatch, SpeedBatch, RewardBatch,
                           SteeringBatch=None, GyroBatch=None):

        print("COLLECT GRADIENTS")
        print("State Batch Size {}".format(StateBatch.shape[0]))

        vae_index = None

        fetches = []
        if self.Parameter.ModelConfig.FREEZE_ACTOR_PARAMS:
            fetches.append(self.Graph.aloss_total)
        else:
            fetches.append(self.Graph.a_grads)
        a_index = len(fetches) -1

        if self.Parameter.ModelConfig.FREEZE_CRITIC_PARAMS:
            fetches.append(self.Graph.closs)
        else:
            fetches.append(self.Graph.c_grads)
        c_index = len(fetches) -1

        if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:

            if self.Parameter.ModelConfig.FREEZE_VAE_PARAMS:
                fetches.append(self.Graph.vae_loss)
            else:
                assert self.Graph.vae_grads is not None
                fetches.append(self.Graph.vae_grads)
            vae_index  = len(fetches) -1

        feed_dict = {
            self.Graph.PHstate: StateBatch,
            self.Graph.PHreturn: ReturnBatch,
            self.Graph.PHadvantage: AdvantageBatch,
            self.Graph.VAE_BATCH_SIZE : StateBatch.shape[0]
        }

        fetches.append(self.merged_summary)
        summary_index = len(fetches) -1

        if len(fetches) == 0:
            print("! NO FETCHES AVAILABLE !")
            assert(False)

        if self.Parameter.EnvConfig.A_DIM == 1:
            feed_dict[self.Graph.PHaction0] = np.vstack(ActionBatch)

        elif self.Parameter.EnvConfig.A_DIM == 2:
            feed_dict[self.Graph.PHaction0] = [[i[0]] for i in ActionBatch]
            feed_dict[self.Graph.PHaction1] = [[i[1]] for i in ActionBatch]
        else:
            feed_dict[self.Graph.PHaction0] = [[i[0]] for i in ActionBatch]
            feed_dict[self.Graph.PHaction1] = [[i[1]] for i in ActionBatch]
            feed_dict[self.Graph.PHaction2] = [[i[2]] for i in ActionBatch]

        if self.Parameter.ModelConfig.CONCAT:
            print("SteeringBatch Shape {}".format(SteeringBatch.shape))
            print("SpeedBatch Shape {}".format(SpeedBatch.shape))
            print("GyroBatch Shape {}".format(GyroBatch.shape))
            feed_dict[self.Graph.PHSteering] = SteeringBatch
            feed_dict[self.Graph.PHGyro] = GyroBatch
            feed_dict[self.Graph.PHSpeed] = SpeedBatch

        return self.Session.run(fetches, feed_dict=feed_dict), a_index, c_index, vae_index, summary_index

    def _apply_average_gradient(self, a_grads_list, c_grads_list):

        feed_dict = {}
        for i in range(len(self.Graph.placeholder_a_gradients)):
            feed_dict[self.Graph.placeholder_a_gradients[i]] = np.stack([g[i] for g in a_grads_list], axis=0).mean(
                axis=0)
        for k in range(len(self.Graph.placeholder_c_gradients)):
            feed_dict[self.Graph.placeholder_c_gradients[k]] = np.stack([g[k] for g in c_grads_list], axis=0).mean(
                axis=0)


        self.Session.run([self.Graph.apply_a_gradients,  # 0
                          self.Graph.apply_c_gradients ], # 1
                         feed_dict=feed_dict)

    def _apply_gradients(self, a_grads_list, c_grads_list, vae_grads_list):
        feed_dict = {}
        fetches = []
        print("LENGTH OF A GRADS LIST : {}".format(len(a_grads_list)))
        print("LENGTH OF C GRADS LIST : {}".format(len(c_grads_list)))
        print("LENGTH OF VAE GRADS LIST : {}".format(len(vae_grads_list)))

        for j in range(len(a_grads_list)):

            for i in range(len(a_grads_list[j])):
                feed_dict[self.Graph.placeholder_a_gradients[i]] = a_grads_list[j][i]
            for k in range(len(c_grads_list[j])):
                feed_dict[self.Graph.placeholder_c_gradients[k]] = c_grads_list[j][k]

            print("APPLY GRADIENTS")

            #fetches = [self.Graph.apply_c_gradients,  # 1
            #              self.Graph.apply_a_gradients  # 2
            #            ]

            if not self.Parameter.ModelConfig.FREEZE_CRITIC_PARAMS:
                fetches.append(self.Graph.apply_c_gradients)
                c_index = len(fetches) -1
            if not self.Parameter.ModelConfig.FREEZE_ACTOR_PARAMS:
                fetches.append(self.Graph.apply_a_gradients)
                a_index = len(fetches) -1

            self.Session.run(fetches,feed_dict=feed_dict)

            if self.Parameter.ModelConfig.UPDATE_OLD_PI_EVERY_GRAD_STEP:
                self.Session.run(self.Graph.Assign_pi2old)
                if self.Parameter.ModelConfig.VALUE_CLIPPING:
                    self.Session.run(self.Graph.Assign_critic2oldcritic)

        if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:
            if not self.Parameter.ModelConfig.FREEZE_VAE_PARAMS:

                fetches = []
                feed_dict = {}

                for p in range(len(vae_grads_list)):
                    for m in range(len(vae_grads_list[p])):
                        feed_dict[self.Graph.placeholder_vae_gradients[m]] = vae_grads_list[p][m]


                    fetches = [self.Graph.apply_vae_gradients]
                    self.Session.run(fetches,feed_dict=feed_dict)


    def _calculateReturn(self, RewardBatch, StateBatch, SpeedBatch=None, SteeringBatch=None, GyroBatch=None):
        ReturnBatch = []  # compute discounted reward
        if self.Parameter.ModelConfig.CONCAT:
            v_s = self._getValueFunction(StateBatch[-1], SpeedBatch[-1], SteeringBatch[-1], GyroBatch[-1])[0][0]
        else:
            v_s = self._getValueFunction(StateBatch[-1], SteeringBatch, GyroBatch)[0][0]
        for r in RewardBatch[::-1]:
            v_s = r + self.Parameter.HyperparameterConfig.GAMMA * v_s
            ReturnBatch.append(v_s)
        ReturnBatch.reverse()
        if self.Parameter.ModelConfig.RETURN_NORM:
            ReturnBatch -= np.mean(ReturnBatch)
            ReturnBatch /= (np.std(ReturnBatch) + 1e-8)
        return ReturnBatch

    def _getValueFunction(self, StateBatch, SpeedBatch=None, SteeringBatch=None, GyroBatch=None):

        StateBatch = StateBatch.reshape((1,) + self.state_dim)
        if StateBatch.ndim < 2: StateBatch = StateBatch[np.newaxis, :]
        if self.Parameter.ModelConfig.CONCAT:
            return self.Session.run(self.Graph.valueFunc, {self.Graph.PHstate: StateBatch,
                                                           self.Graph.PHSpeed: [SpeedBatch],
                                                           self.Graph.PHSteering: [SteeringBatch],
                                                           self.Graph.PHGyro: [GyroBatch]})
        else:
            return self.Session.run(self.Graph.valueFunc, {self.Graph.PHstate: StateBatch})

    def _calculateGAE(self, RewardBatch, ValueBatch, TerminateBatch):
        rewards = np.array(RewardBatch)
        self.rolling_r.update(rewards)
        rewards = np.clip(rewards / self.rolling_r.std, -10, 10)
        v = ValueBatch[-1]
        terminal = TerminateBatch[-1]
        ValueBatch = ValueBatch[:-1]
        TerminateBatch = TerminateBatch[:-1]
        v_final = [v * (1 - terminal)]  # v = 0 if terminal, otherwise use the predicted v
        values = np.array(ValueBatch + v_final)
        terminals = np.array(TerminateBatch + [terminal])
        # Generalized Advantage Estimation - https://arxiv.org/abs/1506.02438
        delta = rewards + self.Parameter.HyperparameterConfig.GAMMA * values[1:] * (1 - terminals[1:]) - values[:-1]
        advantage = utils.discount(delta,
                                   self.Parameter.HyperparameterConfig.GAMMA * self.Parameter.HyperparameterConfig.LAMBDA,
                                   terminals)
        returns = advantage + np.array(ValueBatch)
        advantage = (advantage - advantage.mean()) / np.maximum(advantage.std(), 1e-6)

        return np.vstack(returns), np.vstack(advantage)

    def _writeLogData(self):
        if self.RunnerID == 0:
            self.logParams["RunerId"] = str(self.RunnerID)
            self.logParams["RunnerEpisode"] = str(self.RunnerEpisode)

            fieldnames = []
            for x, y in self.logParams.items():
                fieldnames.append(x)
            if not os.path.isfile(self.log + '/OptimizerData.csv'):
                myFile = open(self.log + '/OptimizerData.csv', 'a')
                with myFile:
                    writerResult = csv.DictWriter(myFile, dialect='excel-tab', fieldnames=fieldnames)
                    writerResult.writeheader()

            myFile = open(self.log + '/OptimizerData.csv', 'a')
            with myFile:
                writerResult = csv.DictWriter(myFile, dialect='excel-tab', fieldnames=fieldnames)
                writerResult.writerows([self.logParams])

    def _optimize(self, eds, LOG_DIR):
        j = 0
        thrownBatches = 0
        a_grads_list, c_grads_list, vae_grads_list = [],[], []
        self.rolling_r = utils.RunningStats()
        finishedlist = list(range(0, self.Parameter.HyperparameterConfig.N_WORKER))

        while True:
            if ray.get(eds.get_size.remote()) >= self.Parameter.HyperparameterConfig.BATCH_SIZE:
                for _ in range(self.Parameter.HyperparameterConfig.BATCH_SIZE):
                    self.localQueue.append(ray.get(eds.get_params.remote()))
                t0 = time.time()

                #speedbatch = [item[6] for item in EnvResponse][:-1]
                #self.Graph.Speed_And_Return_Estimator.LSTM_BATCH_SIZE: SpeedBatch[1:].shape[0]
                for i in range(self.Parameter.HyperparameterConfig.BATCH_SIZE):
                    lstm_ignore = False
                    # Extract Environment Data from the Queue in MiniBatches
                    EnvResponse = self.localQueue.pop()
                    StateBatch = [item[0] for item in EnvResponse]
                    RewardBatch = [item[1] for item in EnvResponse][:-1]
                    TerminateBatch = [item[2] for item in EnvResponse]
                    ActionBatch = [item[3] for item in EnvResponse][:-1]


                    self.RunnerEpisode = [item[4] for item in EnvResponse][0]
                    ValueBatch = [item[5] for item in EnvResponse]
                    SpeedBatch = [item[6] for item in EnvResponse][:-1]
                    self.RunnerID = [item[7] for item in EnvResponse][0]
                    if self.Parameter.ModelConfig.CONCAT:
                        SteeringBatch = [item[8] for item in EnvResponse][:-1]
                        GyroBatch = [item[9] for item in EnvResponse][:-1]
                        SteeringBatch = np.vstack(SteeringBatch)
                        GyroBatch = np.vstack(GyroBatch)

                    if (len(ActionBatch) == 1):
                        print("Batchsize is 1 and will be thrown away", thrownBatches)
                        thrownBatches += 1
                        continue


                    # Tensorflow Reshaping

                    StateBatch = np.asarray(StateBatch)

                    SpeedBatch = np.vstack(SpeedBatch)

                    TerminateBatch = np.vstack(TerminateBatch)


                    #self._apply_train_ops(SpeedBatch=SpeedBatch, StateBatch=StateBatch)

                    if self.Parameter.ModelConfig.GAE:
                        StateBatch = StateBatch[:-1]
                        ReturnBatch, AdvantageBatch = self._calculateGAE(RewardBatch, ValueBatch, TerminateBatch)
                    else:
                        if self.Parameter.ModelConfig.CONCAT:
                            ReturnBatch = self._calculateReturn(RewardBatch, StateBatch, SpeedBatch, SteeringBatch,
                                                                GyroBatch)
                        else:
                            ReturnBatch = self._calculateReturn(RewardBatch, StateBatch)
                        StateBatch = StateBatch[:-1]
                        ReturnBatch = np.vstack(ReturnBatch)
                    RewardBatch = np.vstack(RewardBatch)

                    if not self.Parameter.ModelConfig.OPTIMIZE_EVERY_MINIBATCH:
                        x = []
                        if self.Parameter.ModelConfig.CONCAT:
                            if not self.Parameter.ModelConfig.GAE:
                                AdvantageBatch = self._calculateAdvantage(StateBatch, ReturnBatch, SpeedBatch,
                                                                          SteeringBatch, GyroBatch)
                            x, a_index, c_index, vae_index, s_index = self._collect_gradients(StateBatch, ReturnBatch, ActionBatch, AdvantageBatch,
                                                        SpeedBatch, RewardBatch, SteeringBatch, GyroBatch)
                        else:
                            if not self.Parameter.ModelConfig.GAE:
                                AdvantageBatch = self._calculateAdvantage(StateBatch, ReturnBatch)
                            x, a_index, c_index, vae_index, s_index = self._collect_gradients(StateBatch, ReturnBatch, ActionBatch, AdvantageBatch,SpeedBatch, RewardBatch)

                        if not self.Parameter.ModelConfig.FREEZE_ACTOR_PARAMS:
                            a_grads_list.append(x[a_index])

                        if not self.Parameter.ModelConfig.FREEZE_CRITIC_PARAMS:
                            c_grads_list.append(x[c_index])

                        if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:
                            if not self.Parameter.ModelConfig.FREEZE_VAE_PARAMS:
                                vae_grads_list.append(x[vae_index])


                        self.writer.add_summary(x[s_index], global_step=self.UpdateStep)
                        self._writeLogData()


                    else:
                        TB, fetched = self._optimizOneBatch(StateBatch, ReturnBatch, ActionBatch, AdvantageBatch,
                                                            SpeedBatch, RewardBatch)

                        self._writeLogData()
                        self.writer.add_summary(TB, global_step=self.UpdateStep)

                    self.UpdateStep += 1

                    if self.UpdateStep % 5000 == 0:
                        if self.Parameter.ModelConfig.SAVE_VAE:
                            self.Graph.VAE_saver.save(self.Session, save_path=LOG_DIR + "/VAE_SaveData/VAE",
                                                      global_step=self.UpdateStep)

                        if self.Parameter.ModelConfig.SAVE_ACTOR:
                            self.Graph.actor_saver.save(self.Session, save_path=LOG_DIR + "/ACTOR_SaveData/ACTOR",
                                                        global_step=self.UpdateStep)

                        if self.Parameter.ModelConfig.SAVE_CRITIC:
                            self.Graph.critic_saver.save(self.Session, save_path=LOG_DIR + "/CRITIC_SaveData/CRITIC",
                                                         global_step=self.UpdateStep)

                #self._apply_train_ops(SpeedBatch=SpeedBatch, StateBatch=StateBatch)

                if not self.Parameter.ModelConfig.OPTIMIZE_EVERY_MINIBATCH:
                    self.Session.run(self.Graph.Assign_pi2old)

                    if self.Parameter.ModelConfig.VALUE_CLIPPING:
                        self.Session.run(self.Graph.Assign_critic2oldcritic)
                    if self.Parameter.ModelConfig.AVERAGE_GRADIENTS:
                        self._apply_average_gradient(a_grads_list, c_grads_list)
                    else:

                        if not (self.Parameter.ModelConfig.FREEZE_ACTOR_PARAMS and self.Parameter.ModelConfig.FREEZE_CRITIC_PARAMS and self.Parameter.ModelConfig.FREEZE_VAE_PARAMS):
                            self._apply_gradients(a_grads_list, c_grads_list, vae_grads_list)

                    a_grads_list, c_grads_list, vae_grads_list = [],[], []


                t1 = time.time()
                total = t1 - t0
                # Save the optmized Network for every Runner to pull
                self.Graph.NPsaver.save(self.Session, save_path=LOG_DIR + "/SaveData/test")


                #if self.UpdateStep % 5000 == 0:
                #    if self.Parameter.ModelConfig.SAVE_VAE:
                #        self.Graph.VAE_saver.save(self.Session, save_path=LOG_DIR + "/VAE_SaveData/VAE" , global_step = self.UpdateStep)
#
                #    if self.Parameter.ModelConfig.SAVE_ACTOR:
                #        self.Graph.actor_saver.save(self.Session, save_path=LOG_DIR + "/ACTOR_SaveData/ACTOR" , global_step = self.UpdateStep)
#
                #    if self.Parameter.ModelConfig.SAVE_CRITIC:
                #        self.Graph.critic_saver.save(self.Session, save_path=LOG_DIR + "/CRITIC_SaveData/CRITIC", global_step = self.UpdateStep)

                print("Optimized in ", total, "seconds and Graph has new parameters")
                if self.Parameter.ModelConfig.CLEAR_PS_AFTER_OPT == True:
                    time.sleep(0.1)
                    ray.get(eds.clear_all_params.remote())
                else:
                    if ray.get(eds.get_size.remote()) > 100:
                        time.sleep(0.1)
                        ray.get(eds.clear_all_params.remote())

            else:
                time.sleep(0.1)

    def _initialize(self, state_dim, LOG_DIR, ):
        self.UpdateStep = 0
        self.log = LOG_DIR
        self.logParams = {}

        config = tf.ConfigProto()
        config.gpu_options.allow_growth = True

        self.Session = tf.Session(config = config)
        self.Graph = self._buildGraph(state_dim, LOG_DIR)

        self.Session.run(tf.global_variables_initializer())
        self.localQueue = []
        self.merged_summary = tf.summary.merge_all()
        self.writer = tf.summary.FileWriter(LOG_DIR, self.Session.graph)
        self.Graph.NPsaver.save(self.Session, save_path=LOG_DIR + "/SaveData/test")


        self.Parameter = XMLReader.XMLReader(LOG_DIR + "/Hyperparameter.xml")

        if self.Parameter.ModelConfig.SAVE_VAE:
            self.Graph.VAE_saver.save(self.Session, save_path=LOG_DIR + "/VAE_SaveData/VAE")
        if self.Parameter.ModelConfig.SAVE_ACTOR:
            self.Graph.actor_saver.save(self.Session, save_path=LOG_DIR + "/ACTOR_SaveData/ACTOR")
        if self.Parameter.ModelConfig.SAVE_CRITIC:
            self.Graph.critic_saver.save(self.Session, save_path=LOG_DIR + "/CRITIC_SaveData/CRITIC")

        if (self.Parameter.ModelConfig.RESTORE_MODEL):
            self.Graph.NPsaver.restore(self.Session, save_path=self.Parameter.ModelConfig.RESTORE_DIR)

        if (self.Parameter.ModelConfig.USE_PRETRAINED_VAE):
            print("RESTORE VAE FROM : \n{}".format(self.Parameter.ModelConfig.VAE_RESTORE_DIR))
            latest_checkpoint = tf.train.latest_checkpoint(self.Parameter.ModelConfig.VAE_RESTORE_DIR)
            self.Graph.VAE_saver.restore(self.Session, latest_checkpoint)#save_path=self.Parameter.ModelConfig.VAE_RESTORE_DIR)

        if (self.Parameter.ModelConfig.USE_PRETRAINED_ACTOR):
            print("RESTORE ACTOR FROM : \n{}".format(self.Parameter.ModelConfig.ACTOR_RESTORE_DIR))
            latest_checkpoint = tf.train.latest_checkpoint(self.Parameter.ModelConfig.ACTOR_RESTORE_DIR)
            self.Graph.actor_saver.restore(self.Session, latest_checkpoint)#save_path=self.Parameter.ModelConfig.VAE_RESTORE_DIR)

        if (self.Parameter.ModelConfig.USE_PRETRAINED_CRITIC):
            print("RESTORE CRITIC FROM : \n{}".format(self.Parameter.ModelConfig.CRITIC_RESTORE_DIR))
            latest_checkpoint = tf.train.latest_checkpoint(self.Parameter.ModelConfig.CRITIC_RESTORE_DIR)
            self.Graph.critic_saver.restore(self.Session, latest_checkpoint)#save_path=self.Parameter.ModelConfig.VAE_RESTORE_DIR)



    def _start_session(self):
        return tf.Session()

@ray.remote
class RPOptimizer(object):
    def __init__(self, id, eds, state_dim, LOG_DIR):
        self.OptimizerId = id
        self.state_dim = state_dim
        self._initialize( LOG_DIR)
        self._optimize(eds, LOG_DIR)


    def _run_train_ops(self, StateBatch, SpeedBatch, RewardBatch,
                           SteeringBatch=None, GyroBatch=None):

        #print("RUN TRAIN OPS")

        fetches = [
                   self.merged_summary,  # 0
                   self.RapidPrototype.spe_loss,  # 1
                   self.RapidPrototype.spe2_loss,  # 2
                   self.RapidPrototype.ret_loss,  # 3
                   self.RapidPrototype.ret2_loss,  # 4
                   self.RapidPrototype.VAE_LOSS,  # 5
                   self.RapidPrototype.spe3_loss,  # 6
                   self.RapidPrototype.LSTM_FINAL_STATE,  # 7
                   self.RapidPrototype.VAE_LSTM_STATE,  # 8
                   self.RapidPrototype.spe_train_op,
                   self.RapidPrototype.spe2_train_op,
            self.RapidPrototype.ret_train_op,
            self.RapidPrototype.ret2_train_op
                   ]
        feed_dict = {
            self.RapidPrototype.tfdret: RewardBatch[1:],
            self.RapidPrototype.tfdret0: RewardBatch[:-1],
            self.RapidPrototype.tfdspe: np.expand_dims(SpeedBatch[-1], axis=1),
            self.RapidPrototype.tfdspe2: SpeedBatch[1:],
            self.RapidPrototype.LSTM_BATCH_SIZE: SpeedBatch[1:].shape[0],
            self.RapidPrototype.VAE_BATCH_SIZE: StateBatch[1:].shape[0],
            self.RapidPrototype.tfdsta: StateBatch[1:],
            self.RapidPrototype.tfdsta2: StateBatch[1:],
            self.RapidPrototype.stateparameter2: SpeedBatch[:-1],
            self.RapidPrototype.VAE_INPUT: StateBatch[:-1],
            self.RapidPrototype.LSTM_INIT_STATE: self.LSTM_STATE,
            self.RapidPrototype.VAE_LSTM_INIT_STATE: self.VAE_LSTM_STATE,
            self.RapidPrototype.LSTM_KEEP_PROB: 1.0

        }

        return self.Session.run(fetches, feed_dict=feed_dict)

    def _writeLogData(self):
        if self.RunnerID == 0:
            self.logParams["RunerId"] = str(self.RunnerID)
            self.logParams["RunnerEpisode"] = str(self.RunnerEpisode)
            self.logParams["speloss"] = str(self.speloss)
            self.logParams["spe2loss"] = str(self.spe2loss)
            self.logParams["retloss"] = str(self.retloss)
            self.logParams["ret2loss"] = str(self.ret2loss)
            self.logParams["VAEloss"] = str(self.VAEloss)
            self.logParams["spe3loss"] = str(self.spe3loss)

            fieldnames = []
            for x, y in self.logParams.items():
                fieldnames.append(x)
            if not os.path.isfile(self.log + '/OptimizerData.csv'):
                myFile = open(self.log + '/OptimizerData.csv', 'a')
                with myFile:
                    writerResult = csv.DictWriter(myFile, dialect='excel-tab', fieldnames=fieldnames)
                    writerResult.writeheader()

            myFile = open(self.log + '/OptimizerData.csv', 'a')
            with myFile:
                writerResult = csv.DictWriter(myFile, dialect='excel-tab', fieldnames=fieldnames)
                writerResult.writerows([self.logParams])

    def _optimize(self, eds, LOG_DIR):
        thrownBatches = 0
        a_grads_list, c_grads_list = [], []

        self.rolling_r = utils.RunningStats()
        self.LSTM_STATE = None
        self.VAE_LSTM_STATE = None
        reset_lstm = True
        while True:
            if ray.get(eds.get_size.remote()) >= self.Parameter.HyperparameterConfig.BATCH_SIZE:
                for _ in range(self.Parameter.HyperparameterConfig.BATCH_SIZE):
                    self.localQueue.append(ray.get(eds.get_params.remote()))
                t0 = time.time()


                for i in range(self.Parameter.HyperparameterConfig.BATCH_SIZE):
                    lstm_ignore = False
                    # Extract Environment Data from the Queue in MiniBatches
                    EnvResponse = self.localQueue.pop(index = 0)
                    StateBatch = [item[0] for item in EnvResponse]
                    RewardBatch = [item[1] for item in EnvResponse]
                    RewardBatch = np.vstack(RewardBatch)
                    #ReturnBatch = self._calculateReturn(RewardBatch, StateBatch)
                    TerminateBatch = [item[2] for item in EnvResponse]
                    ActionBatch = [item[3] for item in EnvResponse]

                    self.RunnerEpisode = [item[4] for item in EnvResponse][0]
                    ValueBatch = [item[5] for item in EnvResponse]
                    SpeedBatch = [item[6] for item in EnvResponse]  # [:-1]
                    self.RunnerID = [item[7] for item in EnvResponse][0]

                    # Tensorflow Reshaping

                    StateBatch = np.asarray(StateBatch)
                    SpeedBatch = np.vstack(SpeedBatch)
                    TerminateBatch = np.vstack(TerminateBatch)

                    terminate_state = TerminateBatch[-1]

                    if reset_lstm:
                        print("NEW BATCH : GET LSTM ZERO STATE")
                        self.LSTM_STATE = self.Session.run(
                            self.RapidPrototype.spe_lstm.zero_state(batch_size=1,dtype=tf.float32))

                        self.VAE_LSTM_STATE = self.Session.run(self.RapidPrototype.VAE_LSTM_INIT_STATE)
                        reset_lstm = False

                    if terminate_state:
                        reset_lstm = True
                        print("terminate_batch {}".format(terminate_state))

                    #print("LSTM BATCH : {}".format(lstm_batch_size))

                    #print("LSTM_STATE Shape {}".format(np.array(self.LSTM_STATE).shape))
                    # print(LSTM_STATE)
                    # Optimize the Network
                    # Calculate the Monte Carlo Return and the Advantage
                    #print("Terminate Batch \n{}".format(TerminateBatch))


                    ###GET LSTM ZERO STATE #####

                    lstm_batch_size = 1  # SpeedBatch[-1].shape[0]

                    if reset_lstm:
                        print("NEW BATCH : GET LSTM ZERO STATE")
                        self.LSTM_STATE = self.Session.run(
                            self.RapidPrototype.spe_lstm.zero_state(batch_size=1, dtype=tf.float32))

                        self.VAE_LSTM_STATE = self.Session.run(self.RapidPrototype.VAE_LSTM_INIT_STATE)
                        reset_lstm = False



                    x = self._run_train_ops(StateBatch,SpeedBatch, RewardBatch)


                    self.writer.add_summary(x[0], global_step=self.UpdateStep)

                    self.speloss = x[1]
                    self.spe2loss = x[2]
                    self.retloss = x[3]
                    self.ret2loss = x[4]

                    self.VAEloss = x[5]
                    self.spe3loss = x[6]
                    self.LSTM_STATE = x[7]
                    self.VAE_LSTM_STATE = x[8]
                    self._writeLogData()

                    self.UpdateStep += 1


                t1 = time.time()
                total = t1 - t0
                # Save the optmized Network for every Runner to pull
                self.RapidPrototype.RPsaver.save(self.Session, save_path=LOG_DIR + "/SaveData/test")

                print("Optimized in ", total, "seconds and Graph has new parameters")
                if self.Parameter.ModelConfig.CLEAR_PS_AFTER_OPT == True:
                    time.sleep(0.1)
                    ray.get(eds.clear_all_params.remote())
                else:
                    if ray.get(eds.get_size.remote()) > 100000:
                        time.sleep(0.1)
                        ray.get(eds.clear_all_params.remote())

            else:
                time.sleep(0.1)

    def _initialize(self, LOG_DIR ):
        self.UpdateStep = 0
        self.log = LOG_DIR
        self.logParams = {}
        self.Session = tf.Session()

        name = "RapidPrototype"
        with tf.variable_scope(name):
            self.RapidPrototype = RapidPrototype.RapidPrototype(name, self.state_dim, LOG_DIR)

        self.Session.run(tf.global_variables_initializer())
        self.localQueue = []
        self.merged_summary = tf.summary.merge_all()
        self.writer = tf.summary.FileWriter(LOG_DIR, self.Session.graph)
        self.Parameter = XMLReader.XMLReader(LOG_DIR + "/Hyperparameter.xml")

    def _start_session(self):
        return tf.Session()

    def _calculateReturn(self, RewardBatch, StateBatch, SpeedBatch=None, SteeringBatch=None, GyroBatch=None):
        ReturnBatch = []  # compute discounted reward
        if self.Parameter.ModelConfig.CONCAT:
            v_s = self._getValueFunction(StateBatch[-1], SpeedBatch[-1], SteeringBatch[-1], GyroBatch[-1])[0][0]
        else:
            v_s = self._getValueFunction(StateBatch[-1], SteeringBatch, GyroBatch)[0][0]
        for r in RewardBatch[::-1]:
            v_s = r + self.Parameter.HyperparameterConfig.GAMMA * v_s
            ReturnBatch.append(v_s)
        ReturnBatch.reverse()
        if self.Parameter.ModelConfig.RETURN_NORM:
            ReturnBatch -= np.mean(ReturnBatch)
            ReturnBatch /= (np.std(ReturnBatch) + 1e-8)
        return ReturnBatch