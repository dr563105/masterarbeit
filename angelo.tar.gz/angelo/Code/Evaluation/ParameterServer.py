import ray
import os
import psutil
@ray.remote#(memory = 5 *1024*1024*1024, object_store_memory = 5 *1024*1024*1024)
class DataServer:
	def __init__(self):
		self.list =[]
		print("Queue created")

	def get_params(self):
		if(not len(self.list)==0):
			return self.list.pop(0)

	def put_params(self,data):
		self.list.append(data)
		return True

	def is_empty(self):
		return True if not len(self.list)==0 else False

	def get_size(self):
		return len(self.list)

	def clear_all_params(self):
		self.list = []
		return True

	def get_memory_usage(self):
		process = psutil.Process(os.getpid())
		return process.memory_info().rss / 1000000

	def shutdown_server(self):
		print("paramete server sagt goodbye")
		ray.shutdown()