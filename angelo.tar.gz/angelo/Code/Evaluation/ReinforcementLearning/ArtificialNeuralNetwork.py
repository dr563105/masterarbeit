from Config import *

import numpy as np

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
tf.logging.set_verbosity(tf.logging.WARN)

import warnings

warnings.filterwarnings('ignore')

class ANN(object):
    def __init__(self,  kernel_initializer,Parameter,state_dim):
        self.Kernel_Initializer = kernel_initializer
        self.Parameter = Parameter
        self.state_dim = state_dim

    def _buildSharedNet(self, input,PHSpeed,PHSteering,PHGyro,trainable):
        with tf.variable_scope('SharedLayer'):
            cnn_layer = input
            if self.Parameter.ModelConfig.CONCAT:
                if self.Parameter.ModelConfig.CONCATNAME.find("Speed")!=-1:
                    #SpeedDim = tf.layers.dense(PHSpeed, 100, tf.nn.relu, name='conLF1c', kernel_initializer=self.Kernel_Initializer)
                    SpeedDim = tf.layers.dense(PHSpeed, self.state_dim[0]*self.state_dim[1], tf.nn.relu, name='conLF2c', kernel_initializer=self.Kernel_Initializer)
                    SpeedDim = tf.reshape(SpeedDim, [-1, self.state_dim[0], self.state_dim[1], 1])
                    cnn_layer = tf.concat(values=[cnn_layer, SpeedDim], axis=3)

                if self.Parameter.ModelConfig.CONCATNAME.find("Steering")!=-1:
                    #SteerDim = tf.layers.dense(PHSteering, 100, tf.nn.relu, name='conLF1d', kernel_initializer=self.Kernel_Initializer)
                    SteerDim = tf.layers.dense(PHSteering,  self.state_dim[0]*self.state_dim[1], tf.nn.relu, name='conLF2d', kernel_initializer=self.Kernel_Initializer)
                    SteerDim = tf.reshape(SteerDim, [-1, self.state_dim[0], self.state_dim[1], 1])
                    cnn_layer = tf.concat(values=[cnn_layer, SteerDim], axis=3)

                if self.Parameter.ModelConfig.CONCATNAME.find("Gyro")!=-1:
                    #GyroDim = tf.layers.dense(PHGyro, 100, tf.nn.relu, name='conLF1e',kernel_initializer=self.Kernel_Initializer)
                    GyroDim = tf.layers.dense(PHGyro, self.state_dim[0]*self.state_dim[1], tf.nn.relu, name='conLF2e', kernel_initializer=self.Kernel_Initializer)
                    GyroDim = tf.reshape(GyroDim, [-1, self.state_dim[0], self.state_dim[1], 1])
                    cnn_layer = tf.concat(values=[cnn_layer, GyroDim], axis=3)

            print(cnn_layer)
            for i in range(self.Parameter.NetworkConfig.SHARED_CNN_LAYERS):
                cnn_layer =tf.layers.conv2d(inputs=cnn_layer,
                                            filters=self.Parameter.NetworkConfig.SHARED_CNN_FILTERS[i],
                                            kernel_size=self.Parameter.NetworkConfig.SHARED_CNN_KERNEL_SIZE[i],
                                            strides=self.Parameter.NetworkConfig.SHARED_CNN_STRIDES[i],
                                            activation=tf.nn.relu,
                                            trainable=trainable,
                                            name = "_SharedCNNLayer_"+str(i),
                                            kernel_initializer = self.Kernel_Initializer
                                            )
        return cnn_layer


    def _buildActorNet(self, input, trainable=False, pdf ='normal',sigma0=None,sigma1=None,sigma2=None):
        with tf.variable_scope('ActorNet'):
            actor_layer =input
            for i in range (self.Parameter.NetworkConfig.ACTOR_CNN_LAYERS):
                actor_layer = tf.layers.conv2d(inputs=actor_layer,
                                             filters=self.Parameter.NetworkConfig.ACTOR_CNN_FILTERS[i],
                                             kernel_size=self.Parameter.NetworkConfig.ACTOR_CNN_KERNEL_SIZE[i],
                                             strides=self.Parameter.NetworkConfig.ACTOR_CNN_STRIDES[i],
                                             activation=tf.nn.relu,
                                             name="_ActorCNNLayer_" + str(i),
                                             kernel_initializer=self.Kernel_Initializer)
                print(actor_layer)
            actor_layer = tf.layers.flatten(actor_layer)
            for i in range(self.Parameter.NetworkConfig.ACTOR_FC_LAYERS):
                actor_layer = tf.layers.dense(actor_layer, self.Parameter.NetworkConfig.ACTOR_FC_UNITS[i], tf.nn.relu6,
                                                trainable=trainable, name='_ActorLayer'+str(i),
                                                kernel_initializer=self.Kernel_Initializer)
            if pdf == 'normal':
                if self.Parameter.EnvConfig.A_DIM==1:
                    dist1 = self._buildNormalDistribution(actor_layer, trainable,'_ActorNet',0,0.0,1.0,sigma0)
                elif self.Parameter.EnvConfig.A_DIM == 2:
                    dist1 = self._buildNormalDistribution(actor_layer, trainable,'_ActorNet',0,0.0,1.0,sigma0)
                    dist2 = self._buildNormalDistribution(actor_layer, trainable,'_ActorNet',1,0.0,1.0,sigma1)
                else:
                    dist1 = self._buildNormalDistribution(actor_layer, trainable,'_ActorNet',0,0.0,1.0,sigma0)
                    dist2 = self._buildNormalDistribution(actor_layer, trainable,'_ActorNet',1,1.0,0.5,sigma1)
                    dist3 = self._buildNormalDistribution(actor_layer, trainable,'_ActorNet',2,1.0,0.5,sigma2)
            elif pdf == 'beta':
                dist1 =self._buildBetaDistribution(actor_layer, trainable,'_ActorNet')
                #dist2 =self._buildBetaDistribution(actor_layer, trainable,'_ActorNet')
                #dist3 =self._buildBetaDistribution(actor_layer, trainable,'_ActorNet')
            else:
                print("please choose between normal and beta distribution")
                assert False
        if self.Parameter.EnvConfig.A_DIM ==1:
            return dist1
        elif self.Parameter.EnvConfig.A_DIM ==2:
            return dist1,dist2
        else:
            return dist1,dist2,dist3



    def _buildCriticNet(self, input,trainable = True):
        with tf.variable_scope('CriticNet'):

            critic_layer = input
            for i in range (self.Parameter.NetworkConfig.CRITIC_CNN_LAYERS):
                critic_layer = tf.layers.conv2d(inputs=critic_layer,
                                             filters=self.Parameter.NetworkConfig.CRITIC_CNN_FILTERS[i],
                                             kernel_size=self.Parameter.NetworkConfig.CRITIC_CNN_KERNEL_SIZE[i],
                                             strides=self.Parameter.NetworkConfig.CRITIC_CNN_STRIDES[i],
                                             activation=tf.nn.relu,
                                             trainable = trainable,
                                             name="_CriticCNNLayer_" + str(i),
                                             kernel_initializer=self.Kernel_Initializer)

            critic_layer = tf.layers.flatten(critic_layer)
            for i in range(self.Parameter.NetworkConfig.CRITIC_FC_LAYERS):
                critic_layer = tf.layers.dense(critic_layer, self.Parameter.NetworkConfig.CRITIC_FC_UNITS[i], tf.nn.relu6,
                                                name='_CriticLayer'+str(i),
                                               trainable=trainable,
                                               kernel_initializer=self.Kernel_Initializer)
            valueFunc = tf.layers.dense(critic_layer, 1, name='v',kernel_initializer = self.Kernel_Initializer)
        return valueFunc


    def _buildJoinedNet(self,input,PHSpeed,PHSteering,PHGyro,pdf= 'normal',trainable = True, BATCH_SIZE = None):
        with tf.variable_scope('JoinedNet'):

            vae_decoder_output = None
            vae_feature_extraction = None
            vae_mean = None
            vae_logvar = None
            vae_z = None

            if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:

                vae_decoder_output, vae_mean, vae_logvar, vae_z, vae_feature_extraction = self._build_VAE(net_input=input, BATCH_SIZE = BATCH_SIZE, PHSpeed = PHSpeed, PHSteering= PHSteering, PHGyro= PHGyro  )

                if self.Parameter.NetworkConfig.VAE_USE_MEAN_FOR_SHARED:

                    shared_layer = vae_mean
                elif self.Parameter.NetworkConfig.VAE_USE_LOGVAR_FOR_SHARED:
                    shared_layer = vae_mean + vae_logvar
                else:
                    shared_layer = vae_feature_extraction

                    if self.Parameter.ModelConfig.VAE_INBETWEEN_FUSION:

                        with tf.variable_scope('CONCAT'):

                            concat_dim = [shared_layer.shape[1], shared_layer.shape[2]]
                            if self.Parameter.ModelConfig.CONCATNAME.find("Speed") != -1:
                                SpeedDim = tf.layers.dense(PHSpeed, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                           name='conLF2c',
                                                           kernel_initializer=self.Kernel_Initializer)
                                SpeedDim = tf.reshape(SpeedDim, [-1, concat_dim[0], concat_dim[1], 1])
                                shared_layer = tf.concat(values=[shared_layer, SpeedDim], axis=3)

                            if self.Parameter.ModelConfig.CONCATNAME.find("Steering") != -1:
                                SteerDim = tf.layers.dense(PHSteering, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                           name='conLF2d', kernel_initializer=self.Kernel_Initializer)
                                SteerDim = tf.reshape(SteerDim, [-1, concat_dim[0], concat_dim[1], 1])
                                shared_layer = tf.concat(values=[shared_layer, SteerDim], axis=3)

                            if self.Parameter.ModelConfig.CONCATNAME.find("Gyro") != -1:
                                GyroDim = tf.layers.dense(PHGyro, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                          name='conLF2e',
                                                          kernel_initializer=self.Kernel_Initializer)
                                GyroDim = tf.reshape(GyroDim, [-1, concat_dim[0], concat_dim[1], 1])
                                shared_layer = tf.concat(values=[shared_layer, GyroDim], axis=3)


            else:
                shared_layer = self._buildSharedNet(input,PHSpeed,PHSteering,PHGyro,trainable=trainable)

            valueFunc= self._buildCriticNet(shared_layer)
            if self.Parameter.EnvConfig.A_DIM ==1:
                distribution1 = self._buildActorNet(shared_layer,trainable, pdf)
                return distribution1, valueFunc, shared_layer
            elif self.Parameter.EnvConfig.A_DIM==2:
                distribution1, distribution2 = self._buildActorNet(shared_layer, trainable, pdf)
                return distribution1, distribution2, valueFunc

            else:
                distribution1, distribution2, distribution3 = self._buildActorNet(shared_layer,trainable, pdf)
                return distribution1, distribution2, distribution3, valueFunc, vae_decoder_output, vae_mean, vae_logvar, vae_z



    def _buildNormalDistribution(self, actor_layer, trainable, scope,action_id, Offset=0.0, Multiplier = 1.0,sigmanew=None):
        with tf.variable_scope(scope+'_Distribution'):
            for i in range(self.Parameter.NetworkConfig.ACTION_FC_LAYERS):
                actor_layer = tf.layers.dense(actor_layer, self.Parameter.NetworkConfig.ACTION_FC_UNITS[i], tf.nn.relu6,
                                              trainable=trainable, name='_Action_Layer'+str(action_id)+"_" + str(i),
                                              kernel_initializer=self.Kernel_Initializer)
            mu = tf.layers.dense(actor_layer,1, tf.nn.tanh, trainable=trainable, name='mu_'+str(action_id),
                                 kernel_initializer=self.Kernel_Initializer)
            sigma = tf.layers.dense(actor_layer, 1, tf.nn.softplus, trainable=trainable, name='sigma_' + str(action_id),
                                    kernel_initializer=self.Kernel_Initializer)
            if sigmanew != None:
                sigma = sigmanew
            tf.summary.scalar('sigma'+str(action_id), tf.reduce_mean(sigma))
            mu = tf.add(mu, Offset)
            mu = tf.multiply(mu, Multiplier)
            norm_dist = tf.distributions.Normal(loc=mu, scale=sigma)
        return norm_dist


    def _buildBetaDistribution(self, actor_layer, trainable, scope):
        with tf.variable_scope(scope+'_Distribution'):
            alpha = tf.layers.dense(actor_layer, self.Parameter.EnvConfig.A_DIM, tf.nn.softplus, trainable=trainable, name='alpha',
                                 kernel_initializer=self.Kernel_Initializer)
            beta = tf.layers.dense(actor_layer, self.Parameter.EnvConfig.A_DIM, tf.nn.softplus, trainable=trainable, name='beta',
                                    kernel_initializer=self.Kernel_Initializer)
            tf.summary.scalar('alpha', tf.reduce_mean(alpha))
            tf.summary.scalar('beta', tf.reduce_mean(beta))
            beta_dist = tf.distributions.Beta(concentration0=alpha, concentration1=beta)
        return beta_dist

    def _build_VAE(self, net_input, BATCH_SIZE, PHSpeed = None, PHSteering = None, PHGyro = None ):


        nn = net_input

        with tf.variable_scope("VAE"):
            with tf.variable_scope('Encoder'):
                with tf.variable_scope('FeatureExtraction'):
                    with tf.variable_scope('Shared'):
                        if self.Parameter.ModelConfig.VAE_EARLY_FUSION:

                                    concat_dim = [nn.shape[1], nn.shape[2]]
                                    if self.Parameter.ModelConfig.CONCATNAME.find("Speed") != -1:
                                        SpeedDim = tf.layers.dense(PHSpeed, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                                   name='conLF2c',
                                                                   kernel_initializer=self.Kernel_Initializer)
                                        SpeedDim = tf.reshape(SpeedDim, [-1, concat_dim[0], concat_dim[1], 1])
                                        nn = tf.concat(values=[nn, SpeedDim], axis=3)

                                    if self.Parameter.ModelConfig.CONCATNAME.find("Steering") != -1:
                                        SteerDim = tf.layers.dense(PHSteering, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                                   name='conLF2d',
                                                                   kernel_initializer=self.Kernel_Initializer)
                                        SteerDim = tf.reshape(SteerDim, [-1, concat_dim[0], concat_dim[1], 1])
                                        nn = tf.concat(values=[nn, SteerDim], axis=3)

                                    if self.Parameter.ModelConfig.CONCATNAME.find("Gyro") != -1:
                                        GyroDim = tf.layers.dense(PHGyro, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                                  name='conLF2e',
                                                                  kernel_initializer=self.Kernel_Initializer)
                                        GyroDim = tf.reshape(GyroDim, [-1, concat_dim[0], concat_dim[1], 1])
                                        nn = tf.concat(values=[nn, GyroDim], axis=3)

                        for i in range(self.Parameter.NetworkConfig.GET_FEATURE_MAP_LAYER):
                            nn = tf.layers.conv2d(inputs=nn,
                                              filters=self.Parameter.NetworkConfig.VAE_CNN_FILTERS[i],
                                              kernel_size=self.Parameter.NetworkConfig.VAE_CNN_KERNEL_SIZE[i],
                                              strides=self.Parameter.NetworkConfig.VAE_CNN_STRIDES[i],
                                              dilation_rate = self.Parameter.NetworkConfig.VAE_CNN_DILATION_RATE[i],
                                              activation=tf.nn.relu,
                                              padding = self.Parameter.NetworkConfig.VAE_CNN_PADDING[i],
                                              kernel_initializer=self.Kernel_Initializer,
                                            name = "ConvLayer{}".format(i))
                        shared_feature_maps = nn


                    for i in range(self.Parameter.NetworkConfig.GET_FEATURE_MAP_LAYER, self.Parameter.NetworkConfig.VAE_CNN_LAYERS):
                        nn = tf.layers.conv2d(inputs=nn,
                                          filters=self.Parameter.NetworkConfig.VAE_CNN_FILTERS[i],
                                          kernel_size=self.Parameter.NetworkConfig.VAE_CNN_KERNEL_SIZE[i],
                                          strides=self.Parameter.NetworkConfig.VAE_CNN_STRIDES[i],
                                          dilation_rate = self.Parameter.NetworkConfig.VAE_CNN_DILATION_RATE[i],
                                          activation=tf.nn.relu,
                                          padding = self.Parameter.NetworkConfig.VAE_CNN_PADDING[i],
                                          kernel_initializer=self.Kernel_Initializer,
                                        name = "ConvLayer{}".format(i))

                        print("\nEncoder Layer {}: \n{}\n".format(i,nn))



                    vae_feature_extraction = nn





                nn = tf.layers.flatten(nn)

                mean = tf.layers.dense(nn,
                                       units=self.Parameter.NetworkConfig.VAE_LATENT_DIM,
                                       kernel_initializer=self.Kernel_Initializer,
                                       name='Mean')

                logvar = tf.layers.dense(nn,
                                         units=self.Parameter.NetworkConfig.VAE_LATENT_DIM,
                                         kernel_initializer=self.Kernel_Initializer,
                                         name='Logvar')



            with tf.variable_scope("Reparameterize"):
                # reparameterize
                eps = tf.random.normal(shape=(BATCH_SIZE, self.Parameter.NetworkConfig.VAE_LATENT_DIM))
                z = eps * tf.exp(logvar * .5) + mean

            with tf.variable_scope('Decoder'):
                #nn = tf.layers.dense(z, units=self.Parameter.NetworkConfig.VAE_LATENT_DIM * self.Parameter.NetworkConfig.VAE_LATENT_DIM * 64,
                #					 name='Dense_Layer_1',
                #					 kernel_initializer=self.Kernel_Initializer)

                nn = tf.layers.dense(z,
                                     units=vae_feature_extraction.shape[1] * vae_feature_extraction.shape[2] * vae_feature_extraction.shape[3],
                                     name='Dense_Layer_1',
                                     kernel_initializer=self.Kernel_Initializer)

                nn = tf.reshape(nn, [BATCH_SIZE, vae_feature_extraction.shape[1] , vae_feature_extraction.shape[2] , vae_feature_extraction.shape[3]])

                print("\nDecoder Reshaped: \n{}\n".format(nn))

                for i in range(self.Parameter.NetworkConfig.VAE_CNN_DECODER_LAYERS):
                    nn = tf.layers.conv2d_transpose(inputs=nn,
                                          filters=self.Parameter.NetworkConfig.VAE_CNN_DECODER_FILTERS[i],
                                          kernel_size=self.Parameter.NetworkConfig.VAE_CNN_DECODER_KERNEL_SIZE[i],
                                          strides=self.Parameter.NetworkConfig.VAE_CNN_DECODER_STRIDES[i],
                                          activation=tf.nn.relu,
                                          padding = self.Parameter.NetworkConfig.VAE_CNN_DECODER_PADDING[i],
                                          kernel_initializer=self.Kernel_Initializer)
                    print("\nDecoder Layer {}: \n{}\n".format(i,nn))


                if self.Parameter.ModelConfig.VAE_EARLY_FUSION:
                    output_filters = 6
                else:
                    output_filters = 3


                nn = tf.layers.conv2d_transpose(inputs=nn,
                                                filters=output_filters,
                                                kernel_size=3,
                                                strides=1,
                                                #activation=tf.nn.relu,
                                                padding="same",
                                                kernel_initializer=self.Kernel_Initializer)

                print("\nDecoder Output Layer :\n{}\n".format( nn))
                #assert(False)

                decoder_out = tf.math.tanh(nn)

        return decoder_out , mean, logvar , z , shared_feature_maps


    def _vae_compute_loss(self, decoder, image_label, mean, logvar, z, PHSpeed = None, PHSteering = None, PHGyro = None):

        nn = image_label


        if self.Parameter.ModelConfig.VAE_EARLY_FUSION:

            concat_dim = [image_label.shape[1], image_label.shape[2]]

            if self.Parameter.ModelConfig.CONCATNAME.find("Speed") != -1:
                SpeedDim = tf.tile(PHSpeed, [1,concat_dim[0]*concat_dim[1] ]  )
                SpeedDim = tf.reshape(SpeedDim ,shape=[tf.shape(image_label)[0], concat_dim[0] , concat_dim[1]])
                SpeedDim = tf.expand_dims(SpeedDim, axis = -1)
                nn = tf.concat(values=[nn, SpeedDim], axis=3)

            if self.Parameter.ModelConfig.CONCATNAME.find("Steering") != -1:
                SteerDim = tf.tile(PHSteering,[1,concat_dim[0]*concat_dim[1] ]  )
                SteerDim = tf.reshape(SteerDim ,shape=[tf.shape(image_label)[0], concat_dim[0] , concat_dim[1]])
                SteerDim = tf.expand_dims(SteerDim, axis = -1)
                nn = tf.concat(values=[nn, SteerDim], axis=3)

            if self.Parameter.ModelConfig.CONCATNAME.find("Gyro") != -1:
                GyroDim = tf.tile(PHGyro,[1,concat_dim[0]*concat_dim[1] ] )
                GyroDim = tf.reshape(GyroDim ,shape=[tf.shape(image_label)[0], concat_dim[0] , concat_dim[1]])
                GyroDim = tf.expand_dims(GyroDim, axis = -1)
                nn = tf.concat(values=[nn, GyroDim], axis=3)


        def log_normal_pdf(sample, mean, logvar, raxis=1):
            log2pi = tf.math.log(2. * np.pi)
            return tf.reduce_sum(-.5 * ((sample - mean) ** 2. * tf.exp(-logvar) + logvar + log2pi), axis=raxis)

        logits_flat = tf.layers.flatten(decoder)
        labels_flat = tf.layers.flatten(nn)
        print(logits_flat)
        print(labels_flat)

        # mse
        recon_loss = tf.math.pow(tf.subtract(labels_flat, logits_flat), 2)

        print("reconstruction_loss : {}".format(recon_loss))

        print(tf.shape(recon_loss))
        print(recon_loss)

        logpx_z = tf.reduce_sum(recon_loss, axis=1)
        # logpx_z = tf.reduce_mean(recon_loss, axis=1)

        reconstruction_loss = logpx_z
        print("logpx_loss : {}".format(logpx_z))
        log_P = log_normal_pdf(z, 0., 1.)
        log_Q = log_normal_pdf(z, mean, logvar)
        print("logqx_loss : {}".format(log_Q))
        # self.kl_loss = -tf.reduce_sum(logpz- logqz_x )
        kl_loss = -(log_P - log_Q)
        print("kl_loss{}".format(kl_loss))
        elbo_loss = tf.reduce_mean(logpx_z + kl_loss)

        # loss_summary = tf.summary.scalar("loss", elbo_loss)
        # tf_summaries.append(loss_summary)
        return reconstruction_loss, kl_loss, elbo_loss