from itertools import starmap

import tensorflow as tf
from ReinforcementLearning import ArtificialNeuralNetwork

from Utils import XMLReader
from Config import *

import numpy as np

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import warnings

warnings.filterwarnings('ignore')
class PPO(object):
    def __init__(self, name, state_dim,LOG_DIR):
        self.Parameter = XMLReader.XMLReader(LOG_DIR+"/Hyperparameter.xml")
        with tf.variable_scope(name):

            #Placeholder
            self.PHstate = tf.placeholder(tf.float32, [None] + list(state_dim), 'State')

            self.PHstate_diff = tf.placeholder(tf.float32, [None] + list(state_dim), 'Diff_State')

            self.PHSpeed = tf.placeholder(tf.float32, [None, 1], 'PHSpeed')
            self.PHSteering = tf.placeholder(tf.float32, [None, 1], 'PHSteering')
            self.PHGyro = tf.placeholder(tf.float32, [None, 1], 'PHGyro')
            self.VAE_BATCH_SIZE = tf.placeholder(shape=(), dtype=tf.int32 , name ="VAE_BATCH_SIZE")
            self.apply_vae_gradients = None

            if self.Parameter.EnvConfig.A_DIM==1:
                self.PHaction0 = tf.placeholder(tf.float32, [None, 1], 'Action0')
                tf.summary.histogram("Steering", self.PHaction0)
            if self.Parameter.EnvConfig.A_DIM==2:
                self.PHaction0 = tf.placeholder(tf.float32, [None, 1], 'Action0')
                tf.summary.histogram("Steering", self.PHaction0)
                self.PHaction1 = tf.placeholder(tf.float32, [None, 1], 'Action1')
                tf.summary.histogram("GasAndBrake", self.PHaction1)

            if self.Parameter.EnvConfig.A_DIM==3:
                self.PHaction0 = tf.placeholder(tf.float32, [None, 1], 'Action0')
                tf.summary.histogram("Steering", self.PHaction0)
                self.PHaction1 = tf.placeholder(tf.float32, [None, 1], 'Action1')
                tf.summary.histogram("Gas", self.PHaction1)
                self.PHaction2 = tf.placeholder(tf.float32, [None, 1], 'Action2')
                tf.summary.histogram("Brake", self.PHaction2)


            self.PHadvantage =tf.placeholder(tf.float32, [None, 1], 'Advantage')
            tf.summary.scalar("Advantage", tf.reduce_mean(self.PHadvantage))
            self.PHreturn = tf.placeholder(tf.float32, [None, 1], 'DiscountedReward')
            tf.summary.scalar("Return", tf.reduce_sum(self.PHreturn))
            self.global_step = tf.train.get_or_create_global_step()

            self.aloss_total = None
            self.closs = None

            with tf.variable_scope("Learning_Rate"):

                self.learning_rate_Actor = tf.train.exponential_decay(self.Parameter.HyperparameterConfig.A_LR, self.global_step,
                                                                      decay_steps=self.Parameter.HyperparameterConfig.DECAY_STEP,
                                                                      decay_rate=self.Parameter.HyperparameterConfig.DECAY_RATE,
                                                                      staircase=self.Parameter.HyperparameterConfig.DECAY_STAIRCASE)
                self.learning_rate_Critic = tf.train.exponential_decay(self.Parameter.HyperparameterConfig.C_LR, self.global_step,
                                                                       decay_steps=self.Parameter.HyperparameterConfig.DECAY_STEP,
                                                                       decay_rate=self.Parameter.HyperparameterConfig.DECAY_RATE,
                                                                       staircase=self.Parameter.HyperparameterConfig.DECAY_STAIRCASE)

                self.learning_rate_VAE = tf.train.exponential_decay(self.Parameter.HyperparameterConfig.VAE_LR, self.global_step,
                                                                       decay_steps=self.Parameter.HyperparameterConfig.DECAY_STEP,
                                                                       decay_rate=self.Parameter.HyperparameterConfig.DECAY_RATE,
                                                                       staircase=self.Parameter.HyperparameterConfig.DECAY_STAIRCASE)
                tf.summary.scalar("learning_rate_Actor", self.learning_rate_Actor)
                tf.summary.scalar("learning_rate_Critic", self.learning_rate_Critic)
                tf.summary.scalar("learning_rate_VAE", self.learning_rate_VAE)

            self.OPT_A = tf.train.AdamOptimizer(self.learning_rate_Actor, name='AdamOptActor')
            self.OPT_C = tf.train.AdamOptimizer(self.learning_rate_Critic, name='AdamOptCritic')
            self.OPT_VAE = tf.train.AdamOptimizer(self.learning_rate_VAE, name='AdamOptVAE')

            if self.Parameter.HyperparameterConfig.INITIALIZER =="default":
                kernel_initializer = self._get_glorot_uniformInitializer()
            elif self.Parameter.HyperparameterConfig.INITIALIZER =="he_normal":
                kernel_initializer = self._get_he_normalInitializer()
            else:
                print("Please choose between default and he_normal for the INITIALIZER")
                assert False
            #Define Network self.Parameter
            ANN = ArtificialNeuralNetwork.ANN(
                kernel_initializer=kernel_initializer,
                Parameter=self.Parameter,
                state_dim =state_dim
            )

            if self.Parameter.EnvConfig.A_DIM==1:
                self.distribution0, self.valueFunc, self.last_shared_layer = ANN._buildJoinedNet(self.PHstate,self.PHSpeed,self.PHSteering,self.PHGyro , BATCH_SIZE=self.VAE_BATCH_SIZE)

            elif self.Parameter.EnvConfig.A_DIM==2:
                self.distribution0, self.distribution1,self.valueFunc = ANN._buildJoinedNet(self.PHstate,self.PHSpeed,self.PHSteering,self.PHGyro, BATCH_SIZE=self.VAE_BATCH_SIZE)

            else:
                self.distribution0, self.distribution1, self.distribution2,self.valueFunc, self.vae_decoder_output, self.vae_mean, self.vae_logvar, self.vae_z = ANN._buildJoinedNet(self.PHstate,self.PHSpeed,self.PHSteering,self.PHGyro, BATCH_SIZE=self.VAE_BATCH_SIZE)


            #Defining the parameteres that has to be optimized
            self.critic_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+'/JoinedNet'+'/CriticNet')
            self.actor_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+'/JoinedNet'+'/ActorNet')
            self.shared_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+'/JoinedNet'+'/SharedLayer')
            self.vae_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+'/JoinedNet'+'/VAE')

            if self.Parameter.NetworkConfig.VAE_USE_MEAN_FOR_SHARED:
                self.vae_shared_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + '/JoinedNet' + '/VAE/Encoder')

            else:
                self.vae_shared_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + '/JoinedNet' + '/VAE/Encoder/FeatureExtraction/Shared')

                if self.Parameter.ModelConfig.CONCAT:
                    if self.Parameter.ModelConfig.VAE_INBETWEEN_FUSION:
                        self.concat_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + '/JoinedNet' + '/CONCAT')
                    #self.vae_shared_params = self.vae_shared_params + self.concat_params

            if not self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:
                if self.Parameter.ModelConfig.CONCAT:
                    cnn_layer = self.PHstate

                    with tf.variable_scope('CONCAT'):
                        if self.Parameter.ModelConfig.CONCATNAME.find("Speed") != -1:
                            # SpeedDim = tf.layers.dense(PHSpeed, 100, tf.nn.relu, name='conLF1c', kernel_initializer=self.Kernel_Initializer)
                            SpeedDim = tf.layers.dense(self.PHSpeed, state_dim[0] * state_dim[1], tf.nn.relu,
                                                       name='conLF2c',
                                                       kernel_initializer=kernel_initializer)
                            SpeedDim = tf.reshape(SpeedDim, [-1, state_dim[0], state_dim[1], 1])
                            cnn_layer = tf.concat(values=[cnn_layer, SpeedDim], axis=3)

                        if self.Parameter.ModelConfig.CONCATNAME.find("Steering") != -1:
                            # SteerDim = tf.layers.dense(PHSteering, 100, tf.nn.relu, name='conLF1d', kernel_initializer=self.Kernel_Initializer)
                            SteerDim = tf.layers.dense(self.PHSteering, state_dim[0] * state_dim[1], tf.nn.relu,
                                                       name='conLF2d', kernel_initializer=kernel_initializer)
                            SteerDim = tf.reshape(SteerDim, [-1, state_dim[0], state_dim[1], 1])
                            cnn_layer = tf.concat(values=[cnn_layer, SteerDim], axis=3)

                        if self.Parameter.ModelConfig.CONCATNAME.find("Gyro") != -1:
                            # GyroDim = tf.layers.dense(PHGyro, 100, tf.nn.relu, name='conLF1e',kernel_initializer=self.Kernel_Initializer)
                            GyroDim = tf.layers.dense(self.PHGyro, state_dim[0] * state_dim[1], tf.nn.relu, name='conLF2e',
                                                      kernel_initializer=kernel_initializer)
                            GyroDim = tf.reshape(GyroDim, [-1, state_dim[0], state_dim[1], 1])
                            cnn_layer = tf.concat(values=[cnn_layer, GyroDim], axis=3)

                        self.net_input = cnn_layer



                else:
                    self.net_input = self.PHstate

            else:
                self.net_input = self.PHstate


            if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:
                self.pi = self.actor_params

                if self.Parameter.ModelConfig.CONCAT:
                    if self.Parameter.ModelConfig.VAE_INBETWEEN_FUSION:

                        self.pi =self.pi + self.concat_params

                self.pi = self.pi + self.vae_shared_params

            else:
                self.pi = self.actor_params+ self.shared_params

            with tf.variable_scope("OldPi"):

                if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:

                    _,self.vae_old_mean, self.vae_old_logvar, _, self.vae_old_feature_extraction = ANN._build_VAE(net_input= self.net_input, BATCH_SIZE= self.VAE_BATCH_SIZE, PHSpeed = self.PHSpeed, PHSteering= self.PHSteering, PHGyro= self.PHGyro )

                    if self.Parameter.NetworkConfig.VAE_USE_MEAN_FOR_SHARED and not self.Parameter.NetworkConfig.VAE_USE_LOGVAR_FOR_SHARED:
                        old_shared_last_layer = self.vae_old_mean

                    elif self.Parameter.NetworkConfig.VAE_USE_MEAN_FOR_SHARED and self.Parameter.NetworkConfig.VAE_USE_LOGVAR_FOR_SHARED:
                        old_shared_last_layer = self.vae_old_mean + self.vae_old_logvar
                    else:
                        old_shared_last_layer =  self.vae_old_feature_extraction

                        if self.Parameter.ModelConfig.VAE_INBETWEEN_FUSION:

                            with tf.variable_scope('CONCAT'):

                                concat_dim =  [old_shared_last_layer.shape[1],old_shared_last_layer.shape[2]]
                                if self.Parameter.ModelConfig.CONCATNAME.find("Speed") != -1:
                                    SpeedDim = tf.layers.dense(self.PHSpeed, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                               name='conLF2c',
                                                               kernel_initializer=kernel_initializer)
                                    SpeedDim = tf.reshape(SpeedDim, [-1, concat_dim[0], concat_dim[1], 1])
                                    old_shared_last_layer = tf.concat(values=[old_shared_last_layer, SpeedDim], axis=3)

                                if self.Parameter.ModelConfig.CONCATNAME.find("Steering") != -1:
                                    SteerDim = tf.layers.dense(self.PHSteering, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                               name='conLF2d', kernel_initializer=kernel_initializer)
                                    SteerDim = tf.reshape(SteerDim, [-1, concat_dim[0], concat_dim[1], 1])
                                    old_shared_last_layer = tf.concat(values=[old_shared_last_layer, SteerDim], axis=3)

                                if self.Parameter.ModelConfig.CONCATNAME.find("Gyro") != -1:
                                    GyroDim = tf.layers.dense(self.PHGyro, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                              name='conLF2e',
                                                              kernel_initializer=kernel_initializer)
                                    GyroDim = tf.reshape(GyroDim, [-1, concat_dim[0], concat_dim[1], 1])
                                    old_shared_last_layer = tf.concat(values=[old_shared_last_layer, GyroDim], axis=3)

                else:
                    old_shared_last_layer= ANN._buildSharedNet(self.PHstate,self.PHSpeed,self.PHSteering,self.PHGyro,trainable=False)
                    #tf.summary.image("input", self.PHstate)

                if self.Parameter.EnvConfig.A_DIM==1:
                    if self.Parameter.ModelConfig.SIGMA_OLD_EQUALS_SIGMA_NEW:
                        self.old_distribution0 = ANN._buildActorNet(old_shared_last_layer,trainable=False,
                                                               sigma0=self.distribution0.scale)
                    else:
                        self.old_distribution0 = ANN._buildActorNet(old_shared_last_layer, trainable=False)

                        self.get_mu0 = self.old_distribution0.loc[0]
                        self.sample_op0 = tf.squeeze(self.old_distribution0.sample(1), axis=0)[0]  # operation of choosing action
                elif self.Parameter.EnvConfig.A_DIM==2:
                    if self.Parameter.ModelConfig.SIGMA_OLD_EQUALS_SIGMA_NEW:
                        self.old_distribution0,self.old_distribution1 = ANN._buildActorNet(old_shared_last_layer,trainable=False,
                                                                   sigma0=self.distribution0.scale,
                                                                   sigma1=self.distribution1.scale)
                    else:
                        self.old_distribution0,self.old_distribution1 = ANN._buildActorNet(old_shared_last_layer,trainable=False)

                        self.sample_op0 = tf.squeeze(self.old_distribution0.sample(1), axis=0)[
                            0]  # operation of choosing action
                        self.sample_op1 = tf.squeeze(self.old_distribution1.sample(1), axis=0)[
                            0]  # operation of choosing action
                        self.get_mu0 = self.old_distribution0.loc[0]
                        self.get_mu1 = self.old_distribution1.loc[0]
                else:
                    if self.Parameter.ModelConfig.SIGMA_OLD_EQUALS_SIGMA_NEW:
                        self.old_distribution0, self.old_distribution1, self.old_distribution2 = ANN._buildActorNet(old_shared_last_layer,trainable=False,
                                                                   sigma0=self.distribution0.scale,
                                                                   sigma1=self.distribution1.scale,
                                                                   sigma2=self.distribution2.scale)
                    else:
                        self.old_distribution0, self.old_distribution1, self.old_distribution2 = ANN._buildActorNet(old_shared_last_layer,trainable=False)

                        self.sample_op0 = tf.squeeze(self.old_distribution0.sample(1), axis=0)[
                            0]  # operation of choosing action
                        self.sample_op1 = tf.squeeze(self.old_distribution1.sample(1), axis=0)[
                            0]  # operation of choosing action
                        self.sample_op2 = tf.squeeze(self.old_distribution2.sample(1), axis=0)[
                            0]  # operation of choosing action
                        self.get_mu0 = self.old_distribution0.loc[0]
                        self.get_mu1 = self.old_distribution1.loc[0]
                        self.get_mu2 = self.old_distribution2.loc[0]


            self.old_shared_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+"/OldPi"+'/SharedLayer')

            self.old_actor_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+"/OldPi"+'/ActorNet')

            #if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:
            #    if self.Parameter.NetworkConfig.VAE_USE_MEAN_FOR_SHARED:
            #        self.vae_old_shared_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/OldPi" + "/VAE/Encoder")
    #
            #    else:
            #        self.vae_old_shared_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+ '/OldPi' + '/VAE/Encoder/FeatureExtraction/Shared')
    #
            #        if self.Parameter.ModelConfig.CONCAT:
            #            if self.Parameter.ModelConfig.VAE_INBETWEEN_FUSION:
            #                self.old_concat_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/OldPi" + "/CONCAT")
                    #self.vae_old_shared_params = self.vae_old_shared_params + self.old_concat_params


            if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:

                if self.Parameter.NetworkConfig.VAE_USE_MEAN_FOR_SHARED:
                    self.vae_old_shared_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES,
                                                                   scope=name + "/OldPi" + "/VAE/Encoder")

                else:
                    self.vae_old_shared_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES,
                                                                   scope=name + '/OldPi' + '/VAE/Encoder/FeatureExtraction/Shared')

                    if self.Parameter.ModelConfig.CONCAT:
                        if self.Parameter.ModelConfig.VAE_INBETWEEN_FUSION:
                            self.old_concat_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES,
                                                                       scope=name + "/OldPi" + "/CONCAT")

                self.old_pi = self.old_actor_params

                if self.Parameter.ModelConfig.CONCAT:
                    if self.Parameter.ModelConfig.VAE_INBETWEEN_FUSION:
                        self.old_pi = self.old_pi + self.old_concat_params

                self.old_pi = self.old_pi + self.vae_old_shared_params

            else:
                self.old_pi = self.old_actor_params + self.old_shared_params

            if self.Parameter.ModelConfig.VALUE_CLIPPING:
                with tf.variable_scope("OldC"):
                    old_value_func = ANN._buildCriticNet(old_shared_last_layer,trainable = False)
                self.critic_old_params=tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+"/OldC"+'/CriticNet')

            with tf.variable_scope("ActorLoss"):

                ratio0 = self.distribution0.prob(self.PHaction0) / (self.old_distribution0.prob(self.PHaction0) + 1e-9)
                surr0_1 = ratio0 * tf.stop_gradient(self.PHadvantage)  # surrogate loss
                clip0 = tf.clip_by_value(
                    ratio0, 1. - self.Parameter.HyperparameterConfig.EPSILON, 1. + self.Parameter.HyperparameterConfig.EPSILON)
                tf.summary.scalar("clippedratio0", tf.reduce_mean(clip0))
                surr0_2 = clip0 * tf.stop_gradient(self.PHadvantage)
                self.aloss0 = -tf.reduce_mean(tf.minimum(surr0_1, surr0_2))
                tf.summary.scalar("a0loss", self.aloss0)
                self.aloss_total = self.aloss0

                if self.Parameter.EnvConfig.A_DIM ==2 or self.Parameter.EnvConfig.A_DIM ==3:
                    ratio1 = self.distribution1.prob(self.PHaction1) / (self.old_distribution1.prob(self.PHaction1) + 1e-5)
                    clip1 = tf.clip_by_value(
                        ratio1, 1. - self.Parameter.HyperparameterConfig.EPSILON, 1. + self.Parameter.HyperparameterConfig.EPSILON)
                    tf.summary.scalar("clippedratio1", tf.reduce_mean(clip1))
                    surr1_1 = ratio1 * tf.stop_gradient(self.PHadvantage)  # surrogate loss
                    surr1_2 = clip1 * tf.stop_gradient(self.PHadvantage)
                    self.aloss1 = -tf.reduce_mean(tf.minimum(surr1_1, surr1_2))
                    tf.summary.scalar("a1loss", self.aloss1)
                    self.aloss_total+=self.aloss1

                if self.Parameter.EnvConfig.A_DIM ==3:
                    ratio2 = self.distribution2.prob(self.PHaction2) / (self.old_distribution2.prob(self.PHaction2) + 1e-5)
                    clip2 = tf.clip_by_value(
                        ratio2, 1. - self.Parameter.HyperparameterConfig.EPSILON, 1. + self.Parameter.HyperparameterConfig.EPSILON)
                    tf.summary.scalar("clippedratio2", tf.reduce_mean(clip2))
                    surr2_1 = ratio2 * tf.stop_gradient(self.PHadvantage)  # surrogate loss
                    surr2_2 =  clip2 * tf.stop_gradient(self.PHadvantage)
                    self.aloss2 = -tf.reduce_mean(tf.minimum(surr2_1, surr2_2))
                    tf.summary.scalar("a2loss", self.aloss2)
                    self.aloss_total+=self.aloss2

            with tf.variable_scope("CriticLoss"):
                if self.Parameter.ModelConfig.VALUE_CLIPPING:
                    clipped_value_estimate = old_value_func + tf.clip_by_value(self.valueFunc - old_value_func,
                                                                               -self.Parameter.HyperparameterConfig.EPSILON,
                                                                               self.Parameter.HyperparameterConfig.EPSILON)
                    loss_vf1 = tf.squared_difference(clipped_value_estimate, self.PHreturn)
                    loss_vf2 = tf.squared_difference(self.valueFunc, self.PHreturn)
                    self.closs = tf.reduce_mean(tf.maximum(loss_vf1, loss_vf2)) * self.Parameter.HyperparameterConfig.VALUE_COEFF
                else:
                    self.advantage = self.PHreturn - self.valueFunc
                    self.closs = self.Parameter.HyperparameterConfig.VALUE_COEFF * tf.reduce_mean(tf.square(self.advantage))
                tf.summary.scalar("closs", self.closs)


            if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:
                with tf.variable_scope("VAELoss"):
                    self.vae_reconstruction_loss, self.vae_kl_loss, self.vae_loss = ANN._vae_compute_loss(decoder= self.vae_decoder_output, image_label=  self.net_input, mean = self.vae_mean, logvar = self.vae_logvar, z = self.vae_z,PHSpeed = self.PHSpeed, PHSteering= self.PHSteering, PHGyro= self.PHGyro)
                    tf.summary.scalar("vae_mse_loss", tf.reduce_mean(self.vae_reconstruction_loss))
                    tf.summary.scalar("vae_kl_loss", tf.reduce_mean(self.vae_kl_loss))
                    tf.summary.scalar("vae_loss", self.vae_loss)
                    tf.summary.image("input",  self.net_input)
                    tf.summary.image("reconstructions", self.vae_decoder_output[:, :, :, 0:3])


            with tf.variable_scope('entropy'):
                entropy0 = self.old_distribution0.entropy()
                self.pol_entpen0 = -self.Parameter.HyperparameterConfig.ENTROPY_BETA * tf.reduce_mean(entropy0)
                tf.summary.scalar("polentpen0", self.pol_entpen0)
                self.aloss_total += self.pol_entpen0

                if self.Parameter.EnvConfig.A_DIM ==2 or self.Parameter.EnvConfig.A_DIM ==3:
                    entropy1 = self.old_distribution1.entropy()
                    self.pol_entpen1 = -self.Parameter.HyperparameterConfig.ENTROPY_BETA  * tf.reduce_mean(entropy1)
                    tf.summary.scalar("polentpen1", self.pol_entpen1)
                    self.aloss_total += self.pol_entpen1

                if self.Parameter.EnvConfig.A_DIM==3:
                    entropy2 = self.old_distribution2.entropy()
                    self.pol_entpen2 = -self.Parameter.HyperparameterConfig.ENTROPY_BETA * tf.reduce_mean(entropy2)
                    tf.summary.scalar("polentpen2", self.pol_entpen2)
                    self.aloss_total += self.pol_entpen2

            tf.summary.scalar("aloss_total", self.aloss_total)


            with tf.variable_scope('GradientCalculation'):
                if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:

                    if self.Parameter.ModelConfig.CONCAT:
                        if self.Parameter.ModelConfig.VAE_INBETWEEN_FUSION:
                            self.actor_params += self.concat_params
                            self.critic_params += self.concat_params

                    if self.Parameter.ModelConfig.VAE_TRAIN_ADD_RL:
                        self.aloss_total = self.aloss_total
                        self.closs = self.closs

                        self.a_grads = tf.gradients(self.aloss_total, self.actor_params + self.vae_shared_params)
                        self.c_grads = tf.gradients(self.closs, self.critic_params + self.vae_shared_params)
                    else:
                        self.a_grads = tf.gradients(self.aloss_total, self.actor_params)
                        self.c_grads = tf.gradients(self.closs,self.critic_params)

                else:
                    self.a_grads = tf.gradients(self.aloss_total, self.actor_params + self.shared_params)
                    self.c_grads = tf.gradients(self.closs, self.critic_params + self.shared_params)

                print("a grads :")
                for v in self.a_grads:
                    print(v)

                print("c grads :")
                for v in self.c_grads:
                    print(v)

                if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:
                    self.vae_old_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES,
                                                               scope=name + '/OldPi' + '/VAE')
                                                               #scope='/OldPi' + '/VAE')

                    print("VAE PARAMS :")
                    for v in self.vae_params:
                        print(v)

                    self.vae_grads = tf.gradients(self.vae_loss, self.vae_params)

                    print("VAE GRADS : ")
                    for v in self.vae_grads:
                        print(v)
            #assert (False)
            self.placeholder_a_gradients = []
            for grad_var in self.a_grads:
                self.placeholder_a_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))
            self.placeholder_c_gradients = []
            for grad_var in self.c_grads:
                self.placeholder_c_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))

            if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:
                self.placeholder_vae_gradients = []
                for grad_var in self.vae_grads:
                    self.placeholder_vae_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))


            with tf.variable_scope('GradientPropagation'):

                if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:
                    if self.Parameter.ModelConfig.VAE_TRAIN_ADD_RL:

                        self.apply_a_gradients = self.OPT_A.apply_gradients(
                            zip(self.placeholder_a_gradients, self.actor_params + self.vae_shared_params),
                            global_step=self.global_step)
                        self.apply_c_gradients = self.OPT_C.apply_gradients(
                            zip(self.placeholder_c_gradients, self.critic_params + self.vae_shared_params))
                    else:
                        self.apply_a_gradients = self.OPT_A.apply_gradients(
                            zip(self.placeholder_a_gradients, self.actor_params),
                            global_step=self.global_step)
                        self.apply_c_gradients = self.OPT_C.apply_gradients(
                            zip(self.placeholder_c_gradients, self.critic_params))

                    self.apply_vae_gradients = self.OPT_VAE.apply_gradients(zip(self.placeholder_vae_gradients, self.vae_params))

                else:
                    self.apply_a_gradients = self.OPT_A.apply_gradients(
                        zip(self.placeholder_a_gradients, self.actor_params + self.shared_params),
                        global_step=self.global_step)
                    self.apply_c_gradients = self.OPT_C.apply_gradients(
                        zip(self.placeholder_c_gradients, self.critic_params + self.shared_params))

            #self.vae_train_op  = self.OPT_VAE.minimize(self.vae_loss)

            self.Assign_pi2old = [piold.assign(pi) for pi, piold in zip(self.pi, self.old_pi)]
            if self.Parameter.ModelConfig.VALUE_CLIPPING:
                self.Assign_critic2oldcritic = [criticold.assign(critic) for critic, criticold in zip(self.critic_params, self.critic_old_params)]

        self.NPsaver = tf.train.Saver()

        #print(vae_var_list)
        #assert(False)
        #
        if self.Parameter.ModelConfig.USE_VAE_AS_SHARED_NET:
            self.VAE_saver = tf.train.Saver(var_list = self.vae_params , filename= "VAE", max_to_keep = 10)

        self.actor_saver = tf.train.Saver(var_list=self.actor_params, filename="actor",  max_to_keep = 10)

        self.critic_saver = tf.train.Saver(var_list=self.critic_params, filename="critic",  max_to_keep = 10)

    def _get_he_normalInitializer(self):
        return tf.keras.initializers.he_normal()

    def _get_glorot_uniformInitializer(self):
        return tf.keras.initializers.glorot_uniform()








