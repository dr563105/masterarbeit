from itertools import starmap

import tensorflow as tf
from Metrics import ArtificialNeuralNetwork

from Utils import XMLReader
from Config import *

import numpy as np

class RapidPrototype():

	def __init__(self, name, state_dim, LOG_DIR):
		self.Parameter = XMLReader.XMLReader(LOG_DIR + "/Hyperparameter.xml")
		self.S_DIM = state_dim
		self.kernel_initializer = tf.keras.initializers.glorot_uniform()
		self.LSTM_UNITS = 100
		self.LSTM_LAYERS = 2
		self.LSTM_BATCH_SIZE = tf.placeholder(shape=(), dtype=tf.int32, name="lstm_batch_size")

		self.LSTM_INIT_STATE = tf.zeros(shape=(self.LSTM_LAYERS, 2, 1, self.LSTM_UNITS))
		l = tf.unstack(self.LSTM_INIT_STATE, axis=0)
		self.LSTM_INIT_STATE = tuple(
			[tf.nn.rnn_cell.LSTMStateTuple(l[idx][0], l[idx][1]) for idx in range(self.LSTM_LAYERS)])

		self.LSTM_FINAL_STATE = None
		self.LSTM_KEEP_PROB = tf.placeholder(tf.float32, name='dropout_keep_prob')
		self.VAE_LATENT_DIM = 25
		self.VAE_BATCH_SIZE = tf.placeholder(shape=(), dtype=tf.int32, name="vae_batch_size")
		#self.state_dim = state_dim

		#self.Parameter = Parameter()

		#self.learning_rate_Spe_ret = tf.train.exponential_decay(learning_rate=self.Parameter.HyperparameterConfig.C_LR,
		#														global_step=globalstep,
		#														decay_steps=self.Parameter.HyperparameterConfig.DECAY_STEP,
		#														decay_rate=self.Parameter.HyperparameterConfig.DECAY_RATE,
		#														staircase=self.Parameter.HyperparameterConfig.DECAY_STAIRCASE)
		self.ANN = ArtificialNeuralNetwork.ANN(Parameter=self.Parameter,
											   kernel_initializer=self._get_glorot_uniformInitializer(),
											   state_dim=self.S_DIM)

		self.tfdc_r = tf.placeholder(tf.float32, [None, 1], 'discounted_r')
		self.tfdret = tf.placeholder(tf.float32, [None, 1], 'reward_t1')
		self.tfdret0 = tf.placeholder(tf.float32, [None, 1], 'reward_t0')
		self.tfdspe = tf.placeholder(tf.float32, [None, 1], 'speed_t1')
		self.tfdspe2 = tf.placeholder(tf.float32, [None, 1], 'speed_t2')

		self.tfdsta2 = tf.placeholder(tf.float32, [None] + list(self.S_DIM), 'new_state')
		self.tfdsta = tf.placeholder(tf.float32, [None] + list(self.S_DIM), 'old_state')

		self.stateparameter2 = tf.placeholder(tf.float32, [None, 1], 'stateparameter2')

		self.VAE_INPUT = tf.placeholder(tf.float32, [None] + list(self.S_DIM), 'VAE_INPUT')


		#Optimizer
		self.learning_rate_Spe_ret = 0.0001
		self.optimizer= tf.train.AdamOptimizer(self.learning_rate_Spe_ret, name='AdamOptSperet')


		# VAE
		self.VAE_MEAN, self.VAE_LOGVAR = self.ANN._build_VAE_Encoder(net_input=self.VAE_INPUT, name="VAE",
																	 w_init=self.kernel_initializer,
																	 VAE_LATENT_DIM=self.VAE_LATENT_DIM)
		self.VAE_Z = self.ANN._build_VAE_Reparameterize(mean=self.VAE_MEAN, logvar=self.VAE_LOGVAR, name="VAE",
														VAE_BATCH_SIZE=self.VAE_BATCH_SIZE,
														VAE_LATENT_DIM=self.VAE_LATENT_DIM)
		self.VAE_DECODER = self.ANN._build_VAE_Decoder(z=self.VAE_Z, name="VAE", w_init=self.kernel_initializer, VAE_BATCH_SIZE = self.VAE_BATCH_SIZE)

		self.VAE_RECON_LOSS, self.VAE_KL_LOSS, self.VAE_LOSS = self.ANN._VAE_compute_loss(decoder=self.VAE_DECODER,
																					  image_label=self.VAE_INPUT,
																					  mean=self.VAE_MEAN,
																					  logvar=self.VAE_LOGVAR,
																					  z=self.VAE_Z)
		self.VAE_train_op = self.optimizer.minimize(self.VAE_LOSS)


		#SPEED ESTIMATORS
		self.speOut, self.LSTM_FINAL_STATE , self.spe_lstm= self.ANN._build_SpeedEst(input = self.tfdsta, name = "Spe1", w_init=self._get_glorot_uniformInitializer(),
																	  LSTM_LAYERS = self.LSTM_LAYERS,
																	  LSTM_UNITS = self.LSTM_UNITS,
																	  LSTM_INIT_STATE = self.LSTM_INIT_STATE)


		self.spe_loss = 1000.0 * tf.reduce_mean(tf.square(self.speOut - self.tfdspe))
		self.spe_train_op = self.optimizer.minimize(self.spe_loss)

		self.spe2Out = self.ANN._build_SpeedEst2(input = self.tfdsta,name ="Spe2", w_init= self.kernel_initializer, LSTM_LAYERS = self.LSTM_LAYERS, LSTM_UNITS = self.LSTM_UNITS)
		self.spe2_loss = 1000.0 * tf.reduce_mean(tf.square(self.spe2Out - self.tfdspe2))
		self.spe2_train_op = self.optimizer.minimize(self.spe2_loss)

		self.VAE_SPEED_ESTIMATE, self.VAE_LSTM_INIT_STATE, self.VAE_LSTM_STATE = self.ANN._build_SpeedEst3("Spe3",self.VAE_MEAN, self.kernel_initializer ,self.LSTM_LAYERS, self.LSTM_UNITS)
		self.spe3_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/Spe3")
		self.spe3_loss = 1000.0 * tf.reduce_mean(tf.square(self.VAE_SPEED_ESTIMATE - self.tfdspe))
		self.spe3_train_op = self.optimizer.minimize(self.spe3_loss)

		#RETURN ESTIMATORS
		self.retOut = self.ANN._build_ReturnEst(name= "Ret1", w_init= self.kernel_initializer, input = self.tfdsta)
		self.ret_loss = tf.reduce_mean(tf.square(self.retOut - self.tfdret0))
		self.ret_train_op = self.optimizer.minimize(self.ret_loss)

		self.ret2Out = self.ANN._build_ReturnEst2(name ="Ret2", w_init =self.kernel_initializer,state_parameter = self.stateparameter2, input =self.tfdsta)
		self.ret2_loss = tf.reduce_mean(tf.square(self.ret2Out - self.tfdret))
		self.ret2_train_op = self.optimizer.minimize(self.ret2_loss)



		#self.ret3Out = self._build_ReturnEst3("Ret3", w_init= self.kernel_initializer, Action0, Action1, Action2, self.stateparameter2)
		#self.ret3_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/Ret3")


		#SUMMARIES
		tf.summary.image("input", self.VAE_INPUT)
		tf.summary.image("reconstructions", self.VAE_DECODER)

		tf.summary.scalar("VAE_LOSS", self.VAE_LOSS)
		tf.summary.scalar("VAE_MSE_LOSS", tf.reduce_mean(self.VAE_RECON_LOSS))
		tf.summary.scalar("VAE_KL_LOSS", tf.reduce_mean(self.VAE_KL_LOSS))

		tf.summary.scalar("spe_loss_LSTM", self.spe_loss)
		tf.summary.scalar("spe2_loss", self.spe2_loss)
		tf.summary.scalar("spe3_loss_VAE_MEAN", self.spe3_loss)

		tf.summary.scalar("ret1_loss", self.ret_loss)
		tf.summary.scalar("ret2_loss", self.ret2_loss)
		#tf.summary.scalar("ret3_loss", self.ret3_loss)
		self.RPsaver = tf.train.Saver()


	def _get_he_normalInitializer(self):
		return tf.keras.initializers.he_normal()

	def _get_glorot_uniformInitializer(self):
		return tf.keras.initializers.glorot_uniform()



