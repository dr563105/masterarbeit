from Config import *

import tensorflow as tf
import numpy as np

class ANN(object):
	def __init__(self,  kernel_initializer,Parameter,state_dim):
		self.Kernel_Initializer = kernel_initializer
		self.Parameter = Parameter
		self.state_dim = state_dim

	def _build_SpeedEst(self, input,  name, w_init, LSTM_LAYERS, LSTM_UNITS, LSTM_INIT_STATE):
		with tf.variable_scope(name):
			print("INPUT SHAPE :")
			print(input.shape)
			conv1 = tf.layers.conv2d(name="retconv1", inputs=input, filters=32, kernel_size=(4, 4),
									 strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv2 = tf.layers.conv2d(name="retconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv3 = tf.layers.conv2d(name="retconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
									 activation=tf.nn.relu, kernel_initializer=w_init)

			print("scope : FE : ")
			print(conv3.shape)


			print("SPEED ESTIMATOR:")
			state_in = tf.layers.flatten(conv3)
			#state_in = outputs_conv_lstm
			print(state_in)

			# LSTM layer

			num_units = []
			for _ in range(LSTM_LAYERS):
				num_units.append(LSTM_UNITS)
			cells = [tf.nn.rnn_cell.LSTMCell(num_units=n) for n in num_units]

			spe_lstm = tf.nn.rnn_cell.MultiRNNCell(cells)
			#self.spe_lstm = a_lstm


			lstm_in = tf.expand_dims(state_in, axis=0)

			print("LSTM IN SHA")

			print("LSTM IN : \n{}".format(lstm_in))

			a_outputs, a_final_state = tf.nn.dynamic_rnn(cell=spe_lstm, inputs=lstm_in, initial_state=LSTM_INIT_STATE)
			#switch again BS with TS
			a_outputs = tf.transpose(a_outputs, [1,0,2])

			#get last element
			last = a_outputs[-1] #tf.gather_nd(a_outputs, int(a_outputs.shape[0] - 1))
			print("last shape : {}".format(last.shape))

			out = tf.layers.dense(last, 1, name='retls1', kernel_initializer=w_init)

			########

			#out = tf.layers.dense(a_cell_out, 1, kernel_initializer=w_init)
		return out ,a_final_state, spe_lstm

	def _build_SpeedEst2(self, input, name, w_init, LSTM_LAYERS, LSTM_UNITS):
		with tf.variable_scope(name):
			# conLF1c = tf.layers.dense(self.stateparameter2, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
			# conLF2c = tf.layers.dense(conLF1c, self.state_dim[0] * self.state_dim[1], tf.nn.relu, name='conLF2c',
			#                          kernel_initializer=w_init)
			# conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1], 1])
			#
			# concat = tf.concat(values=[self.tfdsta, conLF2cReshapeC], axis=3)

			conv1 = tf.layers.conv2d(name="speconv1", inputs=input, filters=32, kernel_size=(4, 4),
									 strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv2 = tf.layers.conv2d(name="speconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv3 = tf.layers.conv2d(name="speconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			nn = tf.layers.flatten(conv3)

			for i in range(LSTM_LAYERS):
				nn = tf.layers.dense(nn, LSTM_UNITS, tf.nn.relu, name='speed_dense_{}'.format(i),
									 kernel_initializer=w_init)

			out = tf.layers.dense(nn, 1, name='spels1', kernel_initializer=w_init)
		return out

	def _build_SpeedEst3(self ,name, input, w_init, LSTM_LAYERS, LSTM_UNITS):
		with tf.variable_scope(name):

			num_units = []
			for _ in range(LSTM_LAYERS):
				num_units.append(LSTM_UNITS)
			cells = [tf.nn.rnn_cell.LSTMCell(num_units=n) for n in num_units]

			a_lstm = tf.nn.rnn_cell.MultiRNNCell(cells)

			vae_lstm_init_state = a_lstm.zero_state(batch_size=1, dtype=tf.float32)
			lstm_in = tf.expand_dims(input, axis=0)

			print("LSTM IN SHA")

			print("LSTM IN : \n{}".format(lstm_in))

			vae_lstm_outputs, vae_lstm_final_state = tf.nn.dynamic_rnn(cell=a_lstm, inputs=lstm_in, initial_state=vae_lstm_init_state)
			#switch again BS with TS
			vae_lstm_outputs = tf.transpose(vae_lstm_outputs, [1,0,2])

			#get last element
			last = vae_lstm_outputs[-1] #tf.gather_nd(a_outputs, int(a_outputs.shape[0] - 1))

			nn = tf.layers.dense(last,
								 units=1,
								 kernel_initializer=w_init,
								 name='Estimator_Output')


			print(nn)
			# assert(False)
			return nn, vae_lstm_init_state, vae_lstm_final_state

	def _build_ReturnEst(self, name, w_init, input):
		with tf.variable_scope(name):
			conv1 = tf.layers.conv2d(name="retconv1", inputs=input, filters=32, kernel_size=(4, 4),
									 strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv2 = tf.layers.conv2d(name="retconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv3 = tf.layers.conv2d(name="retconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			state_in = tf.layers.flatten(conv3)

			out = tf.layers.dense(state_in, 1, name='retls1', kernel_initializer=w_init)
		return out

	def _build_ReturnEst2(self, name, w_init, state_parameter , input):
		with tf.variable_scope(name):
			conLF1c = tf.layers.dense(state_parameter, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
			conLF2c = tf.layers.dense(conLF1c, self.state_dim[0] * self.state_dim[1], tf.nn.relu, name='conLF2c',
									  kernel_initializer=w_init)
			conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1], 1])

			concat = tf.concat(values=[input, conLF2cReshapeC], axis=3)

			conv1 = tf.layers.conv2d(name="speconv1", inputs=concat, filters=32, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv2 = tf.layers.conv2d(name="speconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv3 = tf.layers.conv2d(name="speconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			state_in = tf.layers.flatten(conv3)

			lafc = tf.layers.dense(state_in, 40, tf.nn.relu, name='lafc', kernel_initializer=w_init)
			out = tf.layers.dense(lafc, 1, name='spels1', kernel_initializer=w_init)
		return out

	def _build_ReturnEst3(self, name, w_init, Action0, Action1, Action2, input):
		with tf.variable_scope(name):

			conLF1c = tf.layers.dense(input, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
			conLF2c = tf.layers.dense(conLF1c, self.state_dim[0] * self.state_dim[1], tf.nn.relu, name='conLF2c',
									  kernel_initializer=w_init)
			conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1], 1])

			concat = tf.concat(values=[self.tfdsta, conLF2cReshapeC], axis=3)

			conv1 = tf.layers.conv2d(name="speconv1", inputs=concat, filters=32, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv2 = tf.layers.conv2d(name="speconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv3 = tf.layers.conv2d(name="speconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			state_in = tf.layers.flatten(conv3)

			lafc = tf.layers.dense(state_in, self.LSTM_UNITS, tf.nn.relu, name='lafc', kernel_initializer=w_init)

			print()
			if Action2 != None:
				concat = tf.concat(values=[lafc, Action2[:-1], Action1[:-1], Action0[:-1]], axis=1)

			elif Action1 != None:
				concat = tf.concat(values=[lafc, Action1[:-1], Action0[:-1]], axis=1)
			else:
				concat = tf.concat(values=[lafc, Action0[:-1]], axis=1)

			out = tf.layers.dense(concat, 1, name='spels1', kernel_initializer=w_init)

		# print(out)
		# assert(False)
		return out

	def _build_VAE_Encoder(self, net_input, name, w_init, VAE_LATENT_DIM):
		with tf.variable_scope(name):
			with tf.variable_scope('Encoder'):

				nn = tf.layers.conv2d(inputs=net_input,
									  filters=32,
									  kernel_size=5,
									  strides=(1, 1),
									  activation=tf.nn.relu,
									  kernel_initializer=w_init,
									  dilation_rate=(2, 2),
									  name="CNN_Layer_3")

				print("Third Layer : {}".format(nn))
				nn = tf.layers.conv2d(inputs=nn,
									  filters=64,
									  kernel_size=3,
									  strides=(2, 2),
									  activation=tf.nn.relu,
									  kernel_initializer=w_init,
									  name="CNN_Layer_4")

				print("Fourth Layer : {}".format(nn))
				nn = tf.layers.conv2d(inputs=nn,
									  filters=64,
									  kernel_size=3,
									  strides=(2, 2),
									  activation=tf.nn.relu,
									  kernel_initializer=w_init,
									  name="CNN_Layer_5")
				print("Fifth Layer : {}".format(nn))

				nn = tf.layers.flatten(nn)

				mean = tf.layers.dense(nn,
									   units=VAE_LATENT_DIM,
									   kernel_initializer=w_init,
									   name='Mean')

				logvar = tf.layers.dense(nn,
										 units=VAE_LATENT_DIM,
										 kernel_initializer=w_init,
										 name='Logvar')

			return mean, logvar

	def _build_VAE_Reparameterize(self, mean, logvar, name, VAE_BATCH_SIZE, VAE_LATENT_DIM):
		with tf.variable_scope(name):
			with tf.variable_scope("Reparameterize"):
				# reparameterize
				eps = tf.random.normal(shape=(VAE_BATCH_SIZE, VAE_LATENT_DIM))
				z = eps * tf.exp(logvar * .5) + mean
				return z

	def _build_VAE_Decoder(self, z, name, w_init, VAE_BATCH_SIZE):
		with tf.variable_scope(name):
			with tf.variable_scope('DECODER'):
				nn = tf.layers.dense(z, units=10 * 10 * 64,
									 name='Dense_Layer_1',
									 kernel_initializer=w_init)
				nn = tf.reshape(nn, [VAE_BATCH_SIZE, 10, 10, 64])
				nn = tf.layers.conv2d_transpose(inputs=nn,
												filters=64,
												kernel_size=3,
												strides=(2, 2),
												padding="same",
												activation=tf.nn.relu,
												kernel_initializer=w_init,
												name="CNN_Transpose_Layer_1")

				print("First Layer : {}".format(nn))

				nn = tf.layers.conv2d_transpose(inputs=nn,
												filters=32,
												kernel_size=3,
												strides=(2, 2),
												padding="same",
												kernel_initializer=w_init,
												name="CNN_Transpose_Layer_3",
												activation=tf.nn.relu)
				print("Third Layer : {}".format(nn))
				nn = tf.layers.conv2d_transpose(inputs=nn,
												filters=3,
												kernel_size=3,
												strides=(1, 1),
												padding="same",
												kernel_initializer=w_init,
												name="CNN_Transpose_Layer_4",

												)

				print("Fourth Layer : {}".format(nn))
				decoder_out = tf.math.tanh(nn)

		return decoder_out

	def _VAE_compute_loss(self, decoder, image_label, mean, logvar, z):

		def log_normal_pdf(sample, mean, logvar, raxis=1):
			log2pi = tf.math.log(2. * np.pi)
			return tf.reduce_sum(-.5 * ((sample - mean) ** 2. * tf.exp(-logvar) + logvar + log2pi), axis=raxis)

		logits_flat = tf.layers.flatten(decoder)
		labels_flat = tf.layers.flatten(image_label)
		print(logits_flat)
		print(labels_flat)

		# mse
		recon_loss = tf.math.pow(tf.subtract(labels_flat, logits_flat), 2)

		print("reconstruction_loss : {}".format(recon_loss))

		print(tf.shape(recon_loss))
		print(recon_loss)

		logpx_z = tf.reduce_sum(recon_loss, axis=1)
		# logpx_z = tf.reduce_mean(recon_loss, axis=1)

		reconstruction_loss = logpx_z
		print("logpx_loss : {}".format(logpx_z))
		log_P = log_normal_pdf(z, 0., 1.)
		log_Q = log_normal_pdf(z, mean, logvar)
		print("logqx_loss : {}".format(log_Q))
		# self.kl_loss = -tf.reduce_sum(logpz- logqz_x )
		kl_loss = -(log_P - log_Q)
		print("kl_loss{}".format(kl_loss))
		elbo_loss = tf.reduce_mean(logpx_z + kl_loss)

		# loss_summary = tf.summary.scalar("loss", elbo_loss)
		# tf_summaries.append(loss_summary)
		return reconstruction_loss, kl_loss, elbo_loss