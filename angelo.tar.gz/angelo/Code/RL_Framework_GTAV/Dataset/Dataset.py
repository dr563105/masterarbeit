import time
import os
import csv
import cv2


class DatasetCreator(object):
    def __init__(self, runnerID):
        self.runnerID = runnerID
        self._initialize()


    def _initialize(self):
        #Create new folder with timestamp
        time.localtime()

        localTime = time.localtime()
        self.timestamp = str(localTime.tm_year) + "-" + str(localTime.tm_mon) + "-" + str(localTime.tm_mday) + "-" + str(localTime.tm_hour) + "-" + str(localTime.tm_min) + "-" + str(localTime.tm_sec)

        self.dataSetDir = "Dataset" + "_" + self.timestamp

        self.fileDir = self.dataSetDir  + "/Runner" + str(self.runnerID)

        if not os.path.exists(self.dataSetDir):
            os.mkdir(self.dataSetDir)

        if not os.path.exists(self.fileDir ):
            os.mkdir(self.fileDir )


    def _addData(self, frame,step):#, velocity, gyro, steering , reward, step):

        #save frame
        #velocity = velocity[0]*120.0
        #gyro = gyro[0] * 100.0
        #steering = steering[0]
        #print("velocity = {}".format(velocity))
        #print("steering = {}".format(steering))
        #print("reward = {}".format(reward))
        #print("gyro = {}".format(gyro))
        #print("step = {}".format(step))
        imgFileName = self.fileDir + "/Frame{:06d}.png".format(step)

        frame = cv2.cvtColor(frame , cv2.COLOR_BGR2RGB)

        cv2.imwrite( imgFileName, frame)

        #save csv
        #data = [step ,velocity, gyro, steering, reward]
        #print(data)
        #assert(False)
       # self._writeCSV(data)

    def _writeCSV(self, data):

        step = str(data[0])
        csvFileName = "value" + step + ".csv"
        with open(self.fileDir + "/" + csvFileName, mode='w') as csv_file:

            fieldnames = ['velocity', 'gyro', 'steering' , 'reward']

            # writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer = csv.writer(csv_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            writer.writerow([str(data[1]), str(data[2]), str(data[3]) , str(data[4])])
