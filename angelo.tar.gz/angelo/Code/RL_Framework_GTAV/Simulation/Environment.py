import gym
import cv2
from Config import *
import numpy as np
import scipy
import deepgtav
from deepgtav.messages import Start, Stop, Scenario, Commands, frame2numpy, RestartEpisode
from deepgtav.client import Client

import time

class Gym_Environment(object):
	def __init__(self,env_id,Parameter,state_dim):
		self.Parameter= Parameter
		self.ID = env_id
		self.intigier=0
		self.state_dim = state_dim

	def _create_environment(self,env_name,seed = None):
		self.Environment = gym.make(env_name).unwrapped
		if seed != None:
			self.Environment.seed(seed)
			print("Seed "+str(seed)+" generated")

	def compress(self, value):
		xlow, xhigh = (-0.21, -0.17)
		ylow, yhigh = (-0.3, 0.0)
		if xlow < value < xhigh:
			return ylow + (value - xlow) / (xhigh - xlow) * (yhigh - ylow)
		else:
			return value

	def compress_image(self, image):
		retImag = np.zeros(shape=image.shape)
		for j in range(image.shape[0]):
			for k in range(image.shape[1]):
				retImag[j, k, 0] = self.compress(image[j, k, 0])

		return retImag


	def _image_preprocessing(self,state):
		color_dim =3
		if self.Parameter.EnvConfig.CROPIMAGE:
			img = state[self.Parameter.EnvConfig.FROM_Y:self.Parameter.EnvConfig.TO_Y,
				  self.Parameter.EnvConfig.FROM_X:self.Parameter.EnvConfig.TO_X]  # we crop side of screen as they carry little information
		else:
			img = state
		if self.Parameter.EnvConfig.GREYSCALE:
			img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
			color_dim = 1
		img = img.astype('float')
		if self.Parameter.EnvConfig.MEANSHIFT:
			img[:, :] -= 127.0
			img = img / 127.0
		else:
			img = img / 255.0
		if self.Parameter.EnvConfig.CROPIMAGE:
			img= img.reshape(self.Parameter.EnvConfig.TO_Y-self.Parameter.EnvConfig.FROM_Y,
							   self.Parameter.EnvConfig.TO_X- self.Parameter.EnvConfig.FROM_X, color_dim)
			if self.Parameter.EnvConfig.IMAGECOMPRESSION and self.Parameter.EnvConfig.GREYSCALE:
				img = self.compress_image(img)
			return img
		else:
			img = img.reshape(self.state_dim[0],self.state_dim[1],self.state_dim[2])
			return img

	def _env_step(self,action):
		observation, reward, done, info = self.Environment.step(action)
		return observation, reward, done, info

	def _env_reset(self):
		self.Environment.seed()
		return self.Environment.reset()


	def _env_render(self):
		s_image = self.Environment.render()
		return s_image

	def _prepare_env(self):
		#for _ in range(50):
		s, _, _, _ = self._env_step([0,0,0])
		return s

	def _close_env(self):
		self.Environment.close()

	def _get_state_parameter(self):
		return	self.Environment.metadata

	def get_velocity(self):
		return np.sqrt(np.square(self.Environment.car.hull.linearVelocity[0]) +
					   np.square(self.Environment.car.hull.linearVelocity[1]))

	def get_gyro(self):
		return self.Environment.car.hull.angularVelocity

	def get_steering(self):
		return self.Environment.car.wheels[0].joint.angle


class GTA_Environment(object):
	# def __init__(self,env_id,Parameter,state_dim):
	def __init__(self, env_id, Parameter, state_dim , ip_address):
		self.Parameter = Parameter
		self.ID = env_id
		self.intigier = 0
		self.state_dim = state_dim

		#self.IP = self.Parameter.Client.IP
		self.IP = ip_address
		self.port = self.Parameter.Client.PORT
		print("IP = " + str(self.IP))
		print("PORT = " + str(self.port))
		self.Client = Client(ip=self.IP, port=self.port, compressionLevel=9)
		self.Message = None
		self.index = 0
		self.collided = False
		self.state_o = None
		self.success = False
		self.collided_counter = 0
		self.restarting = False
		self.accumulated_reward = 0.0
		self.start_positions = [[539.051025390625, 85.24335479736328, 96.10704040527344],
								[1283.875244140625, 560.1414794921875, 80.46791076660156],
								[2064.910400390625, 1432.56201171875, 75.41105651855469],
								[320.98529052734375, -353.2369689941406, 45.76124572753906],
								[137.85340881347656, -897.45751953125, 30.168792724609375],
								[375.34844970703125, -1060.1619873046875, 29.064184188842773],
								[585.3226928710938, -1029.68017578125, 36.94135665893555],
								[1168.1141357421875, -901.4506225585938, 51.806644439697266],
								[1274.2650146484375, -512.6837158203125, 68.85506439208984],
								[965.57470703125, -648.3875122070312, 57.2228889465332],
								[1398.517822265625, -1731.5709228515625, 65.6539077758789],
								[1034.781005859375, -523.4281005859375, 61.070884704589844],
								[1931.775146484375, 1867.4949951171875, 60.28127670288086],
								[2510.30322265625, 2762.40869140625, 45.733970642089844],
								[2507.127685546875, 1371.648681640625, 41.1328010559082]]

		self.font = cv2.FONT_HERSHEY_SIMPLEX
		self.bottomLeftCornerOfText = (10, 280)
		self.fontScale = 0.5
		self.fontColor = (255, 0, 0)
		self.lineType = 2
		self.goal_distance = 0.0
		self.steering = 0.0
		self.throttle = 0.0
		self.brake = 0.0
		self.velocity = 0.0

	def _create_environment(self, seed=None):
		# Init environment
		# connect to server

		# send start

		print("Connect to GTAV")
		scenario = Scenario(drivingMode=-1, location=self.Parameter.GTAV.START_POS)  # manual driving
		print("send start message")
		self.Client.sendMessage(Start(scenario=scenario))
		# wait for message to come back
		message = None
		while message == None:
			message = self.Client.recvMessage()

		print("Init message received :")
		print("Environment has been initialized")
		#print("Message = " + str(message))

	def compress(self, value):
		xlow, xhigh = (-0.21, -0.17)
		ylow, yhigh = (-0.3, 0.0)
		if xlow < value < xhigh:
			return ylow + (value - xlow) / (xhigh - xlow) * (yhigh - ylow)
		else:
			return value

	def compress_image(self, image):
		retImag = np.zeros(shape=image.shape)
		for j in range(image.shape[0]):
			for k in range(image.shape[1]):
				retImag[j, k, 0] = self.compress(image[j, k, 0])

		return retImag

	def _image_preprocessing(self, state):


		##print("state_dim = {}".format(state.shape))
#
		#if self.Parameter.EnvConfig.CROPIMAGE:
		#	img = state[self.Parameter.EnvConfig.FROM_Y:self.Parameter.EnvConfig.TO_Y,
		#		  self.Parameter.EnvConfig.FROM_X:self.Parameter.EnvConfig.TO_X]
		#	#print("return image")
		#	#print("state_dim = {}".format(img.shape))



		img = state
		img = img.astype('float')

		if self.Parameter.EnvConfig.MEANSHIFT:
			img -= 127.0
			img = img / 127.0
		else:
			img = img / 255.0

		#cv2.imwrite("imgrSTATE" + str(self.index) + ".png", img)
		#self.index += 1

		#print(str(img))
		#if self.Parameter.EnvConfig.CROPIMAGE:
		#	img = img.reshape(self.Parameter.EnvConfig.TO_Y - self.Parameter.EnvConfig.FROM_Y,
		#					  self.Parameter.EnvConfig.TO_X - self.Parameter.EnvConfig.FROM_X, color_dim)
		#	if self.Parameter.EnvConfig.IMAGECOMPRESSION and self.Parameter.EnvConfig.GREYSCALE:
		#		img = self.compress_image(img)
		#	#return img

		return img

	def _env_step(self, action):
		#message = None
		message = self.Client.recvMessage()
		terminate_state = False
		while message == None:
			print("message is none")
			self.Client.sendMessage(Commands(0.0, 0.0, 0.0))
			message = self.Client.recvMessage()

		GTAV_state = int(message["state"])
		w, h, _ = message["imageSize"]
		self.state_o = frame2numpy(message['frame'], (int(w), int(h)))

		frame2numpy(message['frame'], (int(w), int(h)))

		self.state = self.state_o
		self.state = cv2.cvtColor(self.state, cv2.COLOR_BGR2RGB)
		self.success = False
		if GTAV_state == 0x2:
			self.restarting = False
			a1 = float(action[0]) ##steering
			a2 = float(action[1]) ##throttle
			a3 = float(action[2]) ##brake

			self.Message = message
			reward = float(message["reward"])
			if reward > 0.0:
				reward = reward*5.0

			#else:
			#	reward = -0.1
			self.accumulated_reward += reward
			collided = message["collided"]

			agentPos = message["position"]
			self.velocity = float(message["velocity"])

			self.collided = collided

			#t,s,b
			self.Client.sendMessage(Commands(throttle =a2, brake= a3, steering = a1))
			self.success = True
			terminate_state = bool(message["terminate_state"])
			#if terminate_state:

			self.throttle = float(message["throttle"])

			##brake and steering are exchanged in GTAV cpp framework: TODO: Change this lol
			self.brake = float(message["steering"])
			self.steering = float(message["brake"])

			self.goal_distance = float(message["goalDistance"])


			if (self.steering is None) or (self.throttle is None) or (self.brake is None) or (self.velocity is None):
				assert(False)


			return self.state, reward, terminate_state, 0, self.success  # , state
		elif GTAV_state == 0x1:
			print("GTAV is initialized")
			self.Client.sendMessage(Commands(0.0, 0.0, 0.0))
			self.collided = False
			self.collided_counter = 0
			self.accumulated_reward = 0.0
		elif GTAV_state == 0x4 or GTAV_state == 0x3:
			print("GTA is waiting")
			self.Client.sendMessage(Commands(0.0, 0.0, 0.0))
			self.collided = False
			self.collided_counter = 0
			self._env_step(action)
		elif GTAV_state == 0x5:
			print("GTA is restarting")
			self.Client.sendMessage(Commands(0.0, 0.0, 0.0))
			self.collided = False
			self.collided_counter = 0
			self.restarting = True
			self.success = True
			reward = float(message["reward"])
			if reward > 0.0:
				reward = reward*5.0
			#else:
			#	reward = -0.1
			#self.accumulated_reward += reward
			self.collided = message["collided"]
			self.accumulated_reward = 0.0
			self.throttle = float(message["throttle"])
			self.steering = float(message["steering"])
			self.brake = float(message["brake"])

			self.goal_distance = float(message["goalDistance"])
			print("TERMINATE STATE : RESTART")
			terminate_state = message["terminate_state"]
			#self._env_step(action)
			#print(terminate_state)
			return self.state, reward, terminate_state, 0, self.success  # , state
		else:
			print("GTA has sent unknown state")
			assert(False)

		return self.state, 0, terminate_state, 0 , self.success # , state




	def _env_reset(self):
		#self.Environment.seed
		if not self.restarting:
			print("Restart GTAV")
			pos = self.Parameter.GTAV.START_POS

			if self.Parameter.GTAV.SPAWN_DIFFERENT_LOCATIONS:
				i = np.random.randint(len(self.start_positions))
				pos =self.start_positions[i]

			scenario = Scenario(location=pos)

			self.Client.sendMessage(RestartEpisode(scenario = scenario))
			self.restarting = True


		#return self.Environment.reset()

	def _env_render(self):
		#self.Environment.render()

		y0, dy = 280 , 20
		self.bottomLeftCornerOfText = (10, y0)
		if self.state_o is not None:
			vis = self.state_o

			vis = cv2.resize(vis, (vis.shape[0]*3 ,vis.shape[1]*3 ))

			text = "Reward : {}\nSpeed : {:.2f}\nSteering : {:.2f}\nBrake : {:.2f}\nThrottle : {:.2f}".format(str(int(self.accumulated_reward)),
																					   		float(self.velocity),
																					   		float(self.steering),
																			   				float(self.brake),
																							float(self.throttle)
																						   )

			for i, line in enumerate(text.split('\n')):
				y = y0 - i*dy
				self.bottomLeftCornerOfText = (10, y)
				cv2.putText(vis, line ,
							self.bottomLeftCornerOfText,
							self.font,
							self.fontScale,
							self.fontColor,
							self.lineType)

			window_name = "GTAV Simulation : {}".format(self.IP)
			cv2.namedWindow(window_name)
			cv2.imshow(window_name, vis)
			cv2.waitKey(1)
		return

	def _prepare_env(self):
		#for _ in range(50):
		self.Client.sendMessage(Commands(0.0, 0.0, 0.0))
		s, _, _, _, success = self._env_step([0, 0, 0])

		return s

	def _close_env(self):
		#self.Environment.close()
		self.Client.sendMessage(Stop())

	def _get_state_parameter(self):
		return self.Environment.metadata

	def get_velocity(self):
		return self.velocity


	def get_steering(self):
		return self.steering#self.Environment.car.wheels[0].joint.angle

	def get_brake(self):
		return self.brake

	def get_throttle(self):
		return self.throttle  # self.Environment.car.wheels[0].joint.angle

	def get_goal_distance(self):
		return self.goal_distance