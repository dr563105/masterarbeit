from xml.etree import ElementTree as ET
import tensorflow as tf
from Config import Parameter


def XMLReader(file):
    Params =Parameter()
    tree = ET.parse(file)
    root = tree.getroot()
    for child in root:
        if (len(child)>0):
            for child2 in child:
                if len(child2)>0:
                    for child3 in child2:
                        if (len(child3)>0):
                            for child4 in child3:
                                x = child.tag+"."+child4.tag
                                print(child.tag + "." + child4.tag + "=" + child4.text)
                                if (child4.attrib['format'] == "list"or child4.attrib['format'] =='tuple'):
                                    child4.text = child4.text.replace("[", "")
                                    child4.text = child4.text.replace("]", "")
                                    child4.text = child4.text.replace("(", "")
                                    child4.text = child4.text.replace(")", "")
                                    exec("Params.{} = list(map({},{}))".format(child.tag+"."+child4.tag,child4.attrib['inner_format'],child4.text.split(",")))

                                elif (child4.attrib['format']=='bool'):
                                    if child4.text =='True':
                                        exec("Params.{} = {}".format(child.tag+"."+child4.tag,True))
                                    else:
                                        exec("Params.{} = {}".format(child.tag+"."+child4.tag,False))
                                else:
                                    exec("Params.{} = {}({})".format(child.tag+"."+child4.tag, child4.attrib['format'],"'"+child4.text+"'"))
                        else:
                            print(child.tag+"."+child3.tag+ "=" +child3.text )
                            if (child3.attrib['format']=='list'or child3.attrib['format']=='tuple'):
                                child3.text = child3.text.replace("[", "")
                                child3.text = child3.text.replace("]", "")
                                child3.text = child3.text.replace("(", "")
                                child3.text = child3.text.replace(")", "")
                                exec("Params.{} = list(map({},{}))".format(child.tag+"."+child3.tag,child3.attrib['inner_format'] ,child3.text.split(",")))
                            elif( child3.attrib['format']=='bool'):
                                if (child3.text == "True"):
                                    exec("Params.{} = {}".format(child.tag+"."+child3.tag ,True))
                                else:
                                    exec("Params.{} = {}".format(child.tag+"."+child3.tag ,False))
                            else:
                                exec("Params.{} = {}({})".format(child.tag+"."+child3.tag,child3.attrib['format'] ,"'"+child3.text+"'"))
                else:
                    print(child.tag+"."+child2.tag+ "=" +child2.text )
                    if (child2.attrib['format'] == 'list'or child2.attrib['format'] == 'tuple'):
                        child2.text = child2.text.replace("[", "")
                        child2.text = child2.text.replace("]", "")
                        child2.text = child2.text.replace("(", "")
                        child2.text = child2.text.replace(")", "")
                        exec("Params.{} = list(map({},{}))".format(child.tag+"."+child2.tag,child2.attrib['inner_format']  ,child2.text.split(",")))
                    elif (child2.attrib['format']=='bool'):
                        if (child2.text == "True"):
                            exec("Params.{} = {}".format(child.tag + "." + child2.tag, True))
                        else:
                            exec("Params.{} = {}".format(child.tag + "." + child2.tag, False))
                    else:
                        exec("Params.{} = {}({})".format(child.tag+"."+child2.tag,child2.attrib['format'] ,"'"+child2.text+"'"))
        else:
            continue

    return Params
