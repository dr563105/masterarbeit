'''
Reinforcment Learning Framework
Using Tensorflow
by Kemal Acar

'''
from Runner import Runner
from GTARunner import GTARunner
import time
from Optimizer import *
from ParameterServer import DataServer
import ray
from Config import *
import os
import sys
import psutil
import csv
from Utils import XMLWriter, XMLReader
import warnings

warnings.filterwarnings('ignore')

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

tf.logging.set_verbosity(tf.logging.WARN)

def get_state_dimension(Parameter):
	'''
	calculate the State Dimension
	which depends on the image dimensions and processings
	:return: state dimension
	'''
	state_dim = Parameter.EnvConfig.S_DIM
	if Parameter.EnvConfig.CROPIMAGE:
		state_dim = tuple([Parameter.EnvConfig.TO_Y-Parameter.EnvConfig.FROM_Y,
						   Parameter.EnvConfig.TO_X-Parameter.EnvConfig.FROM_X,state_dim[2]])
	else:
		state_dim = tuple(Parameter.EnvConfig.S_DIM)
	if Parameter.EnvConfig.GREYSCALE:
		state_dim = tuple([state_dim[0],state_dim[1],1])
	return state_dim


def restart_program():
	"""Restarts the current program, with file objects and descriptors
	   cleanup
	"""

	p = psutil.Process(os.getpid())
	for handler in p.open_files() + p.connections():
		os.close(handler.fd)

	python = sys.executable
	os.execl(python, python, *sys.argv)

def get_pointer(pointer,var,i):
	if pointer[i] == len(var[i])-1:
		pointer[i]=0
		if i == len(pointer)-1:
			return pointer,True
		else:
			pointer, lastRound = get_pointer(pointer,var,i+1)
			return pointer,lastRound
	else:
		pointer[i]+=1
		return pointer,False

def Crossvalidation(Params):
	name = []
	var = []
	pointer = []
	file = open("Utils/CrossValidation.txt", "r")
	MEC_File = file.readlines()
	for i, lines in enumerate(MEC_File, 0):
		lines = lines.replace("\n", "")
		line = lines.split(";")
		if len(line) ==2:
			line = line+["0"]
		name.append(line[0])
		line[1] = line[1].replace("[", "")
		line[1] = line[1].replace("]", "")
		if line[1].find("§")!=-1:
			line[1] = line[1].replace("(", "")
			line[1] = line[1].replace(")", "")
			intlist = (line[1].split("§"))
			lists=[]
			for i in range(len(intlist)):
				lists.append(list(map(int, intlist[i].split(","))))
			var.append(lists)
		else:
			if line[1].find(",") != -1:
				var.append(line[1].split(","))
			else:
				var.append([line[1]])

		pointer.append(line[2])
	print(var)
	pointer = (list(map(int, pointer)))
	types= []
	for i in range(len(pointer)):
		print("Params.{} = {}".format(name[i], var[i][pointer[i]]))
		exec("Params.{} = {}".format(name[i], var[i][pointer[i]]))
		exec ("types.append(type(Params.{}))".format(name[i]))
	pointer, lastRound = get_pointer(pointer,var,0)

	file = open("Utils/CrossValidation.txt", "w")
	for i in range(len(pointer)):
		if types[i] == list:
			file.write("{};".format(name[i]))
			for e in range(len(var[i])):
				file.write(str(var[i][e]))
				if e != len(var[i])-1:
					file.write("§")
			file.write(";{}\n".format(pointer[i]))
		elif types[i] == bool:
			file.write("{};{};{}\n".format(name[i],"[True , False]", pointer[i]))
		else:
			file.write("{};{};{}\n".format(name[i], [types[i]((var[i][e])) for e in range(len(var[i]))], pointer[i]))

	return Params,lastRound


def OverwriteParams(MEC_File,Params):
	commands = []
	for i, lines in enumerate(MEC_File, 0):
		if lines.find("$") != -1:
			commands.append(i)
	for i in range(commands[0]):
		line = MEC_File[i]
		line.replace("\n", "")
		line = line.split("=")
		if len(line) != 2:
			assert False
		if line[1].find("[") != -1:
			line[1] = line[1].replace("[", "")
			line[1] = line[1].replace("]", "")
			line[1] = list(map(int, line[1].split(",")))
		print("Params.{} = {}".format(line[0], line[1]))
		exec("Params.{} = {}".format(line[0], line[1]))
	print("command length", len(commands))
	return Params


def MultipleExecution(Params):
	commands = []
	file = open("Utils/MultiExecutionConfig.txt", "r")
	MEC_File = file.readlines()
	for i, lines in enumerate(MEC_File, 0):
		if lines.find("$") != -1:
			commands.append(i)
	for i in range(commands[0]):
		line = MEC_File[i]
		line.replace("\n", "")
		line = line.split("=")
		if len(line) != 2:
			assert False
		if line[1].find("[") != -1:
			line[1] = line[1].replace("[", "")
			line[1] = line[1].replace("]", "")
			line[1] = list(map(int, line[1].split(",")))
		print("Params.{} = {}".format(line[0], line[1]))
		exec("Params.{} = {}".format(line[0], line[1]))
	print("command length", len(commands))
	file = open("Utils/MultiExecutionConfig.txt", "w")

	for i in range(commands[0] + 1, len(MEC_File)):
		file.write(MEC_File[i])

	if len(commands)==1:
		lastRound = True
	else:
		lastRound= False

	return Params,lastRound,MEC_File

# HyperparameterConfig.ACTION_REPEAT_FOR_X_STEPS = 1
# ModelConfig.CONCAT  =  True
# NetworkConfig.SHARED_CNN_FILTERS  =  [160, 320,640,1280]
# $
# HyperparameterConfig.ACTION_REPEAT_FOR_X_STEPS = 2
# ModelConfig.CONCAT  =  False
# NetworkConfig.SHARED_CNN_FILTERS  =  [161, 321,641,1281]
# $
# HyperparameterConfig.ACTION_REPEAT_FOR_X_STEPS = 3
# ModelConfig.CONCAT  =  True
# NetworkConfig.SHARED_CNN_FILTERS  =  [162, 322,642,1282]
# $

if __name__ == '__main__':
	#LogData
	ts = time.gmtime()


	#Init Multiprocessing
	ray.init()

	# Environment Data Server
	eds = DataServer.remote()

	#Save Hyperparameter in a XML file to know the used training parameter
	Params = Parameter()

	if Params.MultipleExecution == True:
		Params , lastRound, MEC_File = MultipleExecution(Params)
	else:
		lastRound = True


	if Params.ModelConfig.RESTORE_MODEL:
		PARAM_DIR = Params.ModelConfig.PARAM_DIR
		RESTORE_DIR = Params.ModelConfig.RESTORE_DIR
		Params = XMLReader.XMLReader(PARAM_DIR + "/Hyperparameter.xml")
		Params.ModelConfig.RESTORE_MODEL = True
		Params.ModelConfig.RESTORE_DIR = RESTORE_DIR
		Params.ModelConfig.PARAM_DIR = PARAM_DIR
		LOG_DIR = PARAM_DIR+"/"+ time.strftime("%Y-%m-%d_%H:%M:%S", ts)
		if Params.MultipleExecution == True:
			Params = OverwriteParams(MEC_File,Params)

	else:
		LOG_DIR = './LogData/'+Params.ModelConfig.MODELNAME+'/' + time.strftime("%Y-%m-%d_%H:%M:%S", ts)



	print(LOG_DIR)
	if not os.path.isdir(LOG_DIR):
		os.makedirs(LOG_DIR)


	XMLWriter.writeXMLFile(LOG_DIR,Params)
	PARAM_DIR = LOG_DIR # SOLLTE WEG ODER ?
	#Parameter = XMLReader.XMLReader(LOG_DIR + "/Hyperparameter.xml")
	state_dim = get_state_dimension(Params)


	if Params.OptimizerConfig.RUN_PPO:
		opt = Optimizer.remote(1, eds,state_dim,LOG_DIR)
	elif Params.OptimizerConfig.RUN_RAPIDPROTOYPE:
		opt = RPOptimizer.remote(1, eds, state_dim,LOG_DIR)

	#time.sleep(10)
	#time.sleep(5)

	for i in range(Params.HyperparameterConfig.N_WORKER):
		if Params.EnvConfig.GTAV_ENVIRONMENT:
			GTARunner.remote(i, state_dim, LOG_DIR, eds, False)
		elif Params.EnvConfig.CARRACING_ENVIRONMENT:

			Runner.remote(i,state_dim,LOG_DIR,eds,False)

	#if Params.OptimizerConfig.RUN_PPO:
	#	opt = Optimizer(1, eds, state_dim, LOG_DIR)
	#elif Params.OptimizerConfig.RUN_RAPIDPROTOYPE:
	#	opt = RPOptimizer(1, eds, state_dim, LOG_DIR)


	for i in range(60*60):
		time.sleep(Params.HyperparameterConfig.TRAIN_TIME)
		if os.path.isfile(LOG_DIR+"/RewardData.csv"):
			file =LOG_DIR+"/RewardData.csv"
			with open(file,"r")as f:
				reader= csv.reader(f,delimiter = ",")
				data = list(reader)
				row_count = len(data)
			if row_count>Params.HyperparameterConfig.EP_MAX:
				print(row_count)
				ray.shutdown()
				if lastRound == False:
					restart_program()
				else:
					quit()

	ray.shutdown()
	if lastRound == False:
		restart_program()
	else:
		quit()

