from Simulation import Environment
from ReinforcementLearning import  Graph
from Utils import XMLReader
import tensorflow as tf
import csv
import numpy as np
import ray
import os
import time
from datetime import datetime
import Dataset

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
tf.logging.set_verbosity(tf.logging.WARN)

import warnings

warnings.filterwarnings('ignore')


@ray.remote
class GTARunner(object):
	def __init__(self,id,state_dim,LOG_DIR,eds = None,Evaluation=False):

#		if id == 1 or id == 0:
#			with tf.device('/GPU:0'):
#				self._initialize(id, LOG_DIR, state_dim,Evaluation)
#				self._run(eds,LOG_DIR,Evaluation)
#		else:
		#with tf.device('/CPU:0'):
		self._initialize(id, LOG_DIR, state_dim,Evaluation)
		self._run(eds,LOG_DIR,Evaluation)


	def _initialize(self,id, LOG_DIR, state_dim,Evaluation):
		self.log = LOG_DIR
		self.state_dim = state_dim
		self.RunnerId = id
		self.Graph = self._buildGraph(LOG_DIR)
		config = tf.ConfigProto(log_device_placement=True)
		config.gpu_options.allow_growth = True
		self.Session = tf.Session(config = config)
		self.Session.run(tf.global_variables_initializer())
		self.Parameter = XMLReader.XMLReader(LOG_DIR+"/Hyperparameter.xml")
		self.stepcount = 0
		self.failList=[]
		self.consecutiveFails=0
		self.AccumulatedValueFunction = 0
		self.sigmabuffer=[]
		self.velocity = [0]
		self.steering = [0]
		self.goal_distance  = [0]
		self.EpisodicRewardList=[0]
		self.SaveIfMeanReward = 700
		self.episodic_reward = 0

		if self.Parameter.CreateDataset:
			self.Dataset = Dataset.DatasetCreator(self.RunnerId)




		self.Environment = Environment.GTA_Environment(0, self.Parameter, self.state_dim, ip_address = self.Parameter.Client.IP_ADRESSES[self.RunnerId])
		self.Environment._create_environment()


		self.episodecount = 0
		print(LOG_DIR)
		if (self.Parameter.ModelConfig.RESTORE_MODEL):
			print("Restored")
			self.Graph.NPsaver.restore(self.Session, save_path=self.Parameter.ModelConfig.RESTORE_DIR)
		self.logParams = {}
		self.epsilon = 1

	def _buildGraph(self,LOG_DIR):
		ppo = Graph.PPO(name="PPO",
						   state_dim=self.state_dim,LOG_DIR=LOG_DIR, runner = True)
		return ppo

	def get_action(self,State,velocity,steering,goal_distance):
		State = State.reshape((1,) + self.state_dim)


		if self.Parameter.ModelConfig.STOCHASTIC_ACTION_SELECTION == True:
			if self.Parameter.EnvConfig.A_DIM == 1:
				fetches =[self.Graph.sample_op0,
						  self.Graph.old_distribution0.scale]
			if self.Parameter.EnvConfig.A_DIM == 2:
				fetches =[self.Graph.sample_op0,
						  self.Graph.sample_op1,
						  self.Graph.old_distribution0.scale,
						  self.Graph.old_distribution1.scale]
			if self.Parameter.EnvConfig.A_DIM == 3:
				fetches =[self.Graph.sample_op0,
						  self.Graph.sample_op1,
						  self.Graph.sample_op2,
						  self.Graph.old_distribution0.scale,
						  self.Graph.old_distribution1.scale,
						  self.Graph.old_distribution2.scale]
		else:
			if self.Parameter.EnvConfig.A_DIM == 1:
				fetches =[self.Graph.get_mu0,
						  self.Graph.old_distribution0.scale]
			if self.Parameter.EnvConfig.A_DIM == 2:
				fetches =[self.Graph.get_mu0,
						  self.Graph.get_mu1,
						  self.Graph.old_distribution0.scale,
						  self.Graph.old_distribution1.scale]
			if self.Parameter.EnvConfig.A_DIM == 3:
				fetches =[self.Graph.get_mu0,
						  self.Graph.get_mu1,
						  self.Graph.get_mu2,
						  self.Graph.old_distribution0.scale,
						  self.Graph.old_distribution1.scale,
						  self.Graph.old_distribution2.scale]

		feed_dict = {self.Graph.PHstate: State,
					 self.Graph.PHSpeed: [velocity],
					 self.Graph.PHSteering: [steering],
					 self.Graph.PHGoalDistance: [goal_distance]}

		fetched = self.Session.run(fetches,feed_dict)
		a = fetched[:int(len(fetched)/2)]
		sigma = fetched[int(len(fetched)/2):]

		if self.Parameter.EnvConfig.A_DIM == 1:
			a = np.clip(a[0][0],
							  self.Parameter.EnvConfig.A_LOWER_BOUND[0],
							  self.Parameter.EnvConfig.A_UPPER_BOUND[0])
			sigma = sigma[0][0]
		if self.Parameter.EnvConfig.A_DIM == 2:
			a = [np.clip(a[0][0],
						 self.Parameter.EnvConfig.A_LOWER_BOUND[0],
						 self.Parameter.EnvConfig.A_UPPER_BOUND[0]),
				 np.clip(a[1][0],
						 self.Parameter.EnvConfig.A_LOWER_BOUND[0],
						 self.Parameter.EnvConfig.A_UPPER_BOUND[0])
				 ]
			if a[1]>0:
				a = [a[0],a[1],0]
			else:
				a= [a[0],0,-a[1]]

			sigma = [sigma[0][0][0],sigma[1][0][0]]
		if self.Parameter.EnvConfig.A_DIM == 3:
			a = [np.clip(a[0][0],
						 self.Parameter.EnvConfig.A_LOWER_BOUND[0],
						 self.Parameter.EnvConfig.A_UPPER_BOUND[0]),
				 np.clip(a[1][0],
						 self.Parameter.EnvConfig.A_LOWER_BOUND[1],
						 self.Parameter.EnvConfig.A_UPPER_BOUND[1]),
				 np.clip(a[2][0],
						 self.Parameter.EnvConfig.A_LOWER_BOUND[2],
						 self.Parameter.EnvConfig.A_UPPER_BOUND[2])
				 ]
			sigma = [sigma[0][0][0], sigma[1][0][0], sigma[2][0][0]]
		return a, sigma


	def _writeLogData(self,s,eds,done,Evaluation,time):
		self.logParams["RunnerId"]=str(self.RunnerId)
		self.logParams["time/s"]=str(time)
		self.logParams["Local Step"] = str(self.stepcount)
		self.logParams["Local Episode"] = str(self.episodecount)
		self.logParams["AccValueFunc"] = str(self.AccumulatedValueFunction)
		if self.Parameter.EnvConfig.A_DIM==1:
			self.logParams["sigma0"]=str(np.asarray(self.sigmabuffer).mean())
		elif self.Parameter.EnvConfig.A_DIM==2:
			self.logParams["sigma0"] = str(np.asarray([[i[0]] for i in self.sigmabuffer]).mean())
			self.logParams["sigma1"] = str(np.asarray([[i[1]] for i in self.sigmabuffer]).mean())
		else:
			self.logParams["sigma0"] = str(np.asarray([[i[0]] for i in self.sigmabuffer]).mean())
			self.logParams["sigma1"] = str(np.asarray([[i[1]] for i in self.sigmabuffer]).mean())
			self.logParams["sigma2"] = str(np.asarray([[i[2]] for i in self.sigmabuffer]).mean())
		if not Evaluation:
			self.logParams["MemoryUsageEDS(mb)"]= str(ray.get(eds.get_memory_usage.remote()))
		if done:
			self.logParams["done"]="1"
		else:
			self.logParams["done"]="0"

		self.logParams["Reward"] = str(self.episodic_reward)
		fieldnames =[]
		for x, y in self.logParams.items():
			fieldnames.append(x)
		if not os.path.isfile(self.log + '/RewardData.csv'):
			myFile = open(self.log + '/RewardData.csv', 'a')
			with myFile:
				writerResult = csv.DictWriter(myFile, dialect='excel-tab', fieldnames=fieldnames)
				writerResult.writeheader()

		myFile = open(self.log+ '/RewardData.csv', 'a')
		with myFile:
			writerResult = csv.DictWriter(myFile, dialect='excel-tab', fieldnames=fieldnames)
			writerResult.writerows([self.logParams])

	def _checkForSaveState(self,r,LOG_DIR):

		self.EpisodicRewardList.append(r)
		if len(self.EpisodicRewardList) >50:
			self.EpisodicRewardList.pop(0)
		print("Mean Reward over the last "+str(len(self.EpisodicRewardList))+" Episodes",np.asarray(self.EpisodicRewardList).mean())
		if (np.asarray(self.EpisodicRewardList).mean()>=self.SaveIfMeanReward):
			if not os.path.isdir(LOG_DIR + "/SaveData/SafetySaves"):
				os.makedirs(LOG_DIR + "/SaveData/SafetySaves")
			self.Graph.NPsaver.save(self.Session,
									LOG_DIR + "/SaveData/SafetySaves/"+
									"ep_" + str(self.episodecount)+
									"MeanReward_"+str(self.SaveIfMeanReward))
			self.SaveIfMeanReward=np.asarray(self.EpisodicRewardList).mean() + 10

	def reload_net(self,LOG_DIR):
		self.Graph.NPsaver.restore(self.Session, save_path=LOG_DIR + "/SaveData/test")
		return True

	def _run(self,eds,LOG_DIR,Evaluation):

		s = self.Environment._prepare_env()
		#if s is not None:
		frameUnprocessed = s
		s = self.Environment._image_preprocessing(s)

		Batch= []
		BlackZone=False
		t=False
		done = False
		t0 = time.time()
		time.sleep(30)
		if not Evaluation and not self.Parameter.OptimizerConfig.RUN_RAPIDPROTOYPE:
			old_timestamp = time.ctime(os.path.getmtime(LOG_DIR+"/SaveData/checkpoint"))
		dataStep = 0


		while True:

			s_image = self.Environment._env_render()

			a,sigma = self.get_action(s,self.velocity,self.steering,self.goal_distance)

			self.sigmabuffer.append(sigma)

			v = 0
			#self.AccumulatedValueFunction += v

			acc_reward = 0
			s_ = None
			success = False
			for _ in range(self.Parameter.HyperparameterConfig.ACTION_REPEAT_FOR_X_STEPS):

				if (self.Parameter.EnvConfig.A_DIM==1):
					s_,r,done,_ , success= self.Environment._env_step([a, 0.4, 0.0])
				else:
					s_,r,done,_ , success= self.Environment._env_step(a)
				if self.Parameter.ModelConfig.REWARD_NORM:
					r = r / 50

				s_image = self.Environment._env_render()

				if not success:
					assert(False)


				acc_reward +=r
				if done:
					break



			if not success:
				continue

			r = acc_reward
			#print("ACC REWARD : {}\n".format(acc_reward))
			frameUnprocessed = s_
			s_ = self.Environment._image_preprocessing(s_)

			self.stepcount += 1
			#if not Evaluation:
			#	t = self._checkForTerminateState(r)

			t = done

			if done:
				print("TERMINATE STATE REACHED !")


			if self.Parameter.EnvConfig.A_DIM==1 or self.Parameter.EnvConfig.A_DIM==3:
				if self.Parameter.ModelConfig.CONCAT:
					Batch.append([s,r,t,a,self.episodecount,v,self.velocity,self.RunnerId,self.steering,self.goal_distance])
				else:
					Batch.append([s,r,t,a,self.episodecount,v,self.velocity,self.RunnerId])
			else:
				if a[1]==0:
					b = [a[0],-a[2]]
				else:
					b = [a[0],a[1]]
				if self.Parameter.ModelConfig.CONCAT:
					Batch.append([s,r,t,b,self.episodecount,v,self.velocity,self.RunnerId,self.steering,self.goal_distance])

				else:
					Batch.append([s,r,t,b,self.episodecount,v,self.velocity,self.RunnerId])

			# Write to dataset
			if self.Parameter.CreateDataset:
				self.Dataset._addData(frame=frameUnprocessed, step= dataStep) #, step=dataStep, velocity=self.velocity, gyro=self.gyro,#steering=self.steering, reward=r)
			dataStep += 1
			s = s_
			self.velocity = [self.Environment.get_velocity() / 150.0]
			self.steering = [self.Environment.get_steering()]
			self.goal_distance = [self.Environment.get_goal_distance()/5000.0]

			if self.Parameter.ModelConfig.REWARD_NORM:
				self.episodic_reward+=r*50
			else:
				self.episodic_reward+=r

			#self.episodic_reward += r
			if len(Batch)==self.Parameter.HyperparameterConfig.MIN_BATCH_SIZE+1 or\
			t == True or \
			done or \
			self.stepcount > (2000/self.Parameter.HyperparameterConfig.ACTION_REPEAT_FOR_X_STEPS) and Evaluation:

				if not Evaluation:
					ray.get(eds.put_params.remote(Batch))
				temp = Batch[-1]
				Batch=[]
				Batch.append(temp)

				if t == True or done:# and self.episodic_reward >100 :

					Batch = []
					self.episodecount+=1
					if self.RunnerId == 0:
						if self.episodecount % int(
								1000 / self.Parameter.HyperparameterConfig.N_WORKER) == 0 and self.episodecount != 0:
							if not os.path.isdir(LOG_DIR + "/SaveData/SafetySaves"):
								os.makedirs(LOG_DIR + "/SaveData/SafetySaves")
							self.Graph.NPsaver.save(self.Session,
													LOG_DIR + "/SaveData/SafetySaves/ep_" + str(self.episodecount))
					if Evaluation:
						print("Total Reward of Episode is", self.episodic_reward, "from Runner", self.RunnerId,
							  "local episode", self.episodecount, "stepcount", self.stepcount)
					else:
						print("Total Reward of Episode is", self.episodic_reward,"from Runner",self.RunnerId,
							  "local episode", self.episodecount, "stepcount", self.stepcount, "List size",
							  ray.get(eds.get_size.remote()),"EDS memory usage ",ray.get(eds.get_memory_usage.remote()))
					if not Evaluation:
						self._checkForSaveState(self.episodic_reward,LOG_DIR)
					t1 = time.time()
					total = t1 - t0
					self._writeLogData(s,eds,done,Evaluation,total)
					self.sigmabuffer = []
					self.episodic_reward=0
					self.stepcount=0
					self.velocity =[0]
					self.steering = [0]
					self.goal_distance = [0]
					self.AccumulatedValueFunction=0
					#print("ENVIRONMENT RESET : t = {}".format(t))
					#self.Environment._env_reset()

					s = self.Environment._prepare_env()
					s = self.Environment._image_preprocessing(s)
					s_image = self.Environment._env_render()
					t =False
					self.failList = []
					# if self.episodecount > round(self.Parameter.HyperparameterConfig.EP_MAX /
					# 							 self.Parameter.HyperparameterConfig.N_WORKER + 0.49):
					# 	print("Runner",self.RunnerId,"sagt good bye")
					# 	ray.shutdown()
					#if model parameters has changed update Graph
				if not Evaluation and not self.Parameter.OptimizerConfig.RUN_RAPIDPROTOYPE:
					new_timestamp = time.ctime(os.path.getmtime(LOG_DIR+"/SaveData/checkpoint"))
					t1 = datetime.strptime(old_timestamp[8:], "%d %H:%M:%S %Y")
					t2 = datetime.strptime(new_timestamp[8:], "%d %H:%M:%S %Y")
					difference = t1 - t2
					if (difference.seconds > 0.1):
						old_timestamp = new_timestamp
						result = None
						while result is None:
							try:
								# connect
								result = self.reload_net(LOG_DIR)
							except:
								print("couldnt load will try again, Runner ", self.RunnerId)
								pass

						#print(self.Graph.NPsaver.restore(self.Session, save_path=LOG_DIR+"/SaveData/test"))
						print("Runner ", self.RunnerId, " updated his graph")