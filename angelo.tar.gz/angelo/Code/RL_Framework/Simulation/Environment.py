import gym
import cv2
from Config import *
import numpy as np
import scipy
import deepgtav
from deepgtav.messages import Start, Stop, Scenario, Commands, frame2numpy, RestartEpisode
from deepgtav.client import Client



class Gym_Environment(object):
	def __init__(self,env_id,Parameter,state_dim):
		self.Parameter= Parameter
		self.ID = env_id
		self.intigier=0
		self.state_dim = state_dim

	def _create_environment(self,env_name,seed = None):
		self.Environment = gym.make(env_name).unwrapped
		if seed != None:
			self.Environment.seed(seed)
			print("Seed "+str(seed)+" generated")

	def compress(self, value):
		xlow, xhigh = (-0.21, -0.17)
		ylow, yhigh = (-0.3, 0.0)
		if xlow < value < xhigh:
			return ylow + (value - xlow) / (xhigh - xlow) * (yhigh - ylow)
		else:
			return value

	def compress_image(self, image):
		retImag = np.zeros(shape=image.shape)
		for j in range(image.shape[0]):
			for k in range(image.shape[1]):
				retImag[j, k, 0] = self.compress(image[j, k, 0])

		return retImag


	def _image_preprocessing(self,state):
		color_dim =3
		if self.Parameter.EnvConfig.CROPIMAGE:
			img = state[self.Parameter.EnvConfig.FROM_Y:self.Parameter.EnvConfig.TO_Y,
				  self.Parameter.EnvConfig.FROM_X:self.Parameter.EnvConfig.TO_X]  # we crop side of screen as they carry little information
		else:
			img = state
		if self.Parameter.EnvConfig.GREYSCALE:
			img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
			color_dim = 1
		img = img.astype('float')
		if self.Parameter.EnvConfig.MEANSHIFT:
			img[:, :] -= 127.0
			img = img / 127.0
		else:
			img = img / 255.0
		if self.Parameter.EnvConfig.CROPIMAGE:
			img= img.reshape(self.Parameter.EnvConfig.TO_Y-self.Parameter.EnvConfig.FROM_Y,
							   self.Parameter.EnvConfig.TO_X- self.Parameter.EnvConfig.FROM_X, color_dim)
			if self.Parameter.EnvConfig.IMAGECOMPRESSION and self.Parameter.EnvConfig.GREYSCALE:
				img = self.compress_image(img)
			return img
		else:
			img = img.reshape(self.state_dim[0],self.state_dim[1],self.state_dim[2])
			return img

	def _env_step(self,action):
		observation, reward, done, info = self.Environment.step(action)
		return observation, reward, done, info

	def _env_reset(self):
		self.Environment.seed()
		return self.Environment.reset()


	def _env_render(self):
		s_image = self.Environment.render()
		return s_image

	def _prepare_env(self):
		for _ in range(50):
			s, _, _, _ = self._env_step([0,0,0])
		return s

	def _close_env(self):
		self.Environment.close()

	def _get_state_parameter(self):
		return	self.Environment.metadata

	def get_velocity(self):
		return np.sqrt(np.square(self.Environment.car.hull.linearVelocity[0]) +
					   np.square(self.Environment.car.hull.linearVelocity[1]))

	def get_gyro(self):
		return self.Environment.car.hull.angularVelocity

	def get_steering(self):
		return self.Environment.car.wheels[0].joint.angle


class GTA_Environment(object):
	# def __init__(self,env_id,Parameter,state_dim):
	def __init__(self, env_id, Parameter, state_dim , ip_address):
		self.Parameter = Parameter
		self.ID = env_id
		self.intigier = 0
		self.state_dim = state_dim

		#self.IP = self.Parameter.Client.IP
		self.IP = ip_address
		self.port = self.Parameter.Client.PORT
		print("IP = " + str(self.IP))
		print("PORT = " + str(self.port))
		self.Client = Client(ip=self.IP, port=self.port, compressionLevel=9)
		self.Message = None
		self.index = 0

	def _create_environment(self, seed=None):
		# Init environment
		# connect to server

		# send start

		print("Connect to GTAV")
		scenario = Scenario(drivingMode=-1, location=self.Parameter.GTAV.START_POS)  # manual driving
		print("send start message")
		self.Client.sendMessage(Start(scenario=scenario))
		# wait for message to come back
		message = None
		while message == None:
			message = self.Client.recvMessage()

		print("Init message received :")
		print("Environment has been initialized")
		#print("Message = " + str(message))

	def compress(self, value):
		xlow, xhigh = (-0.21, -0.17)
		ylow, yhigh = (-0.3, 0.0)
		if xlow < value < xhigh:
			return ylow + (value - xlow) / (xhigh - xlow) * (yhigh - ylow)
		else:
			return value

	def compress_image(self, image):
		retImag = np.zeros(shape=image.shape)
		for j in range(image.shape[0]):
			for k in range(image.shape[1]):
				retImag[j, k, 0] = self.compress(image[j, k, 0])

		return retImag

	def _image_preprocessing(self, state):
		color_dim = 3

		#print("state_dim = {}".format(state.shape))

		if self.Parameter.EnvConfig.CROPIMAGE:
			img = state[self.Parameter.EnvConfig.FROM_Y:self.Parameter.EnvConfig.TO_Y,
				  self.Parameter.EnvConfig.FROM_X:self.Parameter.EnvConfig.TO_X]
			#print("return image")
			#print("state_dim = {}".format(img.shape))


		else:
			img = state
		if self.Parameter.EnvConfig.GREYSCALE:
			img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
			color_dim = 1
		img = img.astype('float')

		if self.Parameter.EnvConfig.MEANSHIFT:
			img[:, :] -= 127.0
			img = img / 127.0
		else:
			img = img / 255.0

		#cv2.imwrite("imgrSTATE" + str(self.index) + ".png", img)
		#self.index += 1

		#print(str(img))
		if self.Parameter.EnvConfig.CROPIMAGE:
			img = img.reshape(self.Parameter.EnvConfig.TO_Y - self.Parameter.EnvConfig.FROM_Y,
							  self.Parameter.EnvConfig.TO_X - self.Parameter.EnvConfig.FROM_X, color_dim)
			if self.Parameter.EnvConfig.IMAGECOMPRESSION and self.Parameter.EnvConfig.GREYSCALE:
				img = self.compress_image(img)
			#return img
		else:
			img = img.reshape(self.state_dim[0], self.state_dim[1], self.state_dim[2])


		return img

	def _env_step(self, action):
		# observation, reward, done, info = self.Environment.step(action)
		# return observation, reward, done, info
		a1 = float(action[0])
		a2 = float(action[1])
		a3 = float(action[2])


		#print("actions = " + str(action))

		#a2 =0.0
		a3 = 0
		#if self.Message != None:
		#	if  "velocity" in self.Message:
		#		velocity_old = self.Message["velocity"]

		#		if velocity_old < 0.01:
		#			a2 = 0.0
		#			print("actions new = " + str(action))

		#PPO
		#a1 : Steering
		#a2 : Throttle
		#a3 : Brake

		#GTA
		#self.Client.sendMessage(Commands(throttle, steering, brake))

		#print("send commands")
		self.Client.sendMessage(Commands(a2, a1, a3))

		message = None
		while message == None:
			message = self.Client.recvMessage()

		self.Message = message
		reward = message["reward"]
		collided = message["collided"]
		agentPos = message["position"]
		velocity = message["velocity"]
		w, h, _ = message["imageSize"]
		state = frame2numpy(message['frame'], (int(w), int(h)))


		#state = state[20:600, 0:800]
		state = cv2.cvtColor(state,cv2.COLOR_BGR2RGB)

		state = cv2.resize(state, (self.Parameter.EnvConfig.S_DIM[1], self.Parameter.EnvConfig.S_DIM[0]))
		done = collided
		if(collided):
			print("collided")

		#print("collided = " + str(collided))
		#print("velocity = " + str(velocity))
		#print("reward = " + str(reward))

		return state, reward, done, 0  # , state

	def _env_reset(self):
		#self.Environment.seed

		self.Client.sendMessage(RestartEpisode())
		#return self.Environment.reset()

	def _env_render(self):
		#self.Environment.render()
		return
		#print("TODO: ENV RENDER")

	def _prepare_env(self):
		#for _ in range(50):
		s, _, _, _ = self._env_step([0, 0, 0])
		return s

	def _close_env(self):
		#self.Environment.close()
		self.Client.sendMessage(Stop())

	def _get_state_parameter(self):
		return self.Environment.metadata

	def get_velocity(self):

		if float(self.Message["velocity"]) is None:
			return 0.0
		else:
			return float(self.Message["velocity"])
		#return np.sqrt(np.square(self.car.hull.linearVelocity[0]) +
		#			   np.square(self.car.hull.linearVelocity[1]))

	def get_gyro(self):

		return 0.0#self.Environment.car.hull.angularVelocity

	def get_steering(self):
		return 0.0#self.Environment.car.wheels[0].joint.angle
