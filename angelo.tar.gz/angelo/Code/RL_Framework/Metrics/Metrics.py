from Config import *

import numpy as np


class Metric():
    def __init__(self, w_init, S_DIM, globalstep, Parameter, name, state_dim, Action0, Action1=None, Action2=None):

        ##LSTM_LAYER
        self.LSTM_UNITS = 100
        self.LSTM_LAYERS = 2
        self.LSTM_BATCH_SIZE = tf.placeholder(shape=(), dtype=tf.int32 , name ="lstm_batch_size")

        self.LSTM_INIT_STATE = tf.zeros(shape=(self.LSTM_LAYERS , 2, 1, self.LSTM_UNITS))
        l = tf.unstack(self.LSTM_INIT_STATE, axis=0)
        self.LSTM_INIT_STATE = tuple([tf.nn.rnn_cell.LSTMStateTuple(l[idx][0],l[idx][1]) for idx in range(self.LSTM_LAYERS)])

        self.LSTM_FINAL_STATE = None
        self.LSTM_KEEP_PROB = tf.placeholder(tf.float32, name='dropout_keep_prob')

        self.state_dim = state_dim
        self.Parameter = Parameter
        self.learning_rate_Spe_ret = tf.train.exponential_decay(learning_rate=self.Parameter.HyperparameterConfig.C_LR,
                                                                global_step=globalstep,
                                                                decay_steps=self.Parameter.HyperparameterConfig.DECAY_STEP,
                                                                decay_rate=self.Parameter.HyperparameterConfig.DECAY_RATE,
                                                                staircase=self.Parameter.HyperparameterConfig.DECAY_STAIRCASE)
        self.tfdc_r = tf.placeholder(tf.float32, [None, 1], 'discounted_r')
        self.tfdret = tf.placeholder(tf.float32, [None, 1], 'reward_t1')
        self.tfdret0 = tf.placeholder(tf.float32, [None, 1], 'reward_t0')
        self.tfdspe = tf.placeholder(tf.float32, [None, 1], 'speed_t1')
        self.tfdspe2 = tf.placeholder(tf.float32, [None, 1], 'speed_t2')
        self.tfdsta2 = tf.placeholder(tf.float32, [None] + list(S_DIM), 'new_state')
        self.tfdsta = tf.placeholder(tf.float32, [None] + list(S_DIM), 'old_state')


        self.stateparameter2 = tf.placeholder(tf.float32, [None, 1], 'stateparameter2')
        self.speOut, self.LSTM_FINAL_STATE = self._build_SpeedEst("Spe1", w_init)
        self.spe2Out = self._build_SpeedEst2("Spe2", w_init)

        self.retOut = self._build_ReturnEst("Ret1", w_init)
        self.ret2Out = self._build_ReturnEst2("Ret2", w_init)
        self.ret3Out = self._build_ReturnEst3("Ret3", w_init, Action0, Action1, Action2)
        self.OPT_SR = tf.train.AdamOptimizer(self.learning_rate_Spe_ret, name='AdamOptSperet')

        ##VAE##
        self.kernel_initializer = tf.keras.initializers.glorot_uniform()
        self.VAE_INPUT = tf.placeholder(tf.float32, [None] + list(S_DIM), 'VAE_INPUT')
        self.VAE_SAMPLE = tf.placeholder_with_default(tf.constant(0.0), shape=())

        self.VAE_BATCH_SIZE = tf.placeholder(shape=(), dtype=tf.int32)
        self.VAE_LATENT_DIM = 25
        self.VAE_MEAN, self.VAE_LOGVAR = self._build_VAE_Encoder(net_input=self.VAE_INPUT, name="VAE")
        self.VAE_Z = self._build_VAE_Reparameterize(mean=self.VAE_MEAN, logvar=self.VAE_LOGVAR, name="VAE")
        self.VAE_DECODER = self._build_VAE_Decoder(z=self.VAE_Z, name="VAE")
        tf.summary.image("input", self.VAE_INPUT)
        tf.summary.image("reconstructions", self.VAE_DECODER)

        #######

        self.spe_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/Spe1")
        self.spe2_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/Spe2")

        self.ret_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/Ret1")
        self.ret2_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/Ret2")
        self.ret3_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/Ret3")
        self.VAE_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/VAE")

        self.VAE_SPEED_ESTIMATE, self.VAE_LSTM_INIT_STATE, self.VAE_LSTM_STATE = self._build_SpeedEst3("Spe3", self.VAE_MEAN)
        self.spe3_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name + "/Spe3")
        self.spe_loss = 1000.0*tf.reduce_mean(tf.square(self.speOut - self.tfdspe))
        self.spe2_loss = 1000.0*tf.reduce_mean(tf.square(self.spe2Out - self.tfdspe2))
        self.spe3_loss = 1000.0*tf.reduce_mean(tf.square(self.VAE_SPEED_ESTIMATE - self.tfdspe))

        self.ret_loss = tf.reduce_mean(tf.square(self.retOut - self.tfdret0))
        self.ret2_loss = tf.reduce_mean(tf.square(self.ret2Out - self.tfdret))
        self.ret3_loss = tf.reduce_mean(tf.square(self.ret3Out - self.tfdret))

        self.VAE_RECON_LOSS, self.VAE_KL_LOSS, self.VAE_LOSS = self._VAE_compute_loss(decoder=self.VAE_DECODER,
                                                                                      image_label=self.VAE_INPUT,
                                                                                      mean=self.VAE_MEAN,
                                                                                      logvar=self.VAE_LOGVAR,
                                                                                      z=self.VAE_Z)

        tf.summary.scalar("VAE_LOSS", self.VAE_LOSS)
        tf.summary.scalar("VAE_MSE_LOSS", tf.reduce_mean(self.VAE_RECON_LOSS))
        tf.summary.scalar("VAE_KL_LOSS", tf.reduce_mean(self.VAE_KL_LOSS))

        tf.summary.scalar("spe_loss_LSTM", self.spe_loss)
        tf.summary.scalar("spe2_loss", self.spe2_loss)
        tf.summary.scalar("spe3_loss_VAE_MEAN", self.spe3_loss)
        #tf.summary.scalar("ret1_loss", self.ret_loss)
        #tf.summary.scalar("ret2_loss", self.ret2_loss)
        #tf.summary.scalar("ret3_loss", self.ret3_loss)

        self.spe_grads = tf.gradients(self.spe_loss, self.spe_params)
        self.spe_train_op = self.OPT_SR.minimize(self.spe_loss, var_list=self.spe_params)

        self.spe2_grads = tf.gradients(self.spe2_loss, self.spe2_params)
        self.spe3_grads = tf.gradients(self.spe3_loss, self.spe3_params)

        self.ret_grads = tf.gradients(self.ret_loss, self.ret_params)
        self.ret2_grads = tf.gradients(self.ret2_loss, self.ret2_params)
        self.ret3_grads = tf.gradients(self.ret3_loss, self.ret3_params)
        self.VAE_grads = tf.gradients(self.VAE_LOSS, self.VAE_params)

        self.placeholder_spe_gradients = []
        for grad_var in self.spe_grads:
            self.placeholder_spe_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))
        self.placeholder_spe2_gradients = []
        for grad_var in self.spe2_grads:
            self.placeholder_spe2_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))

        self.placeholder_spe3_gradients = []
        for grad_var in self.spe3_grads:
            self.placeholder_spe3_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))

        self.placeholder_ret_gradients = []
        for grad_var in self.ret_grads:
            self.placeholder_ret_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))
        self.placeholder_ret2_gradients = []
        for grad_var in self.ret2_grads:
            self.placeholder_ret2_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))
        self.placeholder_ret3_gradients = []
        for grad_var in self.ret3_grads:
            self.placeholder_ret3_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))


        self.placeholder_VAE_gradients = []
        for grad_var in self.VAE_grads:
            self.placeholder_VAE_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))

        self.apply_spe_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_spe_gradients, self.spe_params))
        self.apply_spe2_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_spe2_gradients, self.spe2_params))
        self.apply_spe3_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_spe3_gradients, self.spe3_params))

        self.apply_ret_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_ret_gradients, self.ret_params))
        self.apply_ret2_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_ret2_gradients, self.ret2_params))
        self.apply_ret3_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_ret3_gradients, self.ret3_params))

        self.apply_VAE_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_VAE_gradients, self.VAE_params))

    def _build_SpeedEst(self, name, w_init):
        with tf.variable_scope(name):
            conv1 = tf.layers.conv2d(name="retconv1", inputs=self.tfdsta, filters=32, kernel_size=(4, 4),
                                     strides=(2, 2),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            conv2 = tf.layers.conv2d(name="retconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            conv3 = tf.layers.conv2d(name="retconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
                                     activation=tf.nn.relu, kernel_initializer=w_init)

            print("scope : FE : ")
            print(conv3.shape)


            print("SPEED ESTIMATOR:")
            state_in = tf.layers.flatten(conv3)
            #state_in = outputs_conv_lstm
            print(state_in)

            # LSTM layer

            num_units = []
            for _ in range(self.LSTM_LAYERS):
                num_units.append(self.LSTM_UNITS)
            cells = [tf.nn.rnn_cell.LSTMCell(num_units=n) for n in num_units]

            self.spe_lstm = tf.nn.rnn_cell.MultiRNNCell(cells)
            #self.spe_lstm = a_lstm

            #self.LSTM_INIT_STATE = a_lstm.zero_state(batch_size=1, dtype=tf.float32)

            lstm_in = tf.expand_dims(state_in, axis=0)

            print("LSTM IN SHA")

            print("LSTM IN : \n{}".format(lstm_in))

            a_outputs, a_final_state = tf.nn.dynamic_rnn(cell=self.spe_lstm, inputs=lstm_in, initial_state=self.LSTM_INIT_STATE)
            #switch again BS with TS
            a_outputs = tf.transpose(a_outputs, [1,0,2])

            #get last element
            last = a_outputs[-1] #tf.gather_nd(a_outputs, int(a_outputs.shape[0] - 1))
            print("last shape : {}".format(last.shape))

            out = tf.layers.dense(last, 1, name='retls1', kernel_initializer=w_init)

            ########

            #out = tf.layers.dense(a_cell_out, 1, kernel_initializer=w_init)
        return out ,a_final_state

    def _build_SpeedEst2(self, name, w_init):
        with tf.variable_scope(name):
            # conLF1c = tf.layers.dense(self.stateparameter2, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
            # conLF2c = tf.layers.dense(conLF1c, self.state_dim[0] * self.state_dim[1], tf.nn.relu, name='conLF2c',
            #                          kernel_initializer=w_init)
            # conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1], 1])
            #
            # concat = tf.concat(values=[self.tfdsta, conLF2cReshapeC], axis=3)

            conv1 = tf.layers.conv2d(name="speconv1", inputs=self.tfdsta, filters=32, kernel_size=(4, 4),
                                     strides=(2, 2),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            conv2 = tf.layers.conv2d(name="speconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            conv3 = tf.layers.conv2d(name="speconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            nn = tf.layers.flatten(conv3)

            for i in range(self.LSTM_LAYERS):
                nn = tf.layers.dense(nn, self.LSTM_UNITS, tf.nn.relu, name='speed_dense_{}'.format(i),
                                     kernel_initializer=w_init)

            out = tf.layers.dense(nn, 1, name='spels1', kernel_initializer=w_init)
        return out

    def _build_SpeedEst3(self, name, input):
        with tf.variable_scope(name):
            # if self.estimator_training_config.lstm_cell:
            #	lstm_cell = tf.nn.rnn_cell.LSTMCell(num_units=self.LSTM_UNITS, forget_bias=1.0)
            #	state_fw = lstm_cell.zero_state(self.batch_size, dtype = tf.float32)
            #	print("lstm_cell")
            #	print(lstm_cell)
            #	output_lstm, state_lstm_decoder = tf.nn.dynamic_rnn(lstm_cell, inputs=net_input, dtype='float32', initial_state = state_fw)
            #	nn = output_lstm
            #	nn = tf.reduce_mean(nn, axis=1)
            # else:
            #	nn = net_input

            #nn = tf.layers.dense(input,
            #                     units=self.VAE_LATENT_DIM * 2,
            #                     kernel_initializer=self.kernel_initializer,
            #                     name='Dense_Layer_1', activation=tf.nn.relu)
            #print(nn)
            ## nn = tf.nn.dropout(nn, rate=dropout_rate)
#
            #nn = tf.layers.dense(nn,
            #                     units=self.VAE_LATENT_DIM,
            #                     kernel_initializer=self.kernel_initializer,
            #                     name='Dense_Layer_2',
            #                     activation=tf.nn.relu)
            #print(nn)
            ## nn = tf.nn.dropout(nn, rate=dropout_rate)
#
            ## LSTM layer

            num_units = []
            for _ in range(self.LSTM_LAYERS):
                num_units.append(self.LSTM_UNITS)
            cells = [tf.nn.rnn_cell.LSTMCell(num_units=n) for n in num_units]

            a_lstm = tf.nn.rnn_cell.MultiRNNCell(cells)

            vae_lstm_init_state = a_lstm.zero_state(batch_size=1, dtype=tf.float32)
            lstm_in = tf.expand_dims(input, axis=0)

            print("LSTM IN SHA")

            print("LSTM IN : \n{}".format(lstm_in))

            vae_lstm_outputs, vae_lstm_final_state = tf.nn.dynamic_rnn(cell=a_lstm, inputs=lstm_in, initial_state=vae_lstm_init_state)
            #switch again BS with TS
            vae_lstm_outputs = tf.transpose(vae_lstm_outputs, [1,0,2])

            #get last element
            last = vae_lstm_outputs[-1] #tf.gather_nd(a_outputs, int(a_outputs.shape[0] - 1))

            nn = tf.layers.dense(last,
                                 units=1,
                                 kernel_initializer=self.kernel_initializer,
                                 name='Estimator_Output')


            print(nn)
            # assert(False)
            return nn, vae_lstm_init_state, vae_lstm_final_state

    def _build_ReturnEst(self, name, w_init):
        with tf.variable_scope(name):
            conv1 = tf.layers.conv2d(name="retconv1", inputs=self.tfdsta, filters=32, kernel_size=(4, 4),
                                     strides=(2, 2),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            conv2 = tf.layers.conv2d(name="retconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            conv3 = tf.layers.conv2d(name="retconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            state_in = tf.layers.flatten(conv3)

            out = tf.layers.dense(state_in, 1, name='retls1', kernel_initializer=w_init)
        return out

    def _build_ReturnEst2(self, name, w_init):
        with tf.variable_scope(name):
            conLF1c = tf.layers.dense(self.stateparameter2, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
            conLF2c = tf.layers.dense(conLF1c, self.state_dim[0] * self.state_dim[1], tf.nn.relu, name='conLF2c',
                                      kernel_initializer=w_init)
            conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1], 1])

            concat = tf.concat(values=[self.tfdsta, conLF2cReshapeC], axis=3)

            conv1 = tf.layers.conv2d(name="speconv1", inputs=concat, filters=32, kernel_size=(4, 4), strides=(2, 2),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            conv2 = tf.layers.conv2d(name="speconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            conv3 = tf.layers.conv2d(name="speconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            state_in = tf.layers.flatten(conv3)

            lafc = tf.layers.dense(state_in, 40, tf.nn.relu, name='lafc', kernel_initializer=w_init)
            out = tf.layers.dense(lafc, 1, name='spels1', kernel_initializer=w_init)
        return out

    def _build_ReturnEst3(self, name, w_init, Action0, Action1, Action2):
        with tf.variable_scope(name):
            # conA0 = tf.layers.dense(Action0[:-1], 100, tf.nn.relu, name='conA0', kernel_initializer=w_init)
            # conA0 = tf.layers.dense(conA0, self.state_dim[0]* self.state_dim[1], tf.nn.relu, name='conA02', kernel_initializer=w_init)
            # conA0 = tf.reshape(conA0, [-1, self.state_dim[0], self.state_dim[1], 1])
            #
            # if Action1 != None:
            # 	conA1 = tf.layers.dense(Action1[:-1], 100, tf.nn.relu, name='conA1', kernel_initializer=w_init)
            # 	conA1 = tf.layers.dense(conA1, self.state_dim[0]* self.state_dim[1], tf.nn.relu, name='conA12', kernel_initializer=w_init)
            # 	conA1 = tf.reshape(conA1, [-1, self.state_dim[0], self.state_dim[1], 1])
            # 	conA0 = tf.concat(values=[conA0, conA1], axis=3)
            #
            # if Action2 != None:
            # 	conA2 = tf.layers.dense(Action2[:-1], 100, tf.nn.relu, name='conA2', kernel_initializer=w_init)
            # 	conA2 = tf.layers.dense(conA2, self.state_dim[0]* self.state_dim[1], tf.nn.relu, name='conA22', kernel_initializer=w_init)
            # 	conA2 = tf.reshape(conA2, [-1, self.state_dim[0], self.state_dim[1], 1])
            # 	conA0 = tf.concat(values=[conA0, conA2], axis=3)

            # print(conA0.shape)
            # conLF1c = tf.layers.dense(self.stateparameter2, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
            # conLF2c = tf.layers.dense(conLF1c, self.state_dim[0]* self.state_dim[1], tf.nn.relu, name='conLF2c', kernel_initializer=w_init)
            # conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1], 1])

            # concat = tf.concat(values=[self.tfdsta,self.tfdsta2,conA0], axis=3)
            conLF1c = tf.layers.dense(self.stateparameter2, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
            conLF2c = tf.layers.dense(conLF1c, self.state_dim[0] * self.state_dim[1], tf.nn.relu, name='conLF2c',
                                      kernel_initializer=w_init)
            conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1], 1])

            concat = tf.concat(values=[self.tfdsta, conLF2cReshapeC], axis=3)

            conv1 = tf.layers.conv2d(name="speconv1", inputs=concat, filters=32, kernel_size=(4, 4), strides=(2, 2),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            conv2 = tf.layers.conv2d(name="speconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            conv3 = tf.layers.conv2d(name="speconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
                                     activation=tf.nn.relu, kernel_initializer=w_init)
            state_in = tf.layers.flatten(conv3)

            lafc = tf.layers.dense(state_in, self.LSTM_UNITS, tf.nn.relu, name='lafc', kernel_initializer=w_init)

            print()
            if Action2 != None:
                concat = tf.concat(values=[lafc, Action2[:-1], Action1[:-1], Action0[:-1]], axis=1)

            elif Action1 != None:
                concat = tf.concat(values=[lafc, Action1[:-1], Action0[:-1]], axis=1)
            else:
                concat = tf.concat(values=[lafc, Action0[:-1]], axis=1)

            out = tf.layers.dense(concat, 1, name='spels1', kernel_initializer=w_init)

        # print(out)
        # assert(False)
        return out

    def _build_VAE_Encoder(self, net_input, name):
        with tf.variable_scope(name):
            with tf.variable_scope('Encoder'):
                #nn = tf.layers.conv2d(
                #    inputs=net_input,
                #    filters=32,
                #    kernel_size=7,
                #    strides=(1, 1),
                #    activation=tf.nn.relu,
                #    dilation_rate=(3, 3),
                #    kernel_initializer=self.kernel_initializer,
                #    padding="same",
                #    name="CNN_Layer_1")

                #print("First Layer : {}".format(nn))
                #nn = tf.layers.conv2d(inputs=net_input,
                #                      filters=32,
                #                      kernel_size=5,
                #                      strides=(1, 1),
                #                      activation=tf.nn.relu,
                #                      kernel_initializer=self.kernel_initializer,
                #                      dilation_rate=(2, 2),
                #                      padding="same",
                #                      name="CNN_Layer_2")
                #print("Second Layer : {}".format(nn))
                nn = tf.layers.conv2d(inputs=net_input,
                                      filters=32,
                                      kernel_size=5,
                                      strides=(1, 1),
                                      activation=tf.nn.relu,
                                      kernel_initializer=self.kernel_initializer,
                                      dilation_rate=(2, 2),
                                      name="CNN_Layer_3")

                print("Third Layer : {}".format(nn))
                nn = tf.layers.conv2d(inputs=nn,
                                      filters=64,
                                      kernel_size=3,
                                      strides=(2, 2),
                                      activation=tf.nn.relu,
                                      kernel_initializer=self.kernel_initializer,
                                      name="CNN_Layer_4")

                print("Fourth Layer : {}".format(nn))
                nn = tf.layers.conv2d(inputs=nn,
                                      filters=64,
                                      kernel_size=3,
                                      strides=(2, 2),
                                      activation=tf.nn.relu,
                                      kernel_initializer=self.kernel_initializer,
                                      name="CNN_Layer_5")
                print("Fifth Layer : {}".format(nn))

                nn = tf.layers.flatten(nn)

                mean = tf.layers.dense(nn,
                                       units=self.VAE_LATENT_DIM,
                                       kernel_initializer=self.kernel_initializer,
                                       name='Mean')

                logvar = tf.layers.dense(nn,
                                         units=self.VAE_LATENT_DIM,
                                         kernel_initializer=self.kernel_initializer,
                                         name='Logvar')

            return mean, logvar

    def _build_VAE_Reparameterize(self, mean, logvar, name):
        with tf.variable_scope(name):
            with tf.variable_scope("Reparameterize"):
                # reparameterize
                eps = tf.random.normal(shape=(self.VAE_BATCH_SIZE, self.VAE_LATENT_DIM))
                z = self.VAE_SAMPLE * eps * tf.exp(logvar * .5) + mean
                return z

    def _build_VAE_Decoder(self, z, name):
        with tf.variable_scope(name):
            with tf.variable_scope('DECODER'):
                nn = tf.layers.dense(z, units=10 * 10 * 64,
                                     name='Dense_Layer_1',
                                     kernel_initializer=self.kernel_initializer)
                nn = tf.reshape(nn, [self.VAE_BATCH_SIZE, 10, 10, 64])
                nn = tf.layers.conv2d_transpose(inputs=nn,
                                                filters=64,
                                                kernel_size=3,
                                                strides=(2, 2),
                                                padding="same",
                                                activation=tf.nn.relu,
                                                kernel_initializer=self.kernel_initializer,
                                                name="CNN_Transpose_Layer_1")

                print("First Layer : {}".format(nn))

                nn = tf.layers.conv2d_transpose(inputs=nn,
                                                filters=32,
                                                kernel_size=3,
                                                strides=(2, 2),
                                                padding="same",
                                                kernel_initializer=self.kernel_initializer,
                                                name="CNN_Transpose_Layer_3",
                                                activation=tf.nn.relu)
                print("Third Layer : {}".format(nn))
                nn = tf.layers.conv2d_transpose(inputs=nn,
                                                filters=3,
                                                kernel_size=3,
                                                strides=(1, 1),
                                                padding="same",
                                                kernel_initializer=self.kernel_initializer,
                                                name="CNN_Transpose_Layer_4",

                                                )

                print("Fourth Layer : {}".format(nn))
                decoder_out = tf.math.tanh(nn)

        return decoder_out

    def _VAE_compute_loss(self, decoder, image_label, mean, logvar, z):

        def log_normal_pdf(sample, mean, logvar, raxis=1):
            log2pi = tf.math.log(2. * np.pi)
            return tf.reduce_sum(-.5 * ((sample - mean) ** 2. * tf.exp(-logvar) + logvar + log2pi), axis=raxis)

        logits_flat = tf.layers.flatten(decoder)
        labels_flat = tf.layers.flatten(image_label)
        print(logits_flat)
        print(labels_flat)

        # mse
        recon_loss = tf.math.pow(tf.subtract(labels_flat, logits_flat), 2)

        print("reconstruction_loss : {}".format(recon_loss))

        print(tf.shape(recon_loss))
        print(recon_loss)

        logpx_z = tf.reduce_sum(recon_loss, axis=1)
        # logpx_z = tf.reduce_mean(recon_loss, axis=1)

        reconstruction_loss = logpx_z
        print("logpx_loss : {}".format(logpx_z))
        log_P = log_normal_pdf(z, 0., 1.)
        log_Q = log_normal_pdf(z, mean, logvar)
        print("logqx_loss : {}".format(log_Q))
        # self.kl_loss = -tf.reduce_sum(logpz- logqz_x )
        kl_loss = -(log_P - log_Q)
        print("kl_loss{}".format(kl_loss))
        elbo_loss = tf.reduce_mean(logpx_z + kl_loss)

        # loss_summary = tf.summary.scalar("loss", elbo_loss)
        # tf_summaries.append(loss_summary)
        return reconstruction_loss, kl_loss, elbo_loss
