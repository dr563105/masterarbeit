from Runner import Runner
import time
import os
import ray
from Runner import Runner
from Utils import XMLReader,XMLWriter
from Config import Parameter
import psutil
import csv
import sys
def get_state_dimension(Parameter):
	'''
	calculate the State Dimension
	which depends on the image dimensions and processings
	:return: state dimension
	'''
	state_dim = Parameter.EnvConfig.S_DIM
	if Parameter.EnvConfig.CROPIMAGE:
		state_dim = tuple([Parameter.EnvConfig.TO_X-Parameter.EnvConfig.FROM_X,
						   Parameter.EnvConfig.TO_Y-Parameter.EnvConfig.FROM_Y,state_dim[2]])
	if Parameter.EnvConfig.GREYSCALE:
		state_dim = tuple([state_dim[0],state_dim[1],1])
	return state_dim

def OverwriteParams(MEC_File,Params):
	commands = []
	for i, lines in enumerate(MEC_File, 0):
		if lines.find("$") != -1:
			commands.append(i)
	for i in range(commands[0]):
		line = MEC_File[i]
		line.replace("\n", "")
		line = line.split("=")
		if len(line) != 2:
			assert False
		if line[1].find("[") != -1:
			line[1] = line[1].replace("[", "")
			line[1] = line[1].replace("]", "")
			line[1] = list(map(int, line[1].split(",")))
		print("Params.{} = {}".format(line[0], line[1]))
		exec("Params.{} = {}".format(line[0], line[1]))
	print("command length", len(commands))
	return Params

def MultipleExecution(Params):
	commands = []
	file = open("Utils/MultiExecutionConfigEvaluator.txt", "r")
	MEC_File = file.readlines()
	for i, lines in enumerate(MEC_File, 0):
		if lines.find("$") != -1:
			commands.append(i)
	for i in range(commands[0]):
		line = MEC_File[i]
		line.replace("\n", "")
		line = line.split("=")
		if len(line) != 2:
			assert False
		if line[1].find("[") != -1:
			line[1] = line[1].replace("[", "")
			line[1] = line[1].replace("]", "")
			line[1] = list(map(int, line[1].split(",")))
		print("Params.{} = {}".format(line[0], line[1]))
		exec("Params.{} = {}".format(line[0], line[1]))
	print("command length", len(commands))
	file = open("Utils/MultiExecutionConfigEvaluator.txt", "w")

	for i in range(commands[0] + 1, len(MEC_File)):
		file.write(MEC_File[i])

	if len(commands)==1:
		lastRound = True
	else:
		lastRound= False

	return Params,lastRound,MEC_File

def restart_program():
	"""Restarts the current program, with file objects and descriptors
	   cleanup
	"""

	p = psutil.Process(os.getpid())
	for handler in p.open_files() + p.connections():
		os.close(handler.fd)

	python = sys.executable
	os.execl(python, python, *sys.argv)

if __name__ == '__main__':

	# LogData
	ts = time.gmtime()

	# Init Multiprocessing
	ray.init()

	Params = Parameter()



	if Params.MultipleExecution == True:
		Params , lastRound, MEC_File = MultipleExecution(Params)
	else:
		lastRound = True


	PARAM_DIR = Params.ModelConfig.PARAM_DIR
	RESTORE_DIR = Params.ModelConfig.RESTORE_DIR
	Params = XMLReader.XMLReader(PARAM_DIR + "/Hyperparameter.xml")
	Params.ModelConfig.RESTORE_MODEL = True
	Params.ModelConfig.RESTORE_DIR = RESTORE_DIR
	Params.ModelConfig.PARAM_DIR = PARAM_DIR
	Params.ModelConfig.STOCHASTIC_ACTION_SELECTION = False
	LOG_DIR = PARAM_DIR+"/Evaluation/"+ time.strftime("%Y-%m-%d_%H:%M:%S", ts)
	if Params.MultipleExecution == True:
		Params = OverwriteParams(MEC_File,Params)

	#Here you can change variables if you want to
	#Parameter.HyperparameterConfig.ACTION_REPEAT_FOR_X_STEPS = 1

	print(LOG_DIR)
	if not os.path.isdir(LOG_DIR):
		os.makedirs(LOG_DIR)


	XMLWriter.writeXMLFile(LOG_DIR,Params)


	state_dim = get_state_dimension(Params)


	Runner.remote(1, state_dim, LOG_DIR,Evaluation = True)

	for i in range(60*60):
		time.sleep(Params.HyperparameterConfig.TRAIN_TIME)
		if os.path.isfile(LOG_DIR+"/RewardData.csv"):
			file =LOG_DIR+"/RewardData.csv"
			with open(file,"r")as f:
				reader= csv.reader(f,delimiter = ",")
				data = list(reader)
				row_count = len(data)
			if row_count>Params.HyperparameterConfig.EP_MAX:
				print(row_count)
				ray.shutdown()
				if lastRound == False:
					restart_program()
				else:
					quit()


	ray.shutdown()
	if lastRound == False:
		restart_program()
	else:
		quit()

# ModelConfig.RESTORE_MODEL = True
# ModelConfig.RESTORE_DIR = "/home/kemal/ppo/RL_Framework/LogData/GreyvsColor2/RGB/SaveData/SafetySaves/ep_1675MeanReward_875.7869085905888"
# ModelConfig.PARAM_DIR = "/home/kemal/ppo/RL_Framework/LogData/GreyvsColor2/RGB"
# HyperparameterConfig.EP_MAX = 10
# $
# ModelConfig.RESTORE_MODEL = True
# ModelConfig.RESTORE_DIR = "/home/kemal/ppo/RL_Framework/LogData/GreyvsColor2/RGB2/SaveData/SafetySaves/ep_1762MeanReward_879.3535609673828"
# ModelConfig.PARAM_DIR = "/home/kemal/ppo/RL_Framework/LogData/GreyvsColor2/RGB2"
# HyperparameterConfig.EP_MAX = 10
# $
# ModelConfig.RESTORE_MODEL = True
# ModelConfig.RESTORE_DIR = "/home/kemal/ppo/RL_Framework/LogData/GreyvsColor2/RGB3/2019-05-02_17:09:27/SaveData/SafetySaves/ep_1884MeanReward_882.0814939635353"
# ModelConfig.PARAM_DIR = "/home/kemal/ppo/RL_Framework/LogData/GreyvsColor2/RGB3"
# HyperparameterConfig.EP_MAX = 10
# $
# ModelConfig.RESTORE_MODEL = True
# ModelConfig.RESTORE_DIR = "/home/kemal/ppo/RL_Framework/LogData/GreyvsColor2/Greyscale/SaveData/SafetySaves/ep_1920MeanReward_889.5304816941498"
# ModelConfig.PARAM_DIR = "/home/kemal/ppo/RL_Framework/LogData/GreyvsColor2/Greyscale"
# HyperparameterConfig.EP_MAX = 10
# $
# ModelConfig.RESTORE_MODEL = True
# ModelConfig.RESTORE_DIR = "/home/kemal/ppo/RL_Framework/LogData/GreyvsColor2/Greyscale2/2019-05-03_02:10:21/SaveData/SafetySaves/ep_923MeanReward_876.3241556099242"
# ModelConfig.PARAM_DIR = "/home/kemal/ppo/RL_Framework/LogData/GreyvsColor2/Greyscale2"
# HyperparameterConfig.EP_MAX = 10
# $