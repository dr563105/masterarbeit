import gym
import time
import tensorflow as tf
import os
from random import randint


class Parameter:
    def __init__(self):
        self.EnvConfig = EnvConfig()
        self.ModelConfig = ModelConfig()
        self.HyperparameterConfig= HyperparameterConfig()
        self.NetworkConfig = NetworkConfig()
        self.OngoingTrainingParameters = OngoingTrainingParameters()
        self.OptimizerConfig = OptimizerConfig()
        self.MultipleExecution = False
        self.Client = Client()
        self.GTAV = GTAV()
        self.CreateDataset = False


class EnvConfig:
    def __init__(self):
        self.GAME = 'CarRacing-v0'
        self.environment = gym.make(self.GAME)

        self.GTAV_ENVIRONMENT = False
        self.CARRACING_ENVIRONMENT = True

        assert (self.CARRACING_ENVIRONMENT != self.GTAV_ENVIRONMENT)

        self.EnvSEED = 0
        #self.A_DIM = self.environment.action_space.shape[0]
        self.A_DIM =3

        self.S_DIM = self.environment.observation_space.shape
        #self.S_DIM = [100, 100, 3]

        self.A_UPPER_BOUND = self.environment.action_space.high.tolist()
        self.A_LOWER_BOUND = self.environment.action_space.low.tolist()
        self.CROPIMAGE = True
        self.FROM_X = 28
        self.TO_X = 68
        self.FROM_Y = 44
        self.TO_Y = 84
        #self.FROM_X = 10
        #self.TO_X = 90
        #self.FROM_Y = 20
        #self.TO_Y = 100
        self.MEANSHIFT = True
        self.GREYSCALE = False
        self.IMAGECOMPRESSION = False

class ModelConfig:
    def __init__(self):
        self.MODELNAME = "CAR_RACING_GAI_V1.1"
        self.RESTORE_MODEL = False
        self.SAVE_MODEL = False
        self.OUTPUT_GRAPH = True                                                                                        #Tensorboard Graph
        #self.RESTORE_DIR = "./LogData/GreyvsColor2/2019-05-02_03:50:24/SaveData/SafetySaves/ep_1920MeanReward_889.5304816941498"
        #self.RESTORE_DIR = "./LogData/CAR_RACING_GAI_V1.1/2019-11-15_21:31:52/SaveData/SafetySaves/ep_456MeanReward_863.0504060682423"
        #self.VAE_RESTORE_DIR = "./LogData/{}/2019-11-13_13:54:49/VAE_SaveData/".format(self.MODELNAME)

        self.PARAM_DIR= "./LogData/CAR_RACING_GAI_V1.1/2019-11-15_21:31:52/"
        self.RESTORE_LEARNING_RATE = False
        self.RESTORE_EPSILON = False
        self.RESTORE_GLOBAL_STEP = False

        self.EPSILON_GREEDY = False
        self.OPTIMIZE_EVERY_MINIBATCH=False
        self.AVERAGE_GRADIENTS = False                                                                                  #Only when OPTIMIZE_EVERY_MINIBATCH=False relevant Otherwise no effect
        self.UPDATE_OLD_PI_EVERY_GRAD_STEP = False                                                                      #Only when AVERAGE_GRADIENTS=False and OPTIMIZE_EVERY_MINIBATCH=False

        self.USE_VAE_AS_SHARED_NET = True
        self.VAE_TRAIN_ADD_RL = False
        self.AC_and_C_WEIGHTING = 1000.0

        self.SAVE_VAE = True
        self.SAVE_ACTOR = True
        self.SAVE_CRITIC = True

        self.USE_PRETRAINED_VAE = False
        self.USE_PRETRAINED_ACTOR =False
        self.USE_PRETRAINED_CRITIC = False


        #self.RESTORE_DIR_NAME = "/home/angelo/Desktop/Investigation of Novel Network Architectures Applied on Reinforcement Learning/RL_Framework_10/LogData/2019-11-20_16:05:40(copy)"
        #self.RESTORE_DIR_NAME = "./LogData/CAR_RACING_GAI_V1.1/2019-11-25_21:31:55"
        #self.RESTORE_DIR_NAME = "./LogData/CAR_RACING_GAI_V1.1/2019-11-25_21:31:58"
        self.RESTORE_DIR_NAME = "./pretrainedVAEs/Third"

        #self.VAE_RESTORE_DIR = "./LogData/{}/{}/VAE_SaveData/".format(self.MODELNAME, self.RESTORE_DIR_NAME)
        #self.CRITIC_RESTORE_DIR = "./LogData/{}/{}/CRITIC_SaveData/".format(self.MODELNAME, self.RESTORE_DIR_NAME)
        #self.ACTOR_RESTORE_DIR ="./LogData/{}/{}/actor_SaveData/".format(self.MODELNAME, self.RESTORE_DIR_NAME)

        self.VAE_RESTORE_DIR = "{}/VAE_SaveData/".format(self.RESTORE_DIR_NAME)
        self.CRITIC_RESTORE_DIR = "{}/CRITIC_SaveData/".format( self.RESTORE_DIR_NAME)
        self.ACTOR_RESTORE_DIR = "{}/ACTOR_SaveData/".format( self.RESTORE_DIR_NAME)

        self.FREEZE_VAE_PARAMS = False
        self.FREEZE_ACTOR_PARAMS = False
        self.FREEZE_CRITIC_PARAMS = False
                                                                                                                        # relevant Otherwise no effect
        self.RETURN_NORM = False                                                                                        #subtract mean of return batch and then devide by std
        self.REWARD_NORM = True                                                                                         #Divide every reward by 10
        self.ADVANTAGE_NORM = False
        self.GAE = False
        self.VALUE_CLIPPING = False
        self.SIGMA_OLD_EQUALS_SIGMA_NEW = False
        self.CONCAT = True
        self.VAE_INBETWEEN_FUSION = False
        self.VAE_EARLY_FUSION = True

        if self.CONCAT:
            assert(self.VAE_INBETWEEN_FUSION != self.VAE_EARLY_FUSION)
        else:
            assert(not(self.VAE_INBETWEEN_FUSION or self.VAE_EARLY_FUSION))


        self.CONCATNAME = "Steering Gyro Speed"                                                                                            #self.CONCATNAME = "Steering Gyro Speed"
        self.CLEAR_PS_AFTER_OPT=True
        self.STOCHASTIC_ACTION_SELECTION = True


def main(_):
    pass


#HyperparameterConfig.BATCH_SIZE ; 8,16,32,128,256
#HyperparameterConfig.MIN_BATCH_SIZE; 8,16,32,128,256
#ModelConfig.VALUE_CLIPPING ; False ,True


class  HyperparameterConfig:
    def __init__(self):
        self.EP_MAX =  10000# Amount of training epsisode
        self.EP_LEN =   5000*4 # amount of steps per episode
        self.TRAIN_TIME = 96 # training time in hours
        self.N_WORKER = 8# parallel workers
        self.GAMMA =    0.98   # reward discount factor
        self.LAMBDA =    0.95   # GAE coefficient
        self.A_LR =     0.00001#0.00001  # learning rate for actor
        self.C_LR =     0.00002#0.00002 #0.00002  # learning rate for critic
        self.VAE_LR = 0.0001#0.0001  # learning rate for VAE
        self.BATCH_SIZE = 10 # Batch Size
        self.MIN_BATCH_SIZE = 16# minimum batch size for updating PPO
        self.EPSILON = 0.2  # for clipping surrogate objective
        self.ENTROPY_BETA=0.000
        self.ACTION_REPEAT_FOR_X_STEPS = 5
        self.INITIALIZER = "he_normal"
        self.SEED = 1234   #randint(0,4294967296)
        self.DECAY_RATE =0.98
        self.DECAY_STEP =1000
        self.DECAY_STAIRCASE=True
        self.OPTIMIZER_EPSILON = 0.001
        self.START_WITH_EXP_DECAY = False
        self.PS = 1

        self.VALUE_COEFF = 1


class NetworkConfig:
    def __init__(self):
        #self.SHARED_CNN_LAYERS = 2# amount of layers
        #self.SHARED_CNN_FILTERS = [64, 128,256,512]# Filter size in each layer
        #self.SHARED_CNN_KERNEL_SIZE = [4,4,4,3]#kernel size in each layer
        #self.SHARED_CNN_STRIDES = [2,2,2,1]# stride size in each layer

        self.SHARED_CNN_LAYERS = 2  # amount of layers
        self.SHARED_CNN_FILTERS = [64, 128, 256, 256]  # Filter size in each layer
        self.SHARED_CNN_KERNEL_SIZE = [4, 4, 4, 3]  # kernel size in each layer
        self.SHARED_CNN_STRIDES = [2, 2, 2, 1]  # stride size in each layer

        self.ACTOR_CNN_LAYERS = 2#2# amount of layers
        #self.ACTOR_CNN_FILTERS = [128,256]# Filter size in each layer
        self.ACTOR_CNN_FILTERS = [64, 128]  # Filter size in each layer
        self.ACTOR_CNN_KERNEL_SIZE = [3,3,3]#kernel size in each layer
        self.ACTOR_CNN_STRIDES = [1,1,1]# stride size in each layer
        self.ACTOR_FC_LAYERS = 1# Amout of layers
        self.ACTOR_FC_UNITS = [600]#Amout of units per layers

        self.ACTION_FC_LAYERS = 2# Amout Action of layers
        self.ACTION_FC_UNITS = [80, 40]#Amout of  units per Action layers

        self.CRITIC_CNN_LAYERS = 2#2# amount of layers
        self.CRITIC_CNN_FILTERS = [64, 128]# Filter size in each layer
        self.CRITIC_CNN_KERNEL_SIZE = [3,3,3]#kernel size in each layer
        self.CRITIC_CNN_STRIDES = [1,1,1]# stride size in each layer
        self.CRITIC_FC_LAYERS = 2# Amout of layers
        self.CRITIC_FC_UNITS = [600,400] #Amout of units per layers

        ##VARIATIONAL AUTOENCODER PARAMS####

        # If this flag is True, then Actor and Critic should have no CNN Layers!
        self.VAE_USE_MEAN_FOR_SHARED = False
        self.VAE_USE_LOGVAR_FOR_SHARED = False

        self.VAE_LATENT_DIM = 50

        self.GET_FEATURE_MAP_LAYER = 4
        self.VAE_CNN_LAYERS = 4# amount of layers
        self.VAE_CNN_DECODER_LAYERS =self.VAE_CNN_LAYERS
        self.VAE_CNN_FILTERS = [32, 64, 128, 256]# Filter size in each layer

        self.VAE_CNN_KERNEL_SIZE = [3, 3, 3, 3]#kernel size in each layer
        self.VAE_CNN_DILATION_RATE = [1, 1, 1,1]  # kernel size in each layer
        self.VAE_CNN_PADDING = ["same", "same", "same", "same"]  # kernel size in each layer
        self.VAE_CNN_STRIDES = [2, 2, 2, 1]# stride size in each layer


          # amount of layers
        self.VAE_CNN_DECODER_STRIDES = [ 2, 2, 2]  # stride size in each layer

        self.VAE_CNN_DECODER_PADDING = ["same", "same", "same"]
        if self.VAE_CNN_DECODER_LAYERS == 1:
            self.VAE_CNN_DECODER_FILTERS = [32]
        elif self.VAE_CNN_DECODER_LAYERS == 2:
            self.VAE_CNN_DECODER_FILTERS = [64, 32]
        elif self.VAE_CNN_DECODER_LAYERS == 3:
            self.VAE_CNN_DECODER_FILTERS = [128,64,32]
        elif self.VAE_CNN_DECODER_LAYERS == 4:
            self.VAE_CNN_DECODER_FILTERS = [256,128,64,32]
            self.VAE_CNN_DECODER_PADDING = ["same", "same", "same", "same"]
            self.VAE_CNN_DECODER_STRIDES = [1, 2, 2, 2]  # stride size in each layer
        else:
            assert(False)

        #self.VAE_CNN_DECODER_FILTERS = [256, 128, 64, 32]# Filter size in each layer
         # kernel size in each layer
        self.VAE_CNN_DECODER_KERNEL_SIZE = [3,3,3,3]#kernel size in each layer




class OptimizerConfig:
    def __init__(self):
        self.RUN_RAPIDPROTOYPE = False
        self.RUN_PPO = True

        assert(self.RUN_PPO != self.RUN_RAPIDPROTOYPE)


class OngoingTrainingParameters:
    LR_A = 0.0
    LR_C = 0.0
    EPSILON  =0.0
    GLOBAL_STEP = 0
    GLOBAL_EP =0
    LR_CHANGE = False

class Client:
    def __init__(self):
        #self.IP = "134.61.73.222"
        #self.IP = "137.226.167.172"
        self.IP_ADRESSES = ["134.61.73.222", "137.226.167.172"]
        self.PORT = 8000


class GTAV:
    def __init__(self):
        self.START_POS = [872.2491455078125, -21.093231201171875, 78.58832550048828]
        self.WEATHER = 0 # 0: Sunny, 1: Rainy , 2 : Foggy
        self.TIME = 0
        self.VEHILCE_TYPE = 0

        #0 : None; 1: Ultrasonic ; 2 : Lidar
        self.SENSOR_0 = 0
        self.SENSOR_1 = 0
        self.SENSOR_2 = 0
        self.SENSOR_3 = 0
        self.SENSOR_4 = 0
        self.SENSOR_5 = 0
        self.SENSOR_6 = 0
        self.SENSOR_7 = 0
        self.SENSOR_8 = 0
        self.SENSOR_9 = 0
        self.SENSOR_10 = 0
        self.SENSOR_11 = 0
        self.SENSOR_12 = 0
