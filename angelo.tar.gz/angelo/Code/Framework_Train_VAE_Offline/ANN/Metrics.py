from Config import *

class Metric():
	def __init__(self,w_init,S_DIM,globalstep,Parameter,name,state_dim,Action0,Action1=None,Action2=None):
		self.state_dim = state_dim
		self.Parameter = Parameter
		self.learning_rate_Spe_ret = tf.train.exponential_decay(learning_rate=self.Parameter.HyperparameterConfig.C_LR,
																global_step = globalstep,
																decay_steps=self.Parameter.HyperparameterConfig.DECAY_STEP,
																decay_rate=self.Parameter.HyperparameterConfig.DECAY_RATE,
																staircase=self.Parameter.HyperparameterConfig.DECAY_STAIRCASE)
		self.tfdc_r = tf.placeholder(tf.float32, [None, 1], 'discounted_r')
		self.tfdret = tf.placeholder(tf.float32, [None, 1], 'reward_t1')
		self.tfdret0 = tf.placeholder(tf.float32, [None, 1], 'reward_t0')
		self.tfdspe = tf.placeholder(tf.float32, [None, 1], 'speed_t1')
		self.tfdsta2 = tf.placeholder(tf.float32, [None] + list(S_DIM), 'new_state')
		self.tfdsta = tf.placeholder(tf.float32, [None] + list(S_DIM), 'old_state')
		self.stateparameter2 = tf.placeholder(tf.float32, [None, 1], 'stateparameter2')
		self.speOut = self._build_SpeedEst("Spe1",w_init)
		self.spe2Out= self._build_SpeedEst2("Spe2",w_init)
		self.retOut = self._build_ReturnEst("Ret1",w_init)
		self.ret2Out = self._build_ReturnEst2("Ret2",w_init)
		self.ret3Out = self._build_ReturnEst3("Ret3",w_init,Action0,Action1,Action2)
		self.OPT_SR = tf.train.AdamOptimizer(self.learning_rate_Spe_ret, name='AdamOptSperet')

		self.spe_params  = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+"/Spe1")
		self.spe2_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+"/Spe2")
		self.ret_params  = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+"/Ret1")
		self.ret2_params  = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+"/Ret2")
		self.ret3_params  = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=name+"/Ret3")

		self.spe_loss    = tf.reduce_mean(tf.square(self.speOut - self.tfdspe))
		self.spe2_loss   = tf.reduce_mean(tf.square(self.spe2Out- self.tfdspe))
		self.ret_loss    = tf.reduce_mean(tf.square(self.retOut - self.tfdret0))
		self.ret2_loss    = tf.reduce_mean(tf.square(self.ret2Out - self.tfdret))
		self.ret3_loss    = tf.reduce_mean(tf.square(self.ret3Out - self.tfdret))

		tf.summary.scalar("spe_loss", self.spe_loss)
		tf.summary.scalar("spe2_loss", self.spe2_loss)
		tf.summary.scalar("ret1_loss", self.ret_loss)
		tf.summary.scalar("ret2_loss", self.ret_loss)
		tf.summary.scalar("ret3_loss", self.ret_loss)

		self.spe_grads  = tf.gradients(self.spe_loss,  self.spe_params)
		self.spe2_grads = tf.gradients(self.spe2_loss, self.spe2_params)
		self.ret_grads  = tf.gradients(self.ret_loss,  self.ret_params)
		self.ret2_grads  = tf.gradients(self.ret2_loss,  self.ret2_params)
		self.ret3_grads  = tf.gradients(self.ret3_loss,  self.ret3_params)


		self.placeholder_spe_gradients = []
		for grad_var in self.spe_grads:
			self.placeholder_spe_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))
		self.placeholder_spe2_gradients = []
		for grad_var in self.spe2_grads:
			self.placeholder_spe2_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))
		self.placeholder_ret_gradients = []
		for grad_var in self.ret_grads:
			self.placeholder_ret_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))
		self.placeholder_ret2_gradients = []
		for grad_var in self.ret2_grads:
			self.placeholder_ret2_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))
		self.placeholder_ret3_gradients = []
		for grad_var in self.ret3_grads:
			self.placeholder_ret3_gradients.append((tf.placeholder(dtype=tf.float32, shape=grad_var.get_shape())))

		self.apply_spe_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_spe_gradients, self.spe_params))
		self.apply_spe2_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_spe2_gradients, self.spe2_params))
		self.apply_ret_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_ret_gradients, self.ret_params))
		self.apply_ret2_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_ret2_gradients, self.ret2_params))
		self.apply_ret3_gradients = self.OPT_SR.apply_gradients(zip(self.placeholder_ret3_gradients, self.ret3_params))




	def _build_SpeedEst(self, name,w_init):
		with tf.variable_scope(name):
			conv1 = tf.layers.conv2d(name="retconv1", inputs=self.tfdsta, filters=32, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv2 = tf.layers.conv2d(name="retconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv3 = tf.layers.conv2d(name="retconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			state_in = tf.layers.flatten(conv3)
			out = tf.layers.dense(state_in, 1, name='retls1', kernel_initializer=w_init)
		return out

	def _build_SpeedEst2(self, name,w_init):
		with tf.variable_scope(name):
			conLF1c = tf.layers.dense(self.stateparameter2, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
			conLF2c = tf.layers.dense(conLF1c, self.state_dim[0]* self.state_dim[1], tf.nn.relu, name='conLF2c', kernel_initializer=w_init)
			conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1],1])

			concat = tf.concat(values=[self.tfdsta, conLF2cReshapeC], axis=3)

			conv1 = tf.layers.conv2d(name="speconv1", inputs=concat, filters=32, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv2 = tf.layers.conv2d(name="speconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv3 = tf.layers.conv2d(name="speconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			state_in = tf.layers.flatten(conv3)


			lafc = tf.layers.dense(state_in, 40, tf.nn.relu, name='lafc', kernel_initializer=w_init)
			out = tf.layers.dense(lafc, 1, name='spels1', kernel_initializer=w_init)
		return out


	def _build_ReturnEst(self, name,w_init):
		with tf.variable_scope(name):
			conv1 = tf.layers.conv2d(name="retconv1", inputs=self.tfdsta, filters=32, kernel_size=(4, 4),
									 strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv2 = tf.layers.conv2d(name="retconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv3 = tf.layers.conv2d(name="retconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			state_in = tf.layers.flatten(conv3)
			out = tf.layers.dense(state_in, 1, name='retls1', kernel_initializer=w_init)
		return out


	def _build_ReturnEst2(self, name,w_init):
		with tf.variable_scope(name):
			conLF1c = tf.layers.dense(self.stateparameter2, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
			conLF2c = tf.layers.dense(conLF1c, self.state_dim[0]* self.state_dim[1], tf.nn.relu, name='conLF2c', kernel_initializer=w_init)
			conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1], 1])

			concat = tf.concat(values=[self.tfdsta, conLF2cReshapeC], axis=3)

			conv1 = tf.layers.conv2d(name="speconv1", inputs=concat, filters=32, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv2 = tf.layers.conv2d(name="speconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv3 = tf.layers.conv2d(name="speconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			state_in = tf.layers.flatten(conv3)


			lafc = tf.layers.dense(state_in, 40, tf.nn.relu, name='lafc', kernel_initializer=w_init)
			out = tf.layers.dense(lafc, 1, name='spels1', kernel_initializer=w_init)
		return out

	def _build_ReturnEst3(self, name,w_init,Action0,Action1,Action2):
		with tf.variable_scope(name):
			# conA0 = tf.layers.dense(Action0[:-1], 100, tf.nn.relu, name='conA0', kernel_initializer=w_init)
			# conA0 = tf.layers.dense(conA0, self.state_dim[0]* self.state_dim[1], tf.nn.relu, name='conA02', kernel_initializer=w_init)
			# conA0 = tf.reshape(conA0, [-1, self.state_dim[0], self.state_dim[1], 1])
			#
			# if Action1 != None:
			# 	conA1 = tf.layers.dense(Action1[:-1], 100, tf.nn.relu, name='conA1', kernel_initializer=w_init)
			# 	conA1 = tf.layers.dense(conA1, self.state_dim[0]* self.state_dim[1], tf.nn.relu, name='conA12', kernel_initializer=w_init)
			# 	conA1 = tf.reshape(conA1, [-1, self.state_dim[0], self.state_dim[1], 1])
			# 	conA0 = tf.concat(values=[conA0, conA1], axis=3)
			#
			# if Action2 != None:
			# 	conA2 = tf.layers.dense(Action2[:-1], 100, tf.nn.relu, name='conA2', kernel_initializer=w_init)
			# 	conA2 = tf.layers.dense(conA2, self.state_dim[0]* self.state_dim[1], tf.nn.relu, name='conA22', kernel_initializer=w_init)
			# 	conA2 = tf.reshape(conA2, [-1, self.state_dim[0], self.state_dim[1], 1])
			# 	conA0 = tf.concat(values=[conA0, conA2], axis=3)

			# print(conA0.shape)
			# conLF1c = tf.layers.dense(self.stateparameter2, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
			# conLF2c = tf.layers.dense(conLF1c, self.state_dim[0]* self.state_dim[1], tf.nn.relu, name='conLF2c', kernel_initializer=w_init)
			# conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1], 1])

			# concat = tf.concat(values=[self.tfdsta,self.tfdsta2,conA0], axis=3)
			conLF1c = tf.layers.dense(self.stateparameter2, 100, tf.nn.relu, name='conLF1c', kernel_initializer=w_init)
			conLF2c = tf.layers.dense(conLF1c, self.state_dim[0] * self.state_dim[1], tf.nn.relu, name='conLF2c',
									  kernel_initializer=w_init)
			conLF2cReshapeC = tf.reshape(conLF2c, [-1, self.state_dim[0], self.state_dim[1], 1])

			concat = tf.concat(values=[self.tfdsta, conLF2cReshapeC], axis=3)

			conv1 = tf.layers.conv2d(name="speconv1", inputs=concat, filters=32, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv2 = tf.layers.conv2d(name="speconv2", inputs=conv1, filters=64, kernel_size=(4, 4), strides=(2, 2),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			conv3 = tf.layers.conv2d(name="speconv3", inputs=conv2, filters=128, kernel_size=(4, 4), strides=(1, 1),
									 activation=tf.nn.relu, kernel_initializer=w_init)
			state_in = tf.layers.flatten(conv3)

			lafc = tf.layers.dense(state_in, 40, tf.nn.relu, name='lafc', kernel_initializer=w_init)
			print()
			if Action2 != None:
				concat = tf.concat(values=[lafc,Action2[:-1],Action1[:-1],Action0[:-1]],axis=1)

			elif Action1 != None:
				concat = tf.concat(values=[lafc,Action1[:-1],Action0[:-1]],axis=1)
			else:
				concat = tf.concat(values=[lafc,Action0[:-1]],axis=1)
			out = tf.layers.dense(concat, 1, name='spels1', kernel_initializer=w_init)
		return out