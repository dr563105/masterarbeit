from itertools import starmap

import tensorflow as tf
from ANN import ArtificialNeuralNetwork

import glob

import numpy as np

from Config import Config

class VAE(object):
	def __init__(self ,name = "VAE", train_op = True ):

		
		self._name = "VAE"
		self.training_config = Config().training_config
		self.dataset_config = Config().dataset_config
		self.network_config = Config().network_config
		self.sequential = Config().estimator_training_config.lstm_cell
		self.sequence_len = Config().dataset_config.sequence_len
		self.latent_dim = self.network_config.latent_dim

		self.batch_size = self.training_config.batch_size
		self.learning_rate = self.training_config.learning_rate
		self.image_size = self.dataset_config.image_size
		self.optimizer = None
		self.train_op = None
		self.c_2 = self.network_config.c_2
		self.tf_summaries = []
		self.reconstruction_loss = None
		self.kl_loss = None
		self.global_step = tf.Variable(0, name='global_step', trainable=False)

		#Placeholder

		self.net_image_label = tf.placeholder(tf.float32, [None,self.image_size[0],self.image_size[1] ,self.image_size[2]], 'Net_Input_Label')
		self.net_input_sequential = tf.placeholder(tf.float32, [None, self.sequence_len,self.image_size[0], self.image_size[1], self.image_size[2]],'Net_Input_seq')
		self.ph_dropout_rate = tf.placeholder_with_default(tf.constant(0.0) , shape = ())

		self.PHSpeed =None
		self.PHSteering = None
		self.PHGyro = None

		#Define Network self.Parameter
		ANN = ArtificialNeuralNetwork.ANN(
			kernel_initializer=self._get_glorot_uniformInitializer(),
			latent_dim = self.latent_dim,
			batch_size = self.batch_size
		)
		with tf.variable_scope("PPO"):
			self.net_input = tf.placeholder(tf.float32, [None, self.image_size[0], self.image_size[1], self.image_size[2]],'State')
			self.VAE_BATCHSIZE = tf.placeholder(shape=(), dtype=tf.int32, name="VAE_BATCHSIZE")

			self.PHSpeed = None
			self.PHSteering = None
			self.PHGyro = None
			self.PHGoalDistance = None

			if self.network_config.VAE_EARLY_FUSION:
				self.PHSpeed = tf.placeholder(tf.float32, [None, 1], 'PHSpeed')
				self.PHSteering = tf.placeholder(tf.float32, [None, 1], 'PHSteering')
				self.PHGyro = tf.placeholder(tf.float32, [None, 1], 'PHGyro')
				self.PHGoalDistance = tf.placeholder(tf.float32, [None, 1], 'PHGoalDistance')

			self.decoder ,  self.mean , self.logvar, self.z , _ = ANN._buildCVAE(PHState= self.net_input,
																			PHSpeed=self.PHSpeed,
																			PHSteering=self.PHSteering,
																			PHGyro=self.PHGyro ,
																			PHGoalDistance=self.PHGoalDistance,
																			BATCHSIZE = self.VAE_BATCHSIZE)
			with tf.variable_scope("OldPi"):
				ANN._build_vae(net_input=self.net_input,
						PHSpeed=self.PHSpeed,
						PHSteering=self.PHSteering,
						PHGyro=self.PHGyro,
						PHGoalDistance=self.PHGoalDistance,
						BATCHSIZE=self.VAE_BATCHSIZE,
						old_pi=True)


		if self.training_config.summary_show_images:
			self.show_reconstructions()
		self.loss = self.compute_loss()
		self.vae_encoder_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='PPO/JoinedNet/VAE/Encoder')


		# define optimizer after nets have been built
		if train_op:
			self.get_train_op()

		#saver after all layers have been created

		self.vae_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='PPO/JoinedNet/VAE')



		self.tf_saver = tf.train.Saver(max_to_keep=self.training_config.max_file_to_keep, var_list=self.vae_params, filename="VAE")



	def compute_loss(self):

		nn = self.net_input
		if self.network_config.VAE_EARLY_FUSION:
			assert(False)
			concat_dim = [self.net_input.shape[1], self.net_input.shape[2]]

			if self.network_config.CONCATNAME.find("Speed") != -1:
				SpeedDim = tf.tile(self.PHSpeed, [1, concat_dim[0] * concat_dim[1]])
				SpeedDim = tf.reshape(SpeedDim, shape=[tf.shape(self.net_input)[0], concat_dim[0], concat_dim[1]])
				SpeedDim = tf.expand_dims(SpeedDim, axis=-1)
				nn = tf.concat(values=[nn, SpeedDim], axis=3)

			if self.network_config.CONCATNAME.find("Steering") != -1:
				SteerDim = tf.tile(self.PHSteering, [1, concat_dim[0] * concat_dim[1]])
				SteerDim = tf.reshape(SteerDim, shape=[tf.shape(self.net_input)[0], concat_dim[0], concat_dim[1]])
				SteerDim = tf.expand_dims(SteerDim, axis=-1)
				nn = tf.concat(values=[nn, SteerDim], axis=3)

			if self.network_config.CONCATNAME.find("Gyro") != -1:
				GyroDim = tf.tile(self.PHGyro, [1, concat_dim[0] * concat_dim[1]])
				GyroDim = tf.reshape(GyroDim, shape=[tf.shape(self.net_input)[0], concat_dim[0], concat_dim[1]])
				GyroDim = tf.expand_dims(GyroDim, axis=-1)
				nn = tf.concat(values=[nn, GyroDim], axis=3)

			if self.network_config.CONCATNAME.find("GoalDistance") != -1:
				GoalDistanceDim = tf.tile(self.PHGoalDistance, [1, concat_dim[0] * concat_dim[1]])
				GoalDistanceDim = tf.reshape(GoalDistanceDim , shape=[tf.shape(self.net_input)[0], concat_dim[0], concat_dim[1]])
				GoalDistanceDim = tf.expand_dims(GoalDistanceDim, axis=-1)
				nn = tf.concat(values=[nn, GoalDistanceDim], axis=3)



		labels_flat = tf.layers.flatten(nn)
		logits_flat = tf.layers.flatten(self.decoder)
		#decoder_logvar =tf.layers.flatten(self.decoder_sigma)
		print(logits_flat)
		print(labels_flat)
		#assert(False)
		if self.training_config.use_mse:
			#reconstruction_loss = tf.losses.mean_squared_error(labels=labels_flat, predictions= logits_flat)
			recon_loss = tf.math.pow(tf.subtract(labels_flat,logits_flat),2)# + decoder_logvar

		print("reconstruction_loss : {}".format(recon_loss))

		print(tf.shape(recon_loss))
		print(recon_loss)
		
		logpx_z = tf.reduce_sum(recon_loss, axis=1)
		#logpx_z = tf.reduce_mean(recon_loss, axis=1)

		#self.kl_loss = -tf.reduce_sum(1+self.logvar - self.mean**2 - tf.exp(self.logvar), axis =1)
		kl_loss = -tf.reduce_sum(self.logvar - self.mean ** 2 - tf.exp(self.logvar), axis=1)


		self.kl_loss =kl_loss
		self.reconstruction_loss = logpx_z

		elbo_loss = tf.reduce_mean(self.reconstruction_loss  + self.c_2*self.kl_loss)

		loss_summary = tf.summary.scalar("loss", elbo_loss)
		mse_loss_summary = tf.summary.scalar("mse_loss", tf.reduce_mean(self.reconstruction_loss))
		kl_loss_summary = tf.summary.scalar("kl_loss", tf.reduce_mean(self.kl_loss))


		self.tf_summaries.append(loss_summary)
		self.tf_summaries.append(mse_loss_summary)
		self.tf_summaries.append(kl_loss_summary)
		return elbo_loss

	def show_reconstructions(self):
		#if self.training_config.use_mse:
		#	reconstructions = tf.sigmoid(self.decoder)
		#if self.training_config.use_ce:
		#	reconstructions = tf.sigmoid(self.decoder)
		reconstruction_img_summary = tf.summary.image("reconstructions", (self.decoder[:,:,:,0:3]*0.5 +0.5))



		input_img_summary = tf.summary.image("input", self.net_input)
		self.tf_summaries.append(reconstruction_img_summary)
		#self.tf_summaries.append(input_img_summary)

	def log_normal_pdf(self , sample, mean, logvar, raxis=1):
    		
		log2pi = tf.math.log(2. * np.pi)
		return tf.reduce_sum(-.5 * ((sample - mean) ** 2. * tf.exp(-logvar) + logvar + log2pi),axis=raxis)

	def _get_glorot_uniformInitializer(self):
		return tf.keras.initializers.glorot_uniform()

	def initialize_vae_with_latest_session(self, sess):
			
		if glob.glob("Log_VAE*") is None:
			print("No previous session found ! Set resume parameter to false and rerun code!")
			assert(False)

		log_dir = glob.glob("Log_VAE*")[-1]
		latest_checkpoint = tf.train.latest_checkpoint(log_dir)
		print("Init VAE with values from : " + log_dir)
		print("Checkpoint : " + str(latest_checkpoint))
		#restore the session
		self.tf_saver.restore(sess, latest_checkpoint)
		#load dataset that has been used for this session
	
	def get_train_op(self):

		self.optimizer = tf.train.AdamOptimizer(learning_rate= self.learning_rate)
		
		if self.training_config.gradient_clipping:
			gvs = self.optimizer.compute_gradients(self.loss)
			capped_gvs = [(tf.clip_by_value(grad, self.training_config.gradient_range[0], self.training_config.gradient_range[1]), var) for grad, var in gvs]
			self.train_op = self.optimizer.apply_gradients(capped_gvs, global_step = self.global_step)
		else:
			self.train_op = self.optimizer.minimize(self.loss, global_step=self.global_step )
