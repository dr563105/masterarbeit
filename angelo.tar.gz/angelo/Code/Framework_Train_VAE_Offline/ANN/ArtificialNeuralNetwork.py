import tensorflow as tf
import numpy as np
from Config import Config


def log_normal_pdf(sample, mean, logvar, raxis=1):
    log2pi = tf.math.log(2. * np.pi)
    return tf.reduce_sum(
        -.5 * ((sample - mean) ** 2. * tf.exp(-logvar) + logvar + log2pi),
        axis=raxis)


class ANN(object):
    def __init__(self, kernel_initializer, latent_dim, batch_size):
        self.latent_dim = latent_dim
        self.kernel_initializer = kernel_initializer

        self.loss = None
        self.network_config = Config().network_config
        self.dataset_config = Config().dataset_config
        self.estimator_training_config = Config().estimator_training_config
        self.LSTM_UNITS = Config().estimator_training_config.LSTM_UNITS
        self.sequence_len = self.dataset_config.sequence_len

        self.batch_size = batch_size
        self.Kernel_Initializer = kernel_initializer

    # noinspection PyInterpreter
    def _build_vae(self, net_input, PHSpeed, PHSteering, PHGyro,PHGoalDistance, BATCHSIZE, old_pi = False):
        nn = net_input
        shared_feature_maps = []
        with tf.variable_scope('VAE'):
            with tf.variable_scope('Encoder'):
                with tf.variable_scope('FeatureExtraction'):
                    if self.network_config.VAE_EARLY_FUSION:

                        concat_dim = [nn.shape[1], nn.shape[2]]
                        if self.network_config.CONCATNAME.find("Speed") != -1:
                            SpeedDim = tf.layers.dense(PHSpeed, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                       name='conLF2c',
                                                       kernel_initializer=self.Kernel_Initializer,
                                                       trainable=True
                                                       )
                            SpeedDim = tf.reshape(SpeedDim, [-1, concat_dim[0], concat_dim[1], 1])
                            nn = tf.concat(values=[nn, SpeedDim], axis=3)

                        if self.network_config.CONCATNAME.find("Steering") != -1:
                            SteerDim = tf.layers.dense(PHSteering, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                       name='conLF2d',trainable=True,
                                                       kernel_initializer=self.Kernel_Initializer)
                            SteerDim = tf.reshape(SteerDim, [-1, concat_dim[0], concat_dim[1], 1])
                            nn = tf.concat(values=[nn, SteerDim], axis=3)

                        if self.network_config.CONCATNAME.find("Gyro") != -1:
                            GyroDim = tf.layers.dense(PHGyro, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                      name='conLF2e',trainable=True,
                                                      kernel_initializer=self.Kernel_Initializer)
                            GyroDim = tf.reshape(GyroDim, [-1, concat_dim[0], concat_dim[1], 1])
                            nn = tf.concat(values=[nn, GyroDim], axis=3)

                        if self.network_config.CONCATNAME.find("GoalDistance") != -1:
                            GoalDistanceDim = tf.layers.dense(PHGoalDistance, concat_dim[0] * concat_dim[1], tf.nn.relu,
                                                              name='conLF2f',
                                                              kernel_initializer=self.Kernel_Initializer)
                            GoalDistanceDim = tf.reshape(GoalDistanceDim, [-1, concat_dim[0], concat_dim[1], 1])
                            nn = tf.concat(values=[nn, GoalDistanceDim], axis=3)

                    print(nn)
                    for i in range(self.network_config.VAE_CNN_LAYERS):
                        nn = tf.layers.conv2d(inputs=nn,
                                              filters=self.network_config.VAE_CNN_FILTERS[i],
                                              kernel_size=self.network_config.VAE_CNN_KERNEL_SIZE[i],
                                              strides=self.network_config.VAE_CNN_STRIDES[i],
                                              dilation_rate=self.network_config.VAE_CNN_DILATION_RATE[i],
                                              activation=tf.nn.relu,
                                              padding=self.network_config.VAE_CNN_PADDING[i],
                                              kernel_initializer=self.Kernel_Initializer,
                                              name="ConvLayer{}".format(i)
                                              )

                        tf.identity(nn, "Shared_feature_maps_{}".format(i))
                        shared_feature_maps.append(nn)

                        print("\nEncoder Layer {}: \n{}\n".format(i, nn))

                    vae_feature_extraction = nn

                nn = tf.layers.flatten(nn)

                mean = tf.layers.dense(nn,
                                   units=self.network_config.VAE_LATENT_DIM,
                                   kernel_initializer=self.Kernel_Initializer,
                                   name='DenseMean')

                mean = tf.identity(mean, "Mean")

                logvar = tf.layers.dense(nn,
                                     units=self.network_config.VAE_LATENT_DIM,
                                     kernel_initializer=self.Kernel_Initializer,
                                     name='DenseLogvar')
                logvar = tf.identity(logvar, "Logvar")

                if old_pi:
                    return mean, logvar, shared_feature_maps


            with tf.variable_scope("Reparameterize"):
                # reparameterize
                eps = tf.random.normal(shape=(BATCHSIZE, self.network_config.VAE_LATENT_DIM))
                z = eps * tf.exp(logvar * .5) + mean
                tf.identity(z, "Latent_space")



            with tf.variable_scope('Decoder'):

                nn = tf.layers.dense(z, units=vae_feature_extraction.shape[1] * vae_feature_extraction.shape[2] *
                                              vae_feature_extraction.shape[3], kernel_initializer=self.Kernel_Initializer)

                nn = tf.reshape(nn, [BATCHSIZE, vae_feature_extraction.shape[1], vae_feature_extraction.shape[2],
                                     vae_feature_extraction.shape[3]])

                print("\nDecoder Reshaped: \n{}\n".format(nn))

                for i in range(self.network_config.VAE_CNN_DECODER_LAYERS):
                    nn = tf.layers.conv2d_transpose(inputs=nn, filters=self.network_config.VAE_CNN_DECODER_FILTERS[i],
                                                    kernel_size=self.network_config.VAE_CNN_DECODER_KERNEL_SIZE[i],
                                                    strides=self.network_config.VAE_CNN_DECODER_STRIDES[i],
                                                    activation=tf.nn.relu,
                                                    padding=self.network_config.VAE_CNN_DECODER_PADDING[i],
                                                    kernel_initializer=self.Kernel_Initializer)
                    print("\nDecoder Layer {}: \n{}\n".format(i, nn))

                if self.network_config.VAE_EARLY_FUSION:
                    output_filters = 6
                else:
                    output_filters = 3

                nn = tf.layers.conv2d_transpose(inputs=nn,
                                                filters=output_filters,
                                                kernel_size=3,
                                                strides=1,
                                                padding="same",
                                                kernel_initializer=self.Kernel_Initializer)

                print("\nDecoder Output Layer :\n{}\n".format(nn))
                # assert(False)
                #decoder_sigma = tf.math.tanh(nn)
                if self.network_config.use_decoder_tanh:
                    nn = tf.math.tanh(nn)
                    #nn = tf.math.sigmoid(nn)
                tf.identity(nn, "Net_out")

        return nn, mean, logvar, z, shared_feature_maps#, decoder_sigma

    def _buildCVAE(self, BATCHSIZE, PHState=None, PHSpeed=None, PHSteering=None, PHGyro=None, PHGoalDistance=None):
        with tf.variable_scope("JoinedNet"):
            vae_output, mean, logvar, z, shared_feature_maps = self._build_vae(net_input=PHState,
                                                                              PHSpeed=PHSpeed,
                                                                              PHSteering=PHSteering,
                                                                              PHGyro=PHGyro,
                                                                               PHGoalDistance=PHGoalDistance,
                                                                              BATCHSIZE = BATCHSIZE)

        return vae_output, mean, logvar, z, shared_feature_maps


