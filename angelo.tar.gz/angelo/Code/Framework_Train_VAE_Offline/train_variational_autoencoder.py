
from __future__ import absolute_import, division, print_function, unicode_literals

import tensorflow as tf

import os
import time
import numpy as np
import glob
import matplotlib.pyplot as plt

from IPython import display

import dataset

from ANN import Graph
import random

from Config import Config

from Utils.utils import *
from tensorflow.python.tools import freeze_graph

log_dir = ""
epoch = 0

#load dataset
training_config = Config().training_config
dataset = dataset.Dataset(True)

early_fusion = Config().network_config.VAE_EARLY_FUSION
#load model
model = Graph.VAE()

config = tf.ConfigProto()
config.gpu_options.allow_growth = True

with tf.Session(config = config) as sess:
  
  sess.run(tf.global_variables_initializer())
  #saver to store model

  tf_summaries = tf.summary.merge_all()

  if training_config.resume_training:   
      log_dir , epoch = restore_session(sess = sess, model = model, data_set = dataset)     
  else:
    #create new session
    log_dir = create_new_session(data_set = dataset)

  #summary writer for tensorboard
  tf_summary_writer_train = tf.summary.FileWriter(log_dir + "/train", sess.graph)
  tf_summary_writer_test = tf.summary.FileWriter(log_dir + "/test", sess.graph)

  #model.tf_input_saver.save(sess, save_path=log_dir + '/Input', write_meta_graph=True)
  #model.tf_OldPi_saver.save(sess, save_path=log_dir + '/VAE_OldPi', write_meta_graph=True)
  model.tf_saver.save(sess, save_path=log_dir + '/VAE',write_meta_graph=True)

  while(epoch <  training_config.num_epochs + 1):
  #for training_config.num_epochs in range(1, training_config.num_epochs + 1):
    start_time = time.time()

    test_x = None
    for i in range(0, dataset.train_iterations):
      #print("i = " + str(i))
      train_x, SpeedBatch, SteeringBatch, GoalDistanceBatch = dataset.get_mini_batch(iteration = i)



      #print("Steering : {}".format(SteeringBatch[0]))
      #print("Speed : {}".format(SpeedBatch[0]))
      #print("Gyro : {}".format(GyroBatch[0]))
      fd_train = {
        model.net_input: train_x ,
        model.ph_dropout_rate : training_config.ph_dropout_rate,
        model.VAE_BATCHSIZE : training_config.batch_size}

      if early_fusion:
        fd_train[model.PHSpeed] = SpeedBatch
        fd_train[model.PHSteering] = SteeringBatch
        #fd_train[model.PHGyro] = GoalDistanceBatch
        fd_train[model.PHGoalDistance] = GoalDistanceBatch


      ops = []
      ops.append(model.train_op)
      if training_config.summary_train_loss:
        #train_loss in summary
        #summary_str = sess.run([tf_summaries], feed_dict = fd_train)
        ops.append(tf_summaries)
        _, summary_str= sess.run(ops, feed_dict= fd_train) 
        tf_summary_writer_train.add_summary(summary_str, global_step= tf.train.global_step(sess,model.global_step))    
      else:
        sess.run(ops, feed_dict= fd_train)
      val_global_step= tf.train.global_step(sess,model.global_step)
      if val_global_step % training_config.save_iteration == 0:
        file_name = "my_vae"
        save_path = model.tf_saver.save(sess, save_path = log_dir + '/VAE', global_step = model.global_step)


    end_time = time.time()

    loop_time = end_time - start_time
    print('global_step: %s' % tf.train.global_step(sess ,model.global_step))
    print("epoch = {} , time for epoch : {}".format(epoch , loop_time ))
    
    #test_and_show_reconstructed_test_images(model = model, epoch = epoch, test_input = test_x, sess = sess, out_dir = log_dir)
    dataset.shuffle_train_and_test_set()
    epoch +=1

print("Training has been finished")