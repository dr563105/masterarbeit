#Creator: Angelo David Mihaltan

import tensorflow as tf
import numpy as np
import os
import glob
import random
import cv2
import csv
from Config import Config

import pickle
from tqdm import tqdm

class Dataset():
    def __init__(self, csv_files = False):
        print("Create Dataset")

        self.dataset_config = Config().dataset_config
        self.training_config = Config().training_config
        self.estimator_training_config = Config().estimator_training_config

        self.value_dim = self.estimator_training_config.predict_gyro + self.estimator_training_config.predict_steering + self.estimator_training_config.predict_velocity
        self.image_sequences = []
        self.path  = self.dataset_config.data_path
        self.images = list()
        self.values = list()
        self.training_set = list()
        self.test_set = list()
        self.batch_size = self.training_config.batch_size

        self.image_size = self.dataset_config.image_size

        self.test_iterations = 0
        self.train_iterations = 0

        self.sequence_len = self.dataset_config.sequence_len
        self.csv_files = csv_files
        self.minibatch_images = np.empty(shape= (self.batch_size, self.dataset_config.image_size[0], self.dataset_config.image_size[1], 3 ))
        self.minibatch_sequential_images = np.empty(shape= (self.batch_size*self.sequence_len,self.dataset_config.image_size[0], self.dataset_config.image_size[1], self.dataset_config.image_size[2]))
        self.minibatch_sequential_values = np.empty(shape= (self.batch_size, self.value_dim ))
        self.val_reshape = np.empty(shape= (self.batch_size,self.sequence_len , self.value_dim ))
        self.images_memory = {}
        self.values_memory = {}
        self.data_into_memory = self.dataset_config.dataset_in_memory


    def load_images(self):
        print("Load images from " + self.path)

        if not os.path.isdir(self.path):
            print("Dir not found ! : \n" + self.path)

        for runner in sorted(os.listdir(self.path)):
            print(runner)

            curPath = self.path + "/" + runner + "/"
            #os.chdir(curPath)
            for file in sorted(glob.glob(curPath + "*.png")):

                #replace backslash with forward slash
                file = file.replace("\\" , "/")
                self.images.append(file)



            #assert(False)

    def load_images_sequential(self):
        print("Load images from " + self.path)

        if not os.path.isdir(self.path):
            print("Dir not found ! : \n" + self.path)

        c = 0
        for runner in os.listdir(self.path):
            print(runner)

            curPath = self.path + "/" + runner + "/"
            #os.chdir(curPath)

            # images = os.listdir(curPath)
            images = glob.glob(curPath + "*.png")
            max_frame_nr = len(images)
            print(max_frame_nr)

            iteration_len = int(len(images)/self.sequence_len)

            for i in range(0 , iteration_len):
                a = i*self.sequence_len
                b = a + self.sequence_len

                #print(i)
                #print("c " + str(c))
                #assert((b - a) == 63 )
                path_batch = []
                for k in range(a,b):
                    image_path = curPath + "Frame{:05d}.png".format(k)
                    path_batch.append(image_path)
                    if not os.path.isfile(image_path):
                        print(image_path + "\nFile does not exist !")
                        assert(False)
                self.image_sequences.append(path_batch)
                #print(images)
                c += 1

        batches_count = int(c)
        num_batches = len(self.image_sequences)
        
        print("number batches count : {}".format(c))
        print("number image sequences : {}".format(num_batches))
        assert(num_batches == batches_count)
        #for l in self.image_sequences:
        #    print("BATCH")
        #    for o in l:
        #        print(o)
        #assert(False)

    def get_test_and_train_set(self, split = 0.01):

        if split > 1.0 or split < 0.0:
            print("Invalid Split !")
            assert(False)

        images = self.images
        #shuffle multiples time

        if self.dataset_config.shuffle_data_set:
            for i in range(10):
                random.shuffle(images)

        bound = int(float(len(images)*split + 0.5))

        for i in range(0 , bound):
            self.test_set.append(images[i])

        for i in range(bound +1 , len(images)):
            self.training_set.append(images[i])


        numpy_trainingSet = np.array(self.training_set)
        numpy_testSet = np.array(self.test_set)

        self.training_set = numpy_trainingSet
        self.test_set = numpy_testSet
    
        size_trainSet = len(self.training_set)
        size_testSet = len(self.test_set)

        self.train_iterations = int(size_trainSet/self.batch_size)
        self.test_iterations = int(size_testSet/self.batch_size)

        print("Split Dataset into Training/Test :( " + str(size_trainSet) + "/" + str(size_testSet) + ") Set" )

    def get_mini_batch(self, iteration, mode = "training"):

        if mode == "training":
            data = self.training_set
        elif mode == "test":
            data = self.test_set
        else:
            print("mode not found !")
            assert(False)

        a = iteration*self.batch_size
        b = (iteration+1)*self.batch_size

        if b > len(data):
            diff = b-a
            a = a - diff

        #minibatch_images = list()
        minibatch_values = list()
        SpeedBatch = []
        SteeringBatch = []
        GyroBatch = []
        GoalDistanceBatch = []

        k = 0
        for i in range(a,b):
            
            img_path= data[i]

            if self.data_into_memory :
                img = self.images_memory.get(img_path)
                if self.csv_files:
                    if self.dataset_config.RANDOM_VALUES:
                        #v,s,g
                        v = np.random.uniform(0.0, 1.0)
                        s = np.random.uniform(-1.0, 1.0)
                        g = np.random.uniform(-1.0, 1.0)
                        gd = np.random.uniform(0.0, 1.0)

                        #print("v,s,g\n {},{},{}".format(v,s,g) )

                        #values = [v,s,g]
                        values = [v, s, gd]

                    else:
                        csv_path = data[i].replace("png", "csv")
                        frame_number = int(csv_path[len(csv_path)- 10: len(csv_path)- 4])
                        csv_path = data[i][0: -10].replace("Frame", "value{}.csv".format(frame_number))
                        values = self.values_memory.get(csv_path)
            else:
                img  = self.get_image(img_path)
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                #minibatch_images.append(img)

                if self.csv_files:
                    if self.dataset_config.RANDOM_VALUES:
                        #v,s,g
                        v = np.random.uniform(0.0, 1.0)
                        s = np.random.uniform(-1.0, 1.0)
                        g = np.random.uniform(-1.0, 1.0)
                        gd = np.random.uniform(0.0, 1.0)

                        values = [v,s,gd]
                    else:
                        csv_path = data[i].replace("png", "csv")
                        frame_number = int(csv_path[len(csv_path)- 10: len(csv_path)- 4])
                        csv_path = data[i][0: -10].replace("Frame", "value{}.csv".format(frame_number))
                        values = self.get_values(csv_path)

            if self.csv_files:
                SpeedBatch.append([values[0]])
                SteeringBatch.append([values[1]])
                #GyroBatch.append([values[2]])
                GoalDistanceBatch.append([values[2]])

            self.minibatch_images[k] = img
            k +=1

        if self.csv_files:
            return self.minibatch_images, np.array(SpeedBatch), np.array(SteeringBatch), np.array(GoalDistanceBatch)#np.array(GyroBatch)

        elif not self.csv_files:
            return self.minibatch_images
        else:
            print("Could not decide if csv files are loaded or not")
            assert(False)

    def get_image(self, path):
        #load image
        
        img = cv2.imread(path)
       # img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        if self.dataset_config.CROPIMAGE:
            img = img[ self.dataset_config.FROM_Y:self.dataset_config.TO_Y, self.dataset_config.FROM_X:self.dataset_config.TO_X]


        #resize
        #res = cv2.resize(cropped_img , (self.image_size[0], self.image_size[1]))

        res = np.array(img, dtype = "float32")

        #map to range [-1,1]
        if self.dataset_config.norm_for_mse:
            res -= 127.0
            res = res / 127.0
            #res /= 255.0

        # map to range [0,1]
        if self.dataset_config.norm_for_ce:
            res /= 255.0
        return res

    def get_values(self, path):

        with open(path) as csv_file:
            #print(path)
            values = []
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                #print(row)

                #Dont know which value belongs to which one?
                if len(row) > 0:

                    velocity = row[0]
                    steering = row[2]
                    gyro = row[1]
                    reward = row[3]
                    if "[" in steering:
                        steering = steering.replace("[", "")
                    if "]" in steering:
                        steering = steering.replace("]", "")

                    if "[" in velocity:
                        velocity = velocity.replace("[", "")
                    if "]" in velocity:
                        velocity = velocity.replace("]", "")

                    if "[" in gyro:
                        gyro = gyro.replace("[", "")
                    if "]" in gyro:
                        gyro = gyro.replace("]", "")

                    if "[" in reward:
                        reward = reward.replace("[", "")
                    if "]" in reward:
                        reward = reward.replace("]", "")

                    velocity = float(velocity)/self.dataset_config.SPEED_NORM
                    steering = float(steering)
                    gyro = float(gyro)/self.dataset_config.GYRO_NORM

                    reward = float(reward)

                    #print(row[2])

                    #if self.estimator_training_config.predict_velocity:
                    #    values.append(velocity)
                    #if self.estimator_training_config.predict_steering:
                    #    values.append(steering)
                    #if self.estimator_training_config.predict_reward:
                    #    values.append(reward)
                    #if self.estimator_training_config.predict_reward:
                    #    values.append(gyro)

                    values = [velocity, steering, gyro]

        return np.array(values)

    def load_dataset_from_previous_session(self ,session_dir):
        
        path = session_dir + "/dataset"
        if not os.path.isdir(path):
            print("Directory " + path + " does not exist !")

        self.training_set = []
        self.test_set = []

        #reload training set
        with open(path + '/training_set.txt') as f:
            for img_file in f.readlines():
                img_file = img_file.replace("\n", "")
                self.training_set.append(img_file)

        #reload test set
        with open(path + '/test_set.txt') as f:
           for img_file in f.readlines():
                img_file = img_file.replace("\n", "")
                self.test_set.append(img_file)
        
        #print(self.training_set)
        size_trainSet = len(self.training_set)
        size_testSet = len(self.test_set)

        self.train_iterations = int(size_trainSet/self.batch_size)
        self.test_iterations = int(size_testSet/self.batch_size)

       
        print("Dataset has been loaded from : " + session_dir)

    def store_dataset(self , session_dir):

        #store path of train and test images into one textfile respectively

        path = session_dir + "/dataset"

        if not os.path.exists(path):
            os.makedirs(path)

        with open(path + '/training_set.txt', 'w') as f:
            for item in self.training_set:
                f.write("%s\n" % item)

        
        with open(path + '/test_set.txt', 'w') as f:
            for item in self.test_set:
                f.write("%s\n" % item)
    
    def store_dataset_pickle(self , session_dir):
	
        #store path of train and test images into one textfile respectively

        path = session_dir + "/dataset"

        if not os.path.exists(path):
            os.makedirs(path)

        with open(path + '/training_set.pickle', 'wb') as f:
            pickle.dump(self.training_set, f)
        
        with open(path + '/test_set.pickle', 'wb') as f:
            pickle.dump(self.test_set, f)
    
    def load_dataset_from_previous_session_pickle(self ,session_dir):
        
        path = session_dir + "/dataset"
        if not os.path.isdir(path):
            print("Directory " + path + " does not exist !")

        self.training_set = []
        self.test_set = []

        #reload training set
        with open(path + '/training_set.pickle', 'rb') as f:
            self.training_set = pickle.load(f)
        
        with open(path + '/test_set.pickle', 'rb') as f:
            self.test_set = pickle.load(f)
        
        #print(self.training_set)
        size_trainSet = len(self.training_set)
        size_testSet = len(self.test_set)

        self.train_iterations = int(size_trainSet/self.batch_size)
        self.test_iterations = int(size_testSet/self.batch_size)

        print("Dataset has been loaded from : " + session_dir)


    
    def shuffle_train_and_test_set(self):
        if self.dataset_config.shuffle_data_set:
            np.random.shuffle(self.training_set)
            np.random.shuffle(self.test_set)

    def get_sequential_mini_batch(self, iteration, mode="training"):

        if mode == "training":
            data = self.training_set
        elif mode == "test":
            data = self.test_set
        else:
            print("mode not found !")
            assert (False)

        # print("iteration : {}".format(iteration))
        a = iteration * self.batch_size  # *self.sequence_len
        b = (iteration + 1) * self.batch_size  # *self.sequence_len

        if b > len(data):
            diff = b - a
            a = a - diff

        #print(data)

        batch = data[a:b]

        k = 0
        for paths in batch:
            #print("paths = {}".format(paths))
            for s in range(0, self.sequence_len):
                img_path = paths[s]
                img = self.get_image(img_path)
                #print("k = {} , s = {}".format(k,s))
                self.minibatch_sequential_images[(k*self.sequence_len)+s] = img
                #cv2.imwrite("test{}_{}.png".format(k,s), img)



            if self.csv_files:
                # take value of latest image
                csv_path = img_path.replace("png", "csv")
                csv_path = csv_path.replace("Frame", "value")
                values = self.get_values(csv_path)
                self.minibatch_sequential_values[k] = values
            k += 1

        if self.csv_files:
            # return np.reshape(self.minibatch_sequential_images, [self.batch_size*self.sequence_len, self.minibatch_images.shape[1], self.minibatch_images.shape[2], self.minibatch_images.shape[3] ]), self.minibatch_sequential_values
            return self.minibatch_sequential_images, self.minibatch_sequential_values

        elif not self.csv_files:
            return self.minibatch_sequential_images
        else:
            print("Could not decide if csv files are loaded or not")
            assert (False)


    def get_test_and_train_set_sequential(self, split = 0.1, shuffle = True):
	
        if split > 1.0 or split < 0.0:
            print("Invalid Split !")
            assert(False)

        self.image_sequences = np.array(self.image_sequences)
       

        #shuffle multiples time

        if self.dataset_config.shuffle_data_set:
            np.random.shuffle(self.image_sequences)

        bound = int(float(len(self.image_sequences)*split + 0.5) )

        for i in range(0 , bound):
            self.test_set.append(self.image_sequences[i])

        for i in range(bound +1 , len(self.image_sequences)):
            self.training_set.append(self.image_sequences[i])


        numpy_trainingSet = np.array(self.training_set)
        numpy_testSet = np.array(self.test_set)

        self.training_set = numpy_trainingSet
        self.test_set = numpy_testSet
        

      
        size_trainSet = len(self.training_set)
        size_testSet = len(self.test_set)

        self.train_iterations = int(size_trainSet/self.batch_size)
        self.test_iterations = int(size_testSet/self.batch_size)

        print("Split Dataset into Training/Test :( " + str(size_trainSet) + "/" + str(size_testSet) + ") Set" )

    def load_dataset_into_memory(self):
        print("Load images from " + self.path + "into memory")

        if not os.path.isdir(self.path):
            print("Dir not found ! : \n" + self.path)

        for runner in tqdm(os.listdir(self.path)):
            print(runner)

            curPath = self.path + "/" + runner + "/"
            #os.chdir(curPath)
            for file in glob.glob(curPath + "*.png"):

                #replace backslash with forward slash
                file = file.replace("\\" , "/")
                self.images.append(file)
                self.images_memory[file] = self.get_image(file)
                if self.csv_files:
                    csv_path = file.replace("png", "csv")
                    frame_number = int(csv_path[len(csv_path) - 10: len(csv_path) - 4])
                    csv_path = file[0: -10].replace("Frame", "value{}.csv".format(frame_number))
                    self.values_memory[csv_path] = self.get_values(csv_path)

            #assert(False)



#
if  __name__ == "__main__":



    dataset = Dataset(csv_files= True)
    dataset.load_images_sequential()
    dataset.get_test_and_train_set_sequential()

    for i in range(80):
        #for s in range(10):
        test_images, values =  dataset.get_sequential_mini_batch(0)
#
        test_images = 0.5 * (test_images + 1)*255
        print(test_images.shape)
            #images =test_images[i*10+s]
        images = test_images[i]
        images = np.array(images, np.uint8)
        #print(images.shape)
        cv2.imwrite("test{}.png".format(i), images)
            #cv2.imwrite("test{}_{}.png".format(i,s), images)

#
    #images, values = dataset.get_mini_batch(0)
#
#print(images)
#print(values)

