class Config():
    def __init__(self ):
        self.training_config = VAETrainingConfig()
        self.estimator_training_config = EstimatorTrainingConfig()
        self.dataset_config = DatasetConfig()
        self.network_config = NetworkConfig()


class VAETrainingConfig():
    def __init__(self ):
        self.batch_size = 128
        self.learning_rate = 0.0001
        self.resume_training = False
        self.num_epochs = 1000
        self.summary_train_loss = True
        self.summary_test_loss = True

        self.summary_show_images = True
        self.ph_dropout_rate = 0.3
        self.gradient_clipping = False
        self.gradient_range = [-1.0, 1.0]
        self.use_mse = True # mean squared error
        self.use_ce = False #cross entropy error
        # if both are true then cs will be used
        assert (self.use_mse != self.use_ce)

        self.max_file_to_keep = 50
        self.save_iteration = 1000

        self.lstm_cell = False
        self.LSTM_UNITS = 100
class DatasetConfig():
    def __init__(self ):
        self.data_path = "../Datasets/Dataset_2019-9-18-14-38-37"
        self.image_size = (40, 40 ,3)
        self.norm_for_mse = True
        self.norm_for_ce = False
        #both cannot be true
        assert(self.norm_for_mse != self.norm_for_ce   )
        self.sequence_len = 10
        self.CROPIMAGE = True
        self.FROM_X = 28
        self.TO_X = 68
        self.FROM_Y = 44
        self.TO_Y = 84

        self.shuffle_data_set = False

        self.dataset_in_memory = True



class NetworkConfig():
    def __init__(self ):
        self.latent_dim = 50
        self.use_dropout = False
        self.c_1 = 1.0
        self.c_2 = 1.0
        self.c_3 = 1.0
        self.use_decoder_tanh = True

        ##VAE CONFIG##
        self.CONCATNAME = "Steering GoalDistance Speed"
        self.VAE_LATENT_DIM = 50
        self.VAE_EARLY_FUSION = False
        self.GET_FEATURE_MAP_LAYER = 2
        self.VAE_LATENT_DIM = 50

        self.GET_FEATURE_MAP_LAYER = 2
        self.VAE_CNN_LAYERS = 1  # amount of layers
        self.VAE_CNN_FILTERS = [32, 64, 128, 256]  # Filter size in each layer

        self.VAE_CNN_KERNEL_SIZE = [4, 4, 3, 3]  # kernel size in each layer
        self.VAE_CNN_DILATION_RATE = [1, 1, 1, 1]  # kernel size in each layer
        self.VAE_CNN_PADDING = ["same", "valid", "valid", "valid"]  # kernel size in each layer
        self.VAE_CNN_STRIDES = [2, 2, 1, 1]  # stride size in each layer

        self.VAE_CNN_DECODER_LAYERS = 1  # amount of layers

        self.VAE_CNN_DECODER_FILTERS = [32]#[256, 128, 64, 32]  # Filter size in each layer
        self.VAE_CNN_DECODER_PADDING = ["same", "valid", "valid", "same"]  # kernel size in each layer
        self.VAE_CNN_DECODER_KERNEL_SIZE = [4]#[3, 3, 4, 4]  # kernel size in each layer
        self.VAE_CNN_DECODER_STRIDES = [2]#[1, 1, 2, 2]  # stride size in each layer


class EstimatorTrainingConfig():
    def __init__(self ):
        self.batch_size = 8
        self.learning_rate = 0.00001
        self.initialize_vae = False
        self.num_epochs = 500
        self.resume_training = False
        self.freeze_vae = False

        self.predict_velocity = True
        self.predict_gyro = False
        self.predict_steering = False
        self.predict_reward = False

        self.summary_train_loss = True
        self.summary_test_loss = True
        self.save_iteration = 5000
        self.train_vae_and_estimator = False

        self.estimate_units = self.predict_velocity + self.predict_gyro + self.predict_steering  + self.predict_reward
        
        self.dropout_rate = 0.3
        self.lstm_cell = True
        self.LSTM_UNITS = 25
        
