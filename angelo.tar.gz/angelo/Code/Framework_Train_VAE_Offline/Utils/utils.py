import tensorflow as tf
import numpy as np
import time
import glob
import matplotlib.pyplot as plt

import dataset
import os

from Config import Config

def create_new_session(data_set):
   #create new session
    localTime = time.localtime()
    timestamp = str(localTime.tm_year) + "-" + str(localTime.tm_mon) + "-" + str(localTime.tm_mday) + "-" + str(localTime.tm_hour) + "-" + str(localTime.tm_min) + "-" + str(localTime.tm_sec)
    log_dir = "./Log_VAE_" + timestamp
    if not os.path.exists(log_dir):
      os.makedirs(log_dir)
    
    data_set.load_images()
    data_set.get_test_and_train_set()
    data_set.store_dataset(log_dir)
    if data_set.data_into_memory:
        data_set.load_dataset_into_memory()
    print("Created new session:\nLogDir = " + log_dir)
    return log_dir


def create_new_session_estimator(data_set):
    # create new session
    localTime = time.localtime()
    timestamp = str(localTime.tm_year) + "-" + str(localTime.tm_mon) + "-" + str(localTime.tm_mday) + "-" + str(
        localTime.tm_hour) + "-" + str(localTime.tm_min) + "-" + str(localTime.tm_sec)
    log_dir = "./Log_Estimator_" + timestamp
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    if Config().estimator_training_config.lstm_cell:
      data_set.load_images_sequential()
      data_set.get_test_and_train_set_sequential()
    else:
      data_set.load_images()
      data_set.get_test_and_train_set()

    data_set.store_dataset_pickle(log_dir)
    print("Created new session:\nLogDir = " + log_dir)
    return log_dir

def create_new_session_vae_estimator(data_set):
    # create new session
    localTime = time.localtime()
    timestamp = str(localTime.tm_year) + "-" + str(localTime.tm_mon) + "-" + str(localTime.tm_mday) + "-" + str(
        localTime.tm_hour) + "-" + str(localTime.tm_min) + "-" + str(localTime.tm_sec)
    log_dir = "./Log_VAE_Estimator_" + timestamp
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    if Config().estimator_training_config.lstm_cell:
      data_set.load_images_sequential()
      data_set.get_test_and_train_set_sequential()
    else:
      data_set.load_images()
      data_set.get_test_and_train_set()

    data_set.store_dataset_pickle(log_dir)
    print("Created new session:\nLogDir = " + log_dir)
    return log_dir


def restore_session(sess, model, data_set):

  #get latest logdir

  if model._name == "VAE":
    dir_name = "Log_VAE*"
  elif  model._name == "Estimator":
    dir_name = "Log_Estimator*"
  else:
    raise RuntimeError("invalid model name !")

  if glob.glob(dir_name) is None:
    print("No previous session found ! Set resume parameter to false and rerun code!")
    assert(False)

  log_dir = glob.glob(dir_name)[-1]
  latest_checkpoint = tf.train.latest_checkpoint(log_dir)
        
  print("Restore Session : " + log_dir)
  print("Checkpoint : " + str(latest_checkpoint))

  #restore the session
  model.tf_saver.restore(sess, latest_checkpoint)
  #load dataset that has been used for this session
  data_set.load_dataset_from_previous_session_pickle(log_dir)

  #restore epoch
  epoch = str(log_dir + "/Test_and_Reconstructions")#[-1][-8: -4]
  epoch = int(os.listdir(epoch)[-1][-8: -4])
  print("Restored epoch : " + str(epoch))
  return log_dir, epoch


#def restore_session_estimator(sess, model, data_set):
#    # get latest logdir
#    if glob.glob("Log_Estimator*") is None:
#        print("No previous session found ! Set resume parameter to false and rerun code!")
#        assert (False)
#
#    log_dir = glob.glob("Log_Estimator*")[-1]
#    latest_checkpoint = tf.train.latest_checkpoint(log_dir)
#
#    print("Restore Session : " + log_dir)
#    print("Checkpoint : " + str(latest_checkpoint))
#
#    # restore the session
#    model.tf_saver.restore(sess, latest_checkpoint)
#    # load dataset that has been used for this session
#    data_set.load_dataset_from_previous_session(log_dir)
#
#    # restore epoch
#    epoch = str(log_dir + "/Test_and_Reconstructions")  # [-1][-8: -4]
#    epoch = int(os.listdir(epoch)[-1][-8: -4])
#    print("Restored epoch : " + str(epoch))
#    return log_dir, epoch
#
#
def restore_session_vae_estimator(sess, model, data_set):
    # get latest logdir
    dir_name= "Log_VAE_Estimator*"
    if glob.glob(dir_name) is None:
        print("No previous session found ! Set resume parameter to false and rerun code!")
        assert (False)

    log_dir = glob.glob(dir_name)[-1]
    latest_checkpoint = tf.train.latest_checkpoint(log_dir)

    print("Restore Session : " + log_dir)
    print("Checkpoint : " + str(latest_checkpoint))

    # restore the session
    model.tf_saver.restore(sess, latest_checkpoint)
    # load dataset that has been used for this session
    data_set.load_dataset_from_previous_session_pickle(log_dir)

    # restore epoch
    epoch = str(log_dir + "/Test_and_Reconstructions")  # [-1][-8: -4]
    epoch = int(os.listdir(epoch)[-1][-8: -4])
    print("Restored epoch : " + str(epoch))
    return log_dir, epoch


def test_and_show_reconstructed_test_images(model, epoch, test_input, sess , out_dir , num_examples_to_show = 4):
	
  feed_dict_images = {model.net_input : test_input}

  reconstructions = sess.run(model.decoder, feed_dict = feed_dict_images)

  if not Config().network_config.use_decoder_tanh:
    reconstructions = sigmoid(reconstructions)

  fig = plt.figure(figsize=(4,4))
  #stack them together
  if Config().estimator_training_config.lstm_cell:
      test_images_labels = test_input[:, Config().dataset_config.sequence_len -1]
      #for j in range(Config().estimator_training_config.batch_size):
      #    test_images_labels.append(test_input[j, :, :, j:j + 3])
#
      #test_images_labels = np.array(test_images_labels)

  test_and_reconstruction = np.array([test_images_labels[0, : , : , :] , test_images_labels[1, : , :, :] , reconstructions[0, : , : , :], reconstructions[1, : , : , :] ])

  if Config().network_config.use_decoder_tanh:
    test_and_reconstruction = 0.5*(test_and_reconstruction+1)

  for i in range(test_and_reconstruction.shape[0]):
      plt.subplot(2, 2, i+1)
      plt.imshow(test_and_reconstruction[i, :, :, :], cmap='brg')
      plt.axis('off')


  # tight_layout minimizes the overlap between 2 sub-plots
  imagedir = out_dir + "/Test_and_Reconstructions"

  if not os.path.exists(imagedir):
    os.mkdir(imagedir)

  plt.savefig(imagedir + "/" + 'image_at_epoch_{:04d}.png'.format(epoch))
  plt.close(fig)

def show_predicted_test_values(vae_model, estimator_model , sess, test_input, labels, num_examples= 8):

    feed_dict_images = {vae_model.net_input: test_input}
    predictions = sess.run(estimator_model.estimate, feed_dict=feed_dict_images)
    print("ground truth values : {}".format(labels))
    print("predictions : {}".format(predictions))



def sigmoid(x ):
	return 1 / (1 + np.exp(-x))

def tanh(x):
    return np.tanh(x)

