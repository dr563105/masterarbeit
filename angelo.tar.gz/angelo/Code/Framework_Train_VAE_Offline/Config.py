class Config():
    def __init__(self ):
        self.training_config = VAETrainingConfig()
        self.estimator_training_config = EstimatorTrainingConfig()
        self.dataset_config = DatasetConfig()
        self.network_config = NetworkConfig()


class VAETrainingConfig():
    def __init__(self ):
        self.batch_size = 128
        self.learning_rate = 0.0001
        self.resume_training = False
        self.num_epochs = 1000
        self.summary_train_loss = True
        self.summary_test_loss = True

        self.summary_show_images = True
        self.ph_dropout_rate = 0.3
        self.gradient_clipping = False
        self.gradient_range = [-1.0, 1.0]
        self.use_mse = True # mean squared error
        self.use_ce = False #cross entropy error
        # if both are true then cs will be used
        assert (self.use_mse != self.use_ce)

        self.max_file_to_keep = 10
        self.save_iteration = 5000

        self.lstm_cell = False
        self.LSTM_UNITS = 100
class DatasetConfig():
    def __init__(self ):
        self.data_path = "../Datasets/Dataset_GTAV_2019-12-1-17-59-53"
        #self.image_size = (40, 40 ,3)
        self.image_size = (100, 100, 3)
        self.norm_for_mse = True
        self.norm_for_ce = False
        #both cannot be true
        assert(self.norm_for_mse != self.norm_for_ce   )
        self.sequence_len = 10
        self.CROPIMAGE = False
        self.FROM_X = 28
        self.TO_X = 68
        self.FROM_Y = 44
        self.TO_Y = 84
        self.RANDOM_VALUES = True
        self.SPEED_NORM = 120.0
        self.GYRO_NORM = 100.0


        self.shuffle_data_set = True

        self.dataset_in_memory = False



class NetworkConfig():
    def __init__(self ):
        self.latent_dim = 300
        self.use_dropout = False
        self.c_1 = 1.0
        self.c_2 = 1.0
        self.c_3 = 1.0
        self.use_decoder_tanh = True

        ##VAE CONFIG##

        import numpy as np
        self.CONCATNAME = "Speed Steering GoalDistance"
        self.VAE_EARLY_FUSION = False


        self.VAE_LATENT_DIM = 200

        self.GET_FEATURE_MAP_LAYER = 5

        self.VAE_CNN_LAYERS = 13  # amount of layers
        self.VAE_CNN_DECODER_LAYERS = self.VAE_CNN_LAYERS  # amount of layers
        self.VAE_CNN_FILTERS = [32, 32 ,64, 64 , 64,  128, 128,128,  256, 256,  512, 512, 512]  # Filter size in each layer


        self.VAE_CNN_KERNEL_SIZE = [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]#list(np.ones(self.VAE_CNN_LAYERS, dtype = np.uint8)*3)

        #self.VAE_CNN_KERNEL_SIZE = [3, 3, 3, 3, 3,3]  # kernel size in each layer
        self.VAE_CNN_DILATION_RATE = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]#list(np.ones(self.VAE_CNN_LAYERS, dtype = np.uint8))#[1, 1, 1, 1, 1,1]  # kernel size in each layer
        self.VAE_CNN_PADDING = ["same","same", "same", "same", "same", "same","same", "same", "same", "same", "same", "same" , "same"]  # kernel size in each layer
        self.VAE_CNN_STRIDES = [2, 2, 1, 1, 2, 1,1,2,1,2,1,1,2]  # stride size in each layer


        self.VAE_CNN_DECODER_FILTERS = []#self.VAE_CNN_FILTERS#[512, 512, 256, 128, 64, 32]  # Filter size in each layer

        for e in range(0,len(self.VAE_CNN_FILTERS)):
            print(e)
            print(len(self.VAE_CNN_FILTERS))
            p =  self.VAE_CNN_FILTERS[len(self.VAE_CNN_FILTERS)-1 - e ]
            self.VAE_CNN_DECODER_FILTERS.append(p)

        self.VAE_CNN_DECODER_PADDING =  ["valid","same", "valid", "valid", "same", "same","same",  "same", "same", "same", "same", "same" , "same"]

       #["valid", "valid", "valid", "valid", "same","same"]# kernel size in each layer


        self.VAE_CNN_DECODER_KERNEL_SIZE = self.VAE_CNN_KERNEL_SIZE
        self.VAE_CNN_DECODER_STRIDES = [2,2,1,2, 1,1,1, 1,1,1,1,2,2]#self.VAE_CNN_STRIDES[-1:0]#[1, 1, 1, 1, 2, 2]  # stride size in each layer

        #self.VAE_CNN_LAYERS = 8# amount of layers
        #self.VAE_CNN_FILTERS = [32, 64, 128, 256, 512, 512, 512, 1024]# Filter size in each layer
#
        #self.VAE_CNN_KERNEL_SIZE = [4,4,3,3, 3,3,3,3]#kernel size in each layer
        #self.VAE_CNN_DILATION_RATE = [1, 1, 1,1,1,1,1,1]  # kernel size in each layer
        #self.VAE_CNN_PADDING = ["same", "valid", "valid", "valid", "valid", "valid","valid", "same"]  # kernel size in each layer
        #self.VAE_CNN_STRIDES = [2,2,1,1,1,1,1,2]# stride size in each layer
#
        #self.VAE_CNN_DECODER_LAYERS = 8  # amount of layers
#
        #self.VAE_CNN_DECODER_FILTERS = [ 1024,512, 512 , 512, 256, 128, 64, 32]# Filter size in each layer
        #self.VAE_CNN_DECODER_PADDING = ["same","valid", "valid","valid", "valid", "valid", "valid","same"]  # kernel size in each layer
        #self.VAE_CNN_DECODER_KERNEL_SIZE = [3,3,3,3,3,3,4,4]#kernel size in each layer
        #self.VAE_CNN_DECODER_STRIDES = [2,1,1,1,1,1,2,2]# stride size in each layer



class EstimatorTrainingConfig():
    def __init__(self ):
        self.batch_size = 8
        self.learning_rate = 0.00001
        self.initialize_vae = False
        self.num_epochs = 500
        self.resume_training = False
        self.freeze_vae = False

        self.predict_velocity = True
        self.predict_gyro = False
        self.predict_steering = False
        self.predict_reward = False

        self.summary_train_loss = True
        self.summary_test_loss = True
        self.save_iteration = 5000
        self.train_vae_and_estimator = False

        self.estimate_units = self.predict_velocity + self.predict_gyro + self.predict_steering  + self.predict_reward
        
        self.dropout_rate = 0.3
        self.lstm_cell = True
        self.LSTM_UNITS = 25
        
